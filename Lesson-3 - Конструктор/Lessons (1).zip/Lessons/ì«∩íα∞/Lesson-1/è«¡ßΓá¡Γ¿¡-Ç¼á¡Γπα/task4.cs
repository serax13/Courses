using System;

namespace Task_4
{
	public class Task_4
	
	{
		static void GetCount(int Chislo)
		{			
			for(int i=0; i<=Chislo; i++)
			{
				if(i<Chislo)
				{
					
				
				Console.Write(i+",");
				}				
				
				if (i==Chislo)
				{
					Console.Write(i+";");
				}
			}
			
		}
		public static void Main(string [] args)
		{
			GetCount(15);
			
			Console.ReadKey();
		}
	}
}