using System;
using System.Threading;

namespace Task_6
{
	public class Task_6
	
	{
		static void GetStars(int x,int y)
		{	
			for (int i=0; i<=x; i++)
			{
				for (int j = 0; j < y; j++)
				{
					Console.Write("*");
					Thread.Sleep(50);
				}
				Console.Write("\n");
			}
			
		}
		public static void Main(string [] args)
		{
			
			GetStars(10,11);
			
			Console.ReadKey();
		}
	}
}