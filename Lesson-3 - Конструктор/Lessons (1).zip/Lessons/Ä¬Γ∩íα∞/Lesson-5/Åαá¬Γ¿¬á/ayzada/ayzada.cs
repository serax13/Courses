using System;

namespace L
{
	public class L
	{
		public static void Main(string [] args)
		{	
		Console.WriteLine("������� ����� ");
		decimal summ=Convert.ToDecimal(Console.ReadLine());
		summ=(summ/100)*90;
		
		Console.WriteLine(summ);
		
		Console.ReadKey();
		}
	}
}