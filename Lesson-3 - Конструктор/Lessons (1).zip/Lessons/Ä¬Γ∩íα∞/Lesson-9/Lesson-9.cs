using System;
using System.Threading;

namespace Lesson9
{
	public class Lesson9
	{
		public static void Main(string [] agrs)
		{
			// Текст Replace
			string textSum = "100 сом";			
			// До Replace
			Console.WriteLine(textSum);
			// После Replace
			Console.WriteLine(textSum.Replace("сом",""));
			
			// Тест Thread
			Console.WriteLine("Подождите пожалуйста");
			for(int i = 1; i <= 100; i++)
			{
				Thread.Sleep(1000);
				Console.Write("=");
			}
			Console.ReadKey();
		}
	}
}