using System;
namespace Lesson
{
	public class lesson
	{
	  public static void Main(string [] args)
	  {
		  Console.WriteLine ("Малахов: \n сорян");
		  
	  }
	}
}

