using System;
namespace Lesson
{
	public class lesson
	{
	  public static void Main(string [] args)
	  {
	      Console.ForegroundColor = ConsoleColor.Red;  
              Console.WriteLine ("�������: \n<<�����>>");
		  
	  }
	}
}