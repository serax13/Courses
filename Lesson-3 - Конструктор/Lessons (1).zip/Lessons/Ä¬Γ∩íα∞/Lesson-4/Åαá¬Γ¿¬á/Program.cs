using System;

namespace Lesson4
{
	public class Program
	{
		public static void Main(string [] agrs)
		{
			
			// ================== Konkatenacia strok ================//
			byte age = 25;
			string name = "Zaxit";
			// Console.WriteLine("Privet menia zovut "+name+" mne "+age+" let");
			// Console.ReadKey();
			
			
			Console.WriteLine("Wwedite imia");
			string name1 = Console.ReadLine();
			
			Console.WriteLine("Wwedite vozrast");
			byte age1 = Convert.ToByte(Console.ReadLine()); 
			
			
			if(age1 >= 18)
			{
				Console.WriteLine("Uvajaemyi "+name1+" vu mojete buxat'");
			}
			else
			{
				Console.WriteLine("Nett "+name1+" vy ne mojete buhat'");
				age1++;
				Console.WriteLine("Prihodite kogda budet vam "+age1);
			}
			
			
			
			

		    Console.ReadKey();
			
			
			
			
			
			
			
			
			
			
			
		}
	}
}