﻿using System;

namespace Lesson7
{
	public class Lesson7
	{
		public static void Main(string [] agrs)
		{
			// Массив int
            int[] intArr = new int[2];
            intArr[0] = 100;
            intArr[1] = 23;
			
			// Массив string
			string[] strArr = new string[2];
			strArr[0] = "Саша";
			strArr[1] = "Вася";
			
			
			// Телефон
			string PhoneNumber = "0700123456";
			
			string[] opers = new string[3];
			opers[0] = "070";
			opers[1] = "077";
			opers[2] = "055";
			
			if(PhoneNumber.Substring(0, 3) == opers[0])
			{
				Console.WriteLine("Да");
			}
			else
			{
				Console.WriteLine("Нет");
			}
			
			Console.WriteLine(strArr[1]);
			Console.ReadKey();
		}
	}
}