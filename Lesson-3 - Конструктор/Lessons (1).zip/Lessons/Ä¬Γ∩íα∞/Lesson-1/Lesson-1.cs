// Подключение библиотек
using System;

namespace Lesson1
{
	// Урок 1
	// Данная программа выводит на консоль текст приветсвия Hello World!
	public class Lesson1
	{
		// Главный метод для запуска программы
		public static void Main(string [] agrs)
		{
			// Команда для вывода
			Console.WriteLine("Hello World!");
			
			// Задерживает консольную программу пока пользователь сам не закроет
			Console.ReadKey();
		}
	}
}