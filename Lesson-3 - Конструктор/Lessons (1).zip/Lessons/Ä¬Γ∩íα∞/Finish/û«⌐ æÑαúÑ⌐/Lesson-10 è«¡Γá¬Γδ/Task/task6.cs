using System;
using System.Threading;

namespace lesson9
{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			string Text = Console.ReadLine();
			string[] TextList = Text.Split(',');
			int TextLength = TextList.Length;

			for (int i = 0; i < TextLength; i++)
			{
				Console.WriteLine(TextList[i]);
			}

			Console.ReadKey();
		}
	}
}