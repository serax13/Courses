using System;
using System.Threading;

namespace lesson9
{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			int n = 1;
			string Letters = "АБВГДЕЁЖЗИКЛМНОПРСТУФКЦЧШЩЪЫЬЭЮЯ";
 
			for(int i = 0; i < Letters.Length; i++)
			{
   			Console.Write(Letters[i]);
   			n++;
				if (n>5)
				{
					n = 1;
					Console.Write("\n");
				}
				Thread.Sleep(50);
			}
			
		Console.ReadKey();
	 }
 }
} 