using System;

namespace TaskApp10
{
	public class TaskApp10
	{
		
		public static void Main(string [] agrs)
		{
	
			
			for (int i=1;i<=10;i++)
			{
				
				for (int j=2;j<=9;j++)
				{
				// Не поняла как выровнять таблицу, криво получается вывод таблицы
				Console.Write("{1}x{0}={2} ", new object[] { i, j, i * j });
				
				}
				Console.Write('\n');
			
				
			}
			
		}
	
	}
						
}