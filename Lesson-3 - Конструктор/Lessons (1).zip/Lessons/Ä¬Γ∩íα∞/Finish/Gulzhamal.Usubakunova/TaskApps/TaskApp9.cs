using System;

namespace TaskApp9
{
	public class TaskApp9
	{
		
		public static void Main(string [] agrs)
		{
	
			for (int i=10;i>0;i--)
			{
				Console.WriteLine(i);
				
			}
			
		}
	
	}
						
}