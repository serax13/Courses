﻿using System;


namespace TelephoneBook
{
	public class TelephoneBook
	{
		
		public static void Main(string [] agrs)
		{
			string ClientsAnswer;
			
			Console.WriteLine("Cколько контактов хотите сохранить");
			string ContactCount = Console.ReadLine();
			int count = Convert.ToInt32(ContactCount.Trim());
			
			Console.WriteLine("Введите номер телефона.Пример:Сергей, 0700123456");
			string[] TelephonNumber = new string[count];
			for(int i = 0; i <= count -1; i++)
			{
				TelephonNumber [i] = Console.ReadLine();
			}
			
			Console.WriteLine("Результат массива");
			for(int i = 0; i <= TelephonNumber.Length - 1; i++)
			{
				Console.WriteLine(TelephonNumber [i]);
			}
			
			
			Console.WriteLine("Хотите позвонить? Да/Нет");
			ClientsAnswer=Console.ReadLine();
			
			if(ClientsAnswer== "Да")
			{
				Console.WriteLine("Введите имя! Например:Сергей");
				string ClientsName= Console.ReadLine();
				
				for(int i = 0; i <= TelephonNumber.Length - 1; i++)
				{
				if(TelephonNumber[i].ToUpper().Contains(ClientsName.ToUpper()) == true)
				{
					Console.WriteLine("Вызов : "+TelephonNumber[i]);
				}
				
				else
				{
					Console.WriteLine("Контакт не найден");
				}
				}
				
		
			}
			else  if (ClientsAnswer== "Нет")
			{
			Console.WriteLine("Спасибо за введенные данные");
			}

			Console.ReadKey();
	
	}
}
}