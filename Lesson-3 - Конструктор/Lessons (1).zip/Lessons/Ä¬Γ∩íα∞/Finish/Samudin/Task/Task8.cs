using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
			Console.ForegroundColor = ConsoleColor.Blue;
			Console.WriteLine("Добро пожаловать в супермаркет 'МАЯК'!!!".ToUpper());
			Console.ForegroundColor = ConsoleColor.White;
			string[] products = new string [12];
			products[0] = "0 - Чай | 120 сом";
			products[1] = "1 - Сахар | 50 сом";
			products[2] = "2 - Хлеб | 20 сом";
			products[3] = "3 - Масло | 80 сом";
			products[4] = "4 - Порошок | 65 сом";
			products[5] = "5 - Сэндвич | 40 сом";
			products[6] = "6 - Сыр | 130 сом";
			products[7] = "7 - Чипсы | 90 сом";
			products[8] = "8 - Майонез | 18 сом";
			products[9] = "9 - Кофе | 10 сом";
			products[10] = "10 - Кефир | 40 сом";
			products[11] = "11 - Молоко | 38 сом";

			for(int i = 0; i <= products.Length - 1; i++)
			{
				Console.WriteLine(products[i].Trim());
			}
			Console.ForegroundColor = ConsoleColor.Blue;
			Console.WriteLine("Введите продукты через запятую!!!");
			Console.WriteLine("Выберите продукты: ");
			Console.ForegroundColor = ConsoleColor.White;

			string productInputs = Console.ReadLine();
			string[] selectProducts = productInputs.Split(',');
			decimal sum = 0;
			string[] Gandon = new string[selectProducts.Length];
			for(int i = 0; i <= selectProducts.Length - 1; i++)
			{
				int result = Convert.ToInt32(selectProducts[i].Trim());
				string myProducts = products[result].Split('|')[1];
				sum = sum + Convert.ToDecimal(myProducts.Replace("сом", ""));
				Gandon[i] = products[result];
			}
			for(int i = 0; i < Gandon.Length; i++)
			{
				Console.WriteLine(Gandon[i]);
			}
			Console.ForegroundColor = ConsoleColor.Blue;
			Console.WriteLine("Подождите пожалуйста...");
			for(int i = 1; i <= 30; i++)
			{
				Console.Write("=");
				Thread.Sleep(100);
			}
			Console.WriteLine("");
			Console.ForegroundColor = ConsoleColor.Green;
			Console.Write("Итоговая сумма: " + sum + " Сом: ");
			Console.ForegroundColor = ConsoleColor.White;
			decimal pay = Convert.ToDecimal(Console.ReadLine());
			Console.WriteLine();
			if(pay == sum)
			{
				Console.ForegroundColor = ConsoleColor.Blue;
				Console.WriteLine("Спасибо за покупку!");
				Console.ForegroundColor = ConsoleColor.White;
			}
			else if(pay > sum)
			{
				Console.ForegroundColor = ConsoleColor.Blue;
				Console.WriteLine("Спасибо за покупку! Ваша сдача " + (pay - sum) + " Сом");
				Console.ForegroundColor = ConsoleColor.White;
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("ERROR!!!");
				Console.ForegroundColor = ConsoleColor.White;
			}
		}	
	}		
}			