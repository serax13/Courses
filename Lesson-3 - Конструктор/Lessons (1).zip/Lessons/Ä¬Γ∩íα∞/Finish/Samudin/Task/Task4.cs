using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
			Console.WriteLine("Введите буквы на английском, через запятую!!!".ToUpper());
			int count = 1;
			string alfavitInputs = Console.ReadLine();
			string[] selectAlfavit = alfavitInputs.Split(',');
			for(int i = 0; i < selectAlfavit.Length; i++)
			{
				if(count > 4)
				{
					count = 1;
					Console.WriteLine();
				}
				Console.Write(selectAlfavit[i]);
				count++;
			}
			Console.ReadKey();	
		}		
	}			
}				