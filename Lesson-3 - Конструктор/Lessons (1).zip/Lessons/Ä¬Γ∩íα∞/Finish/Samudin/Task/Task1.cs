using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
			Console.WriteLine("Алфавит");
			string[] alvafit = new string [33];
			alvafit[0] = "А";
			alvafit[1] = "Б";
			alvafit[2] = "В";
			alvafit[3] = "Г";
			alvafit[4] = "Д";
			alvafit[5] = "Е";
			alvafit[6] = "Ё";
			alvafit[7] = "Ж";
			alvafit[8] = "З";
			alvafit[9] = "И";
			alvafit[10] = "Й";
			alvafit[11] = "К";
			alvafit[12] = "Л";
			alvafit[13] = "М";
			alvafit[14] = "Н";
			alvafit[15] = "О";
			alvafit[16] = "П";
			alvafit[17] = "Р";
			alvafit[18] = "С";
			alvafit[19] = "Т";
			alvafit[20] = "У";
			alvafit[21] = "Ф";
			alvafit[22] = "Х";
			alvafit[23] = "Ц";
			alvafit[24] = "Ч";
			alvafit[25] = "Ш";
			alvafit[26] = "Щ";
			alvafit[27] = "Ъ";
			alvafit[28] = "Ы";
			alvafit[29] = "Ь";
			alvafit[30] = "Э";
			alvafit[31] = "Ю";
			alvafit[32] = "Я";

			for(int i = 0; i <= alvafit.Length - 1; i++)
			{
				Console.WriteLine(alvafit[i].ToUpper());
				Thread.Sleep(250);
			}
			Console.ReadKey();
		}	
	}		
}