using System;

namespace Lessons2
{
    public class Lessons2
    {
    	static void Method(string[] arr, int x)
    	{  
            Console.WriteLine(arr[x]);
    	}
    	public static void Main (string [] args)
    	{
            string[] tovar = new string[6];
            tovar[0] = "Машина";
            tovar[1] = "Квартира";
            tovar[2] = "Кроссовки";
            tovar[3] = "Одежда";
            tovar[4] = "Украшения";
            tovar[5] = "Волосы";
            Method(tovar, 1);
    	}	
    }		
}   