using System;

namespace Lessons2
{
    public class Lessons2
    {
    	static void Znachek()
    	{  
            int count = Convert.ToInt32(Console.ReadLine());
            string[] words = new string[count];
            for(int i = 0; i <= count - 1; i++)
            {
                words[i] = Console.ReadLine();
            }
            for(int i = 0; i <= count - 1; i++)
            {
                Console.WriteLine(words[i]);
            }
    	}
    	public static void Main (string [] args)
    	{
            Znachek();
    	}	
    }		
}   