using System;
//using Threading;

namespace Homework
{
    public class Homework
    {
    	static void Metod(int x, int y)
    	{
    		string[] arrayX = new string[x];
    		int[] arrayY = new int[y];
    		for(int g = 0; g <= arrayY.Length - 1; g++)
    		{
    			for(int i = 0; i <= arrayX.Length - 1; i++)
    			{
    				arrayX[i] = "*";
    				Console.Write(arrayX[i]);
    			}
    			Console.WriteLine();
    		}	
    	}
    	public static void Main (string [] args)
    	{
    		Metod(Convert.ToInt32(Console.ReadLine()),Convert.ToInt32(Console.ReadLine()));
            Console.ReadKey();
    	}	
    }		
}    		
