using System;
namespace Homework
{
    public class Homework
    {
    	public static void Main (string [] args)
    	{
    		Console.WriteLine("Выбор услуг: 1) Игры, 2) Коммунальные услуги");
    		string select = Console.ReadLine();

     		if(select == "1")
    		{
    			Console.WriteLine("Игры:");
    			Console.WriteLine("1) Танки - 50, 2) Warface - 200, 3) Королевство - 500, 4) Техномагия - 750, 5) Strife - 835, 6) Prime World 1500");
    			string selectGames = Console.ReadLine();
    			int gameCost = 0;
	    		if(selectGames == "1")
	    		{
	    			Console.WriteLine("Введите оплату(Танки): ");
	    			gameCost = 50;
	    		}
	    	    else if(selectGames == "2")
	    		{
	    			Console.WriteLine("Введите оплату(Warface): ");
	    			gameCost = 200;
	    		}
	    		else if(selectGames == "3")
	    		{
	    			Console.WriteLine("Введите оплату(Королевство): ");
	    			gameCost = 500;
	    		}
	    		else if(selectGames == "4")
	    		{
	    			Console.WriteLine("Введите оплату(Техномагия): ");
	    			gameCost = 750;
	    		}
	    		else if(selectGames == "5")
	    		{
	    			Console.WriteLine("Введите оплату(Strife): ");
	    			gameCost = 835;
	    		}
	    		else if(selectGames == "6")
	    		{
	    			Console.WriteLine("Введите оплату(Prime World): ");
	    			gameCost = 1500;
	    		}
	    		else 
	    		{
    				Console.ForegroundColor = ConsoleColor.Red;
	    			Console.WriteLine("ERROR!!");
	    			Console.ForegroundColor = ConsoleColor.White;	    		}
	    		int pay = Convert.ToInt32(Console.ReadLine());

		    	if(pay < gameCost)
				{
    				Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("Недостаточно средств для оплаты игры");
					Console.ForegroundColor = ConsoleColor.White;
					
				}
				else if (pay > 5000)
				{
					Console.ForegroundColor = ConsoleColor.Red;
	    			Console.WriteLine("Максимальная сумма 5000 сом".ToUpper());
	    			Console.ForegroundColor = ConsoleColor.White;
				}
				else
				{
					int result = pay - gameCost;
    				Console.ForegroundColor = ConsoleColor.Green;
					Console.WriteLine("Игра оплачена");
					Console.WriteLine("Сдача составляет " + result);
					Console.ForegroundColor = ConsoleColor.White;
					System.Console.WriteLine(result + " будет отправлена на ваш номер телефона");
					System.Console.WriteLine("Введите ваш номер телефона:");
					string phoneNumber = Console.ReadLine();
					System.Console.WriteLine(phoneNumber + " пополнен на " +result);
					Console.ReadKey();
				}
			}
    		else if(select == "2")
    		{
    			Console.WriteLine("Коммунальные услуги:");
    			Console.WriteLine("1) Домофон - 100, 2) Газ - 200, 3) Отопление - 300");
    			string selectService = Console.ReadLine();
    			int serviceCost = 0;

	    		if(selectService == "1")
	    		{
	    			Console.WriteLine("1) Оплата за месяц, 2) Предоплата");
	    			string selectIntercom = Console.ReadLine();
	    			if(selectIntercom == "1")
	    			{
	    				Console.WriteLine("Введите оплату за месяц(Домофон): ");
	    				serviceCost = 100;
	    			}
	    			else if(selectIntercom == "2")
	    			{
	    				Console.WriteLine("Предоплата макс. на 6 месяцев");
	    			}
	    		}
	    		else if(selectService == "2")
	    		{
	    			Console.WriteLine("1) Оплата за месяц, 2) Предоплата");
	    			string selectGas = Console.ReadLine();
	    			if(selectGas == "1")
	    			{
	    				Console.WriteLine("Введите оплату(Газ): ");
	    				serviceCost = 200;
	    			}
	    			else if(selectGas == "2")
	    			{
	    				Console.WriteLine("Предоплата макс. на 6 месяцев");
	    			}
	    		}
	    		else if(selectService == "3")
	    		{
	    			Console.WriteLine("1) Оплата за месяц, 2) Предоплата");
	    			string selectHeat = Console.ReadLine();
	    			if(selectHeat == "1")
	    			{
	    				Console.WriteLine("Введите оплату(Отопление): ");
	    				serviceCost = 300;
	    			}
	    			else if(selectHeat == "2")
	    			{
	    				Console.WriteLine("Предоплата макс. на 6 месяцев");
	    			}
	    		}
	    		else
	    		{
    				Console.ForegroundColor = ConsoleColor.Red;
	    			Console.WriteLine("ERROR!!!");
	    			Console.ForegroundColor = ConsoleColor.White;	    		}
	    		int pay1 = Convert.ToInt32(Console.ReadLine());

		    	if(pay1 < serviceCost)
				{
    				Console.ForegroundColor = ConsoleColor.Red;
					Console.WriteLine("Недостаточно средств для оплаты коммунальных услуг");
					Console.ForegroundColor = ConsoleColor.White;				}
				else if (pay1 > 5000)
				{
					Console.ForegroundColor = ConsoleColor.Red;
	    			Console.WriteLine("Максимальная сумма 5000 сом".ToUpper());
	    			Console.ForegroundColor = ConsoleColor.White;				}
				else
				{
					int result1 = pay1 - serviceCost;
    				Console.ForegroundColor = ConsoleColor.Green;
					Console.WriteLine("Коммунальная услуга оплачена");
					Console.WriteLine("Сдача составляет " + result1);
					Console.ForegroundColor = ConsoleColor.White;					
					System.Console.WriteLine(result1 + " будет отправлена на ваш номер телефона");
					System.Console.WriteLine("Введите ваш номер телефона:");
					string phoneNumber = Console.ReadLine();
					System.Console.WriteLine(phoneNumber + " пополнен на " +result1);
					Console.ReadKey();
				}
    		}
    		else
    		{
    			Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("ERROR!");
				Console.ForegroundColor = ConsoleColor.White;
    		}
    		Console.ReadKey();
		}
    }
}