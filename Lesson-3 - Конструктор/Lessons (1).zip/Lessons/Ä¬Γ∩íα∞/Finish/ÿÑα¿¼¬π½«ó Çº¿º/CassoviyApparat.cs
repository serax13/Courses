using System;
namespace  Lesson
{
    public class Lesson
    {
        static decimal creditSum(decimal Sum, int percent)
        {
            if (Sum > 1000000)
                percent -= 2;
            decimal percentSum = ((Sum / 100) * percent );
            return percentSum;
        }

        public static void Main(string [] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            System.Console.WriteLine("Добро пожаловать в <WORLD BANK!> ");
            System.Console.WriteLine("Выберите вид кредита для себя:");
            Console.ForegroundColor = ConsoleColor.White;
            string[] credit = new string[3];
            credit[0] = "mortgage 15%";
            credit[1] = "consumer 27%";
            credit[2] = "auto 35%";
            for (int i = 0; i < credit.Length; i++)
            {
                System.Console.WriteLine(credit[i].Trim());
            }

            
            decimal res1 = creditSum(10000000, 10);
            decimal res2 = creditSum(10000000, 15);
            decimal res3 = creditSum(10000000, 17);
            Console.WriteLine(res1+"\n"+res2+"\n"+res3);



        }
    }
}