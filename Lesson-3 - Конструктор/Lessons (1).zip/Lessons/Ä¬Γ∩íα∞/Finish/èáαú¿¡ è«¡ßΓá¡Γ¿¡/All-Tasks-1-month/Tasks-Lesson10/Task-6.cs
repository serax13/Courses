using System;
namespace Task_6
{
	public class Task_6
	{
		public static void Main(string [] tasks)
		{
			string Simbols;
			Console.WriteLine("Введите цифры через запятую:");
			Simbols=Console.ReadLine();
			int Summ=0;
			string[] Text=Simbols.Split(',');
			int SimbolsCount=Text.Length;
			Console.WriteLine("Вы ввели "+SimbolsCount+" символов");
			for(int i=0;i<SimbolsCount;i++)
			{
				Console.Write(Text[i]+" ");
				Summ+=Convert.ToInt32(Text[i].Trim());
			}
			Console.WriteLine("\nСумма введенных чисел равна "+Summ);
			Console.ReadKey();
		}
	}
}