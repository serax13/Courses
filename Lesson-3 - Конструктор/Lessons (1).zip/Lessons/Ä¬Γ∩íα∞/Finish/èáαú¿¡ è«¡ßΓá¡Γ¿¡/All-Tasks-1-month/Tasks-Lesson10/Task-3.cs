using System;
namespace Task_3
{
	public class Task_3
	{
		public static void Main(string [] tasks)
		{
			decimal [] Chisla = new decimal[10];
			decimal Summ=0;
		
			for(int i=0;i<10;i++)
			{
				Chisla[i]=i*5/3;
				Console.WriteLine("Число №"+i+" ="+Chisla[i]);
				Summ+=Chisla[i];
				
			}
			Console.WriteLine("Сумма чисел = "+Summ);
			Console.ReadKey();
		}
	}
}