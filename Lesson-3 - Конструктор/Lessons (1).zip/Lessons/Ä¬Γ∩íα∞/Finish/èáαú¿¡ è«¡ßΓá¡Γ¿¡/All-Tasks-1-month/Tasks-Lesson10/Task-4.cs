using System;
namespace Task_4
{
	public class Task_4
	{
		public static void Main(string [] tasks)
		{
			string Simbols;
			Console.WriteLine("Введите буквы через запятую:");
			Simbols=Console.ReadLine();
			string[] Text=Simbols.Split(',');
			int SimbolsCount=Text.Length;
			Console.WriteLine("Вы ввели "+SimbolsCount+" символов");
			int Count=1;
			for(int i=0;i<SimbolsCount;i++)
			{
				Console.Write(Text[i]);
				if(Count==4)
				{
					Console.Write("\n");
					Count=0;
				}
				Count++;
			}
			Console.ReadKey();
		}
	}
}