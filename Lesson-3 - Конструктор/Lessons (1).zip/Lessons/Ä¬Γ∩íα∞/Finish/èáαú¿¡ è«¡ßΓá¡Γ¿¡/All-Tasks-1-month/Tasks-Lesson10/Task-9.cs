using System;
namespace Task_9
{
	public class Task_9
	{
		public static void Main(string [] tasks)
		{
			for(int i=10;i>=0;i--)
			{
				Console.Write(i+" ");
			}
			Console.ReadKey();
		}
	}
}