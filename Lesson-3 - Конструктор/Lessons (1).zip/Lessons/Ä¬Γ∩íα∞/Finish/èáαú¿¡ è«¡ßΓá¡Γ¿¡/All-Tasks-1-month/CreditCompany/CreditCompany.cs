using System;
namespace Credit
{
	public class Credit
	{
		static decimal CalcCredit(decimal SummCredit=0,decimal Percent=0)
		{
			if(SummCredit>1000000)
			{
				Percent-=2;
			}
			return ((SummCredit/100)*Percent)/12;
			
		}
		public static void Main(string [] tasks)
		{
		 string [] ListOfCredit = new string[3];//список кредитов
		 decimal SummCredit=0;
		 
		 ListOfCredit[0]="1 - 15% годовых вид кредита 'ИПОТЕЧНЫЙ'";
		 ListOfCredit[1]="2 - 27% годовых вид кредита 'ПОТРЕБИТЕЛЬСКИЙ'";
		 ListOfCredit[2]="3 - 35% годовых вид кредита 'АВТОКРЕДИТ'";
		 for(int i=0;i<3;i++)
		 {
			 Console.WriteLine(ListOfCredit[i]);
		 }
		 Console.WriteLine("Выберите вид кредита, для этого введите код ");
		 byte CheckChoise=0;
		 CheckChoise=Convert.ToByte(Console.ReadLine());
		 if(CheckChoise==1)
		 {
			 Console.WriteLine("Введите сумму кредита:");
			 SummCredit=Convert.ToDecimal(Console.ReadLine());
			 Console.WriteLine("Вы выбрали "+ListOfCredit[0].Split('-')[1]);
			 Console.WriteLine("Ваша ежемесячная оплата состовляет "+((SummCredit/12)+CalcCredit(SummCredit,15)));
			
		 }
		 else if(CheckChoise==2)
		 {
			  Console.WriteLine("Введите сумму кредита:");
			 SummCredit=Convert.ToDecimal(Console.ReadLine());
			 Console.WriteLine("Вы выбрали "+ListOfCredit[1].Split('-')[1]);
			 Console.WriteLine("Ваша ежемесячная оплата состовляет "+((SummCredit/12)+CalcCredit(SummCredit,27)));
		 }
		 else if(CheckChoise==3)
		 {
			  Console.WriteLine("Введите сумму кредита:");
			 SummCredit=Convert.ToDecimal(Console.ReadLine());
			 Console.WriteLine("Вы выбрали "+ListOfCredit[2].Split('-')[1]);
			 Console.WriteLine("Ваша ежемесячная оплата состовляет "+((SummCredit/12)+CalcCredit(SummCredit,35)));
		 }
			Console.ReadKey();
		}
	}
}