using System;
namespace Terminal
{
	public class Terminal
	{
		public static void Main(string [] term)
		{
			decimal MoneyPay=0; // переменная  для ввода суммы
			string PhoneNumber="tel"; // переменная для ввода телефона
			string CheckChoise="0";//переменная для ввода вариантов
			byte LegenthNum=0;//переменная для хранения количества символов
			int Month=0;//переменная для ввода количество месяцев
			string KeyWord="";// переменная для хранения ключевого слова
			string KeysWordsGames ="онлайн/игра/игры/WorldOfTanks/Warface/Kindoms/Strike/PrimeWorld";// 8 ключей по теме игры
			string KeysWordsComunalServices = "ком/услуги/услуга/комуслуги/газ/домофон/отопление/предоплата";// 8 ключей по теме ком услуги
			string[] opers= new string[10];
			opers[0]="077";
			opers[1]="070";
			opers[2]="055";
			while(1!=2)//простое зацикливание
			{
				Console.ForegroundColor = ConsoleColor.Green; 
				Console.WriteLine("Для проверки задания вывел доступные ключи поиска");
				Console.WriteLine("Тема 'ИГРЫ': "+KeysWordsGames+"\n");
				Console.WriteLine("Тема 'Ком.услуги': "+KeysWordsComunalServices+"\n");
				Console.ResetColor(); 
			Console.WriteLine("Здравствуйте, для оплаты услуг, введите ключ для поиска>>");
			KeyWord=Console.ReadLine();
			for(int i=0;i<8;i++)//цикл для поиска существующего ключа
			{
				if(KeysWordsGames.Split('/')[i]==KeyWord)
				{
					CheckChoise="1";
				}
				else if(KeysWordsComunalServices.Split('/')[i]==KeyWord)
				{
					CheckChoise="2";
				}
			}
			if(CheckChoise=="1")//код отвечающий за выполнения услуг для оплаты игр
			{
				Console.WriteLine("Выберите игру из предложенных вариантов\n и вводите соответствующие номера игры:");
				Console.WriteLine("1-WorldOfTanks 50сом\n2-Warface 200сом\n3-Kindoms 500сом\n4-TechMagic 750сом\n5-Strike 835сом\n6-PrimeWorld 1500сом");
				CheckChoise=Console.ReadLine();
				switch(CheckChoise)
				{
					case "1":
					Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay==50)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
					}
					else if(MoneyPay>50 &&MoneyPay<5001)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + 50+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-50)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LegenthNum=Convert.ToByte(PhoneNumber.Length);
			            if(LegenthNum==10||LegenthNum==13)
						{
							if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-50)+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
					   }
			            else
			            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				            Console.WriteLine("Данный оператор не существует!");
							Console.ResetColor(); 
			            }
						
						
					}
					else if(MoneyPay>5000||MoneyPay<50)
					{ 
			           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor(); 
						//цвет
					}
					break;
					
					case "2":
						Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay==200)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
					}
					else if(MoneyPay>200 &&MoneyPay<5001)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + 200+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-200)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LegenthNum=Convert.ToByte(PhoneNumber.Length);
			            if(LegenthNum==10||LegenthNum==13)
						{
							if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-200)+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
					   }
			            else
			            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				            Console.WriteLine("Данный оператор не существует!");
							Console.ResetColor(); 
			            }
						
						
					}
					else if(MoneyPay>5000||MoneyPay<200)
					{ 
			           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor(); 
						//цвет
					}
					break;
					
					case "3":
						Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay==500)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
					}
					else if(MoneyPay>500 &&MoneyPay<5001)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + 500+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-500)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LegenthNum=Convert.ToByte(PhoneNumber.Length);
			            if(LegenthNum==10||LegenthNum==13)
						{
							if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-500)+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
					   }
			            else
			            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				            Console.WriteLine("Данный оператор не существует!");
							Console.ResetColor(); 
			            }
						
						
					}
					else if(MoneyPay>5000||MoneyPay<500)
					{ 
			           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor(); 
						//цвет
					}
					break;
					
					case "4":
						Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay==750)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
					}
					else if(MoneyPay>750 &&MoneyPay<5001)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + 750+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-750)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LegenthNum=Convert.ToByte(PhoneNumber.Length);
			            if(LegenthNum==10||LegenthNum==13)
						{
							if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-750)+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
					   }
			            else
			            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				            Console.WriteLine("Данный оператор не существует!");
							Console.ResetColor(); 
			            }
						
						
					}
					else if(MoneyPay>5000||MoneyPay<750)
					{ 
			           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor(); 
						//цвет
					}
					break;
					
					case "5":
						Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay==835)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
					}
					else if(MoneyPay>835 &&MoneyPay<5001)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + 835+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-835)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LegenthNum=Convert.ToByte(PhoneNumber.Length);
			            if(LegenthNum==10||LegenthNum==13)
						{
							if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-835)+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
					   }
			            else
			            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				            Console.WriteLine("Данный оператор не существует!");
							Console.ResetColor(); 
			            }
						
						
					}
					else if(MoneyPay>5000||MoneyPay<835)
					{ 
			           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor(); 
						//цвет
					}
					break;
					
					case "6":
						Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay==1500)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
					}
					else if(MoneyPay>1500 &&MoneyPay<5001)
					{
						Console.WriteLine("Платеж прошел успешно на сумму " + 1500+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-1500)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LegenthNum=Convert.ToByte(PhoneNumber.Length);
			            if(LegenthNum==10||LegenthNum==13)
						{
							if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-1500)+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
					   }
			            else
			            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				            Console.WriteLine("Данный оператор не существует!");
							Console.ResetColor(); 
			            }
						
						
					}
					else if(MoneyPay>5000||MoneyPay<1500)
					{ 
			           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor(); 
						//цвет
					}
					break;
					
					default:
						Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Команда не распознана!!");
						Console.ResetColor(); 
					break;
					
				}
				
			}
			else if(CheckChoise=="2") //код отвечающий за выполнения услуг для оплаты комуналки
			{
				Console.WriteLine("Выберите следующие услуги по платежам:");
				Console.WriteLine("1 - Домофон 100сом\n2 - Газ\n3 - Отопление");
				CheckChoise=Console.ReadLine();
				switch(CheckChoise)
				{
					case "3"://Отопление
					Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay<=0||MoneyPay>5000)
					{
						Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма оплаты!!");
						Console.ResetColor(); 
						//Цвет
					}
					else
					{
						Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
					}
					break;
					case "2"://Газ
					Console.WriteLine("Введите сумму оплаты>>");
					MoneyPay=Convert.ToDecimal(Console.ReadLine());
					if(MoneyPay<=0||MoneyPay>5000)
					{   
				        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма оплаты!!");
						Console.ResetColor(); 
						//Цвет
					}
					else
					{
						Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
					}
					break;
					case "1"://Домофон
					Console.WriteLine("Выберите следующий вариант оплаты>>");
					Console.WriteLine("Оплата за месяц - 1\nПредоплата - 2");
					CheckChoise=Console.ReadLine();
					if(CheckChoise=="1")
					{
						Console.WriteLine("Введите сумму оплаты равной 100 сом>>");
					    MoneyPay=Convert.ToDecimal(Console.ReadLine());
						if(MoneyPay!=100)
						{
							Console.WriteLine("Сумма оплаты должна быть равной 100сом!!");
						}
						else
						{
							Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
							
						}
					}
					else if(CheckChoise=="2")
					{   
				        Console.WriteLine("Введите количество месяцев>>");
				        Month=Convert.ToInt32(Console.ReadLine());
						int CheckMoney = Month*100;
						Console.WriteLine("Введите сумму оплаты равной "+CheckMoney+" сом");
					    MoneyPay=Convert.ToDecimal(Console.ReadLine());
						if(MoneyPay>CheckMoney||MoneyPay<CheckMoney)
						{
							Console.ForegroundColor = ConsoleColor.Red; 
							Console.WriteLine("Сумма оплаты должна быть равной "+CheckMoney+" сом!!");
							 Console.ResetColor(); 
						}
						else
						{
							Console.WriteLine("Платеж на сумму "+CheckMoney+" сом успешно завершен");
							CheckMoney=(Month*100)/100*7;
							Console.WriteLine("Для вывода бонуса в виде единиц введите ваш телефон>>");
							PhoneNumber=Console.ReadLine();
						    LegenthNum=Convert.ToByte(PhoneNumber.Length);
			                if(LegenthNum==10||LegenthNum==13)
						    {
				                if(PhoneNumber.Substring(0,3)==opers[0] || PhoneNumber.Substring(0,3)==opers[1]|| PhoneNumber.Substring(0,3)==opers[2])
							{
				                Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+CheckMoney+" сом");
							}
							else
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
							    Console.ResetColor(); 
							}
			                }
			                else
			                {//цвет
						        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
								Console.ResetColor(); 
			                }
							
							
						}
						
					}
					break;
					default:
						Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Команда не распознана!!");
						Console.ResetColor(); 
					break;
				}
			}
			else //код вывода ошибки
			{   
		        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				Console.WriteLine("Услуга не найдена, повторите еще раз!!");
                Console.ResetColor(); 
			}
			Console.ReadKey();
			
			}
			
		}
		
	}
		
		

}