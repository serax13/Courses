using System;
namespace Task_5
{
	public class Task_5
	{
		static void GetSexHuman(char SexHuman)
		{
			if(SexHuman=='М'|| SexHuman=='м')
			{
				Console.WriteLine("Ваш пол мужчина");
			}
			else if(SexHuman=='Ж'||SexHuman=='ж')
			{
				Console.WriteLine("Ваш пол женщина");
			}
			else
			{
				Console.WriteLine("Пол человека не определен!!");
			}
			
		}
		public static void Main(string [] tasks)
		{
			char SexHuman;
			Console.WriteLine("Введите букву ");
			SexHuman=Convert.ToChar(Console.ReadLine());
			GetSexHuman(SexHuman);
			Console.ReadKey();
		}
	}
}