using System;
namespace Task_4
{
	public class Task_4
	{
		static decimal PercentSumm(decimal Summ=0,decimal Percent=0)
		{
			return (Summ/100)*Percent;
		}
		public static void Main(string [] tasks)
		{
			decimal Summ=0,Percent=0;
			Console.WriteLine("Введите сумму>>");
			Summ=Convert.ToDecimal(Console.ReadLine());
			Console.WriteLine("Введите процент>>");
			Percent=Convert.ToDecimal(Console.ReadLine());
			Console.WriteLine("Процент от суммы "+Summ+" состовляет "+PercentSumm(Summ,Percent)+" процентов");
			Console.ReadKey();
		}
	}
}