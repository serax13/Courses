using System;
namespace MARSEL{
	public class task_6{
		public static void Main(){
			Console.WriteLine("\tEnter numbers by using comma:");
			string number = Console.ReadLine();
			string [] ListNumber = number.Split(',');
			int count = 0;
			for(int i = 0;i <= ListNumber.Length-1;i++)
			{
				Console.WriteLine(ListNumber[i]);
				count++;
			}
			Console.WriteLine("Quantity of Numbers is: " + count);
		}
	}
}