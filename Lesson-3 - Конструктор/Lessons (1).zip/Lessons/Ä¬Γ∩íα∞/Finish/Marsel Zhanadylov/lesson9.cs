using System;
using System.Threading;
namespace helloapp{
	public class lesson9{
		public static void Main () {
			
			Console.WriteLine("\tList Of Products.");
			
			string [] ProductsList = new string [15];
			ProductsList [0] = "0-Чай | 120 сом";
			ProductsList [1] = "1-Сахар | 50 сом";
			ProductsList [2] = "2-Хлеб | 20 сом";
			ProductsList [3] = "3-Молоко | 20 сом";
			ProductsList [4] = "4-Сгущенка | 60 сом";
			ProductsList [5] = "5-Сметана | 48 сом";
			ProductsList [6] = "6-Колбаса | 130 сом";
			ProductsList [7] = "7-Мясо | 520 сом";
			ProductsList [8] = "8-Творог | 70 сом";
			ProductsList [9] = "9-Конфеты | 140 сом";
			ProductsList [10] = "10-Курица | 320 сом";
			ProductsList [11] = "11-Рись | 85 сом";
			ProductsList [12] = "12-Гречка | 80 сом";
			ProductsList [13] = "13-Мед | 450 сом";
			ProductsList [14] = "14-Макароны | 90 сом";
			
			Console.WriteLine();
			
			for(int i = 0;i <= 14;i++)
			{
				Console.WriteLine(ProductsList[i]);
			}
			Console.WriteLine();
			Console.WriteLine("Choose Products with number and comma please.");
			string numbers = Console.ReadLine();
			string [] SelectedProduct = numbers.Split(',');
			int NumbersCount = SelectedProduct.Length;
			
			Console.WriteLine();
			decimal total =0;
			for(int i = 0;i <= NumbersCount-1;i++)
			{
				string numbers2 = SelectedProduct[i];
				int index = Convert.ToInt32(numbers2);
				string ProductResult = ProductsList[index];
				Console.WriteLine(ProductResult);
				string SelectedProducts = ProductResult.Split('|')[1];
				total = total + Convert.ToDecimal(SelectedProducts.Replace("сом","").Trim());
			}
			Console.ForegroundColor = ConsoleColor.Cyan;
			Console.Clear();
			Console.WriteLine("\tPlease wait..."); 
			for(int i = 1;i <= 20;i++)
			{
				Thread.Sleep(200);
				Console.Write("*");
			}
			Console.ResetColor();
			Console.WriteLine("\n\tTotal sum to pay " + total + " сом.");
			
			Console.WriteLine("\n\tPlease enter your money.");
			decimal sum = Convert.ToDecimal(Console.ReadLine());
    		if(sum == total)
		    {
			 Console.WriteLine("Thank you for making a shop");
		 	}
			else if (sum > total)
			{
				decimal result2 = sum - total;
				Console.WriteLine("Thank you for making a shop, here's your change " + result2 );
			}
			else if (sum < total) 
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("Sorry,there isn't enough money!!!");
				Console.ResetColor();
			}		 
		}
	}
}
