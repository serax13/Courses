using System;
namespace MARSEL{
	public class task_2{
		public static void Main(){
			string [] alphabet = {"a ","b ","c ","d ","e ","f ","j ","h ","i ","g ","k ","l ","m ","n ","o ","p ","q ","r ","s ","t ","u ","v ","w ","x ","y ","z\n"};
			
			int n = 1;
			for(int i = 0; i<=alphabet.Length-1; i++)
			{
				Console.ForegroundColor = ConsoleColor.Cyan;
				Console.Write(alphabet[i].ToUpper());
				Console.ResetColor();
				n++;
				if(n > 5)
				{
					n = 1;
					Console.WriteLine("\n");
				}
			}
			}
		}
	}
