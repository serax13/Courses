using System;
namespace helloapp
{
    public class Terminal1
    {
        public static void Main(string[] args)
        {
            
            int Service = 0;
            int ChoiceOfGame =0;
            int Games = 0;
            decimal SummOfGame;
            decimal ResultSummOfGame;
            string PhoneNumber;
            int MunicipalServices;
            int Intercom;
            decimal SummOfIntercom;
            int NumberOfMonth;
            decimal Bonus;
            decimal SummOfIntercomResult;

            string[] Operators = { "055", "077", "070" };
            string[] NameOfOperators = { "MegaCom", "BeeLine", " Оператора - O " };

            string[] Services = new string[2];
            {
                Services[0] = "1-оплата игр (game)";
                Services[1] = "2-оплата за ком услуги (service)";
            }
            string[] GamesList =
            {
                "1-Танки 50 сом",
                "2-Warface 200 сом",
                "3-Королевство 500 сом",
                "4-Техномагия 750 сом",
                "5-Strife 835 сом",
                "6-Prime World 1500 сом"
            };
            Console.WriteLine("\tПоиск");
            string textSearch = Console.ReadLine();
            for (int i = 0; i <= Services.Length - 1; i++)
            {
                if (Services[i].Contains(textSearch.Trim().ToLower()) == true)
                {
                    if (i == 0)
                    {
                        Games = 1;
                        Console.WriteLine(Services[i]);
                        textSearch = Services[i];
                    }
                    if (i == 1)
                    {
                        Service = 2;
                        Console.WriteLine(Services[i]);
                        textSearch = Services[i];
                    }
                }
            }
            Console.Clear();
            Console.WriteLine(textSearch);

            if (Games==1)
            {
                Console.WriteLine("Выберите игру: \n");
                for (int j = 0; j < GamesList.Length; j++)
                {
                    Console.WriteLine(GamesList[j]);
                }
                ChoiceOfGame = Convert.ToInt32(Console.ReadLine());
                if (ChoiceOfGame == 1)
                {
                    Console.WriteLine("Танки 50 сом");
                    Console.WriteLine("\tВыберите сумму оплаты:");
                    SummOfGame = Convert.ToDecimal(Console.ReadLine());
                    if (SummOfGame > 0 && SummOfGame < 5000)
					{
						if (SummOfGame == 50)
						{
							Console.WriteLine("Платеж успешно осуществлен на сумму " + SummOfGame + " сомов");
						}
						if (SummOfGame > 50)
						{
							ResultSummOfGame = SummOfGame - 50;
							Console.WriteLine("Платеж прошел успешно на сумму " + 50 + " из " + SummOfGame + " сом, для возврата части суммы " + ResultSummOfGame + " сом введите номер телефона");
							Console.WriteLine("\tВведите номер телефона");
							PhoneNumber = Convert.ToString(Console.ReadLine());
							if (PhoneNumber.Length == 10)
							{
								for (int oper = 0; oper < 3; oper++)
								{
									if (PhoneNumber.StartsWith(Operators[oper]) == true)
									{
										Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + ResultSummOfGame + " сом");
										break;
									}
								}
							}
						}
                        if (SummOfGame < 50)
						{
							ResultSummOfGame = 50 - SummOfGame;
							Console.WriteLine("из за недоздачи денежных средств в размере " + ResultSummOfGame + " сом, сумма которую вы внесли в размере " + SummOfGame + " сом будет начислена в ваш номер телефона");
							Console.WriteLine("\tВведите номер телефона:");
							PhoneNumber = Convert.ToString(Console.ReadLine());
							if (PhoneNumber.Length == 10)
							{
								for (int oper = 0; oper < 3; oper++)
								{
									if (PhoneNumber.StartsWith(Operators[oper]) == true)
									{
										Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + SummOfGame + " сом");
										break;
									}
								}
							}
						}
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
                        Console.ResetColor();
                    }
                  
                }// конец кода 1 игры
                if (ChoiceOfGame == 2)   // старт кода 2 игры
                {
                    Console.WriteLine("WarFace 200 сом");
                    Console.WriteLine("\tВыберите сумму оплаты:");
                    SummOfGame = Convert.ToDecimal(Console.ReadLine());
                    if (SummOfGame > 0 && SummOfGame < 5000)
                    {
                        if (SummOfGame == 200)
                        {
                            Console.WriteLine("Платеж успешно осуществлен на сумму " + SummOfGame + " сомов");
                        }
                        if (SummOfGame > 200)
                        {
                            ResultSummOfGame = SummOfGame - 200;
                            Console.WriteLine("Платеж прошел успешно на сумму " + 200 + " из " + SummOfGame + " сом, для возврата части суммы " + ResultSummOfGame + " сом введите номер телефона");
                            Console.WriteLine("\tВведите номер телефона");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + ResultSummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                        if (SummOfGame < 200)
                        {
                            ResultSummOfGame = 200 - SummOfGame;
                            Console.WriteLine("из за недоздачи денежных средств в размере" + ResultSummOfGame + " сом, сумма которую вы внесли в размере " + SummOfGame + " сом будет начислена в ваш номер телефона");
                            Console.WriteLine("\tВведите номер телефона:");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + SummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
                        Console.ResetColor();
                    }
                }  // конец кода 2 игры

                if (ChoiceOfGame == 3)   // старт кода 3 игры
                {
                    Console.WriteLine("Королество 500 сом");
                    Console.WriteLine("\tВыберите сумму оплаты:");
                    SummOfGame = Convert.ToDecimal(Console.ReadLine());
                    if (SummOfGame > 0 && SummOfGame < 5000)
                    {
                        if (SummOfGame == 500)
                        {
                            Console.WriteLine("Платеж успешно осуществлен на сумму " + SummOfGame + " сомов");
                        }
                        if (SummOfGame > 500)
                        {
                            ResultSummOfGame = SummOfGame - 500;
                            Console.WriteLine("Платеж прошел успешно на сумму " + 500 + " из " + SummOfGame + " сом, для возврата части суммы " + ResultSummOfGame + " сом введите номер телефона");
                            Console.WriteLine("\tВведите номер телефона");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + ResultSummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                        if (SummOfGame < 500)
                        {
                            ResultSummOfGame = 500 - SummOfGame;
                            Console.WriteLine("из за недоздачи денежных средств в размере " + ResultSummOfGame + " сом, сумма которую вы внесли в размере " + SummOfGame + " сом будет начислена в ваш номер телефона");
                            Console.WriteLine("\tВведите номер телефона:");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + SummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
                        Console.ResetColor();
                    }
                }  // конец кода 3 игры

                if (ChoiceOfGame == 4)   // старт кода 4 игры
                {
                    Console.WriteLine("Техномагия 750 сом");
                    Console.WriteLine("\tВыберите сумму оплаты:");
                    SummOfGame = Convert.ToDecimal(Console.ReadLine());
                    if (SummOfGame > 0 && SummOfGame < 5000)
                    {
                        if (SummOfGame == 750)
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Платеж успешно осуществлен на сумму " + SummOfGame + " сомов");
                            Console.ResetColor();
                        }
                        if (SummOfGame > 750)
                        {
                            ResultSummOfGame = SummOfGame - 750;
                            Console.WriteLine("Платеж прошел успешно на сумму " + 750 + " из " + SummOfGame + " сом, для возврата части суммы " + ResultSummOfGame + " сом введите номер телефона");
                            Console.WriteLine("\tВведите номер телефона");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + ResultSummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                        if (SummOfGame < 750)
                        {
                            ResultSummOfGame = 750 - SummOfGame;
                            Console.WriteLine("из за недоздачи денежных средств в размере " + ResultSummOfGame + " сом, сумма которую вы внесли в размере " + SummOfGame + " сом будет начислена в ваш номер телефона");
                            Console.WriteLine("\tВведите номер телефона:");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + SummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
                        Console.ResetColor();
                    }
                } // конец кода 4 игры

                if (ChoiceOfGame == 5)   // старт кода 5 игры
                {
                    Console.WriteLine("Strife 835 сом");
                    Console.WriteLine("\tВыберите сумму оплаты:");
                    SummOfGame = Convert.ToDecimal(Console.ReadLine());
                    if (SummOfGame > 0 && SummOfGame < 5000)
                    {
                        if (SummOfGame == 835)
                        {
                            Console.WriteLine("Платеж успешно осуществлен на сумму " + SummOfGame + " сомов");
                        }
                        if (SummOfGame > 835)
                        {
                            ResultSummOfGame = SummOfGame - 835;
                            Console.WriteLine("Платеж прошел успешно на сумму " + 835 + " из " + SummOfGame + " сом, для возврата части суммы " + ResultSummOfGame + " сом введите номер телефона");
                            Console.WriteLine("\tВведите номер телефона");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + ResultSummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                        if (SummOfGame < 835)
                        {
                            ResultSummOfGame = 835 - SummOfGame;
                            Console.WriteLine("из за недоздачи денежных средств в размере " + ResultSummOfGame + " сом, сумма которую вы внесли в размере " + SummOfGame + " сом будет начислена в ваш номер телефона");
                            Console.WriteLine("\tВведите номер телефона:");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + SummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
                        Console.ResetColor();
                    }
                }  // конец кода 5 игры

                if (ChoiceOfGame == 6)   // старт кода 6 игры
                {
                    Console.WriteLine("Prime World 1500 сом");
                    Console.WriteLine("\tВыберите сумму оплаты:");
                    SummOfGame = Convert.ToDecimal(Console.ReadLine());
                    if (SummOfGame > 0 && SummOfGame < 5000)
                    {
                        if (SummOfGame == 1500)
                        {
                            Console.WriteLine("Платеж успешно осуществлен на сумму " + SummOfGame + " сомов");
                        }
                        if (SummOfGame > 1500)
                        {
                            ResultSummOfGame = SummOfGame - 1500;
                            Console.WriteLine("Платеж прошел успешно на сумму " + 1500 + " из " + SummOfGame + " сом, для возврата части суммы " + ResultSummOfGame + " сом введите номер телефона");
                            Console.WriteLine("\tВведите номер телефона");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + ResultSummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                        if (SummOfGame < 1500)
                        {
                            ResultSummOfGame = 1500 - SummOfGame;
                            Console.WriteLine("из за недоздачи денежных средств в размере " + ResultSummOfGame + " сом, сумма которую вы внесли в размере " + SummOfGame + " сом будет начислена в ваш номер телефона");
                            Console.WriteLine("\tВведите номер телефона:");
                            PhoneNumber = Convert.ToString(Console.ReadLine());
                            if (PhoneNumber.Length == 10)
                            {
                                for (int oper = 0; oper < 3; oper++)
                                {
                                    if (PhoneNumber.StartsWith(Operators[oper]) == true)
                                    {
                                        Console.WriteLine("Ваш баланс " + NameOfOperators[oper] + " пополнен на " + SummOfGame + " сом");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
                        Console.ResetColor();
                    }
                }  // конец кода 6 игры
            }
            if (Service == 2)
            {

                Console.WriteLine("\tВыберите ком услугу: \n1-Домофон 100 сом \n 2-Газ 100 сом \n  3-Отопление 100 сом");
                MunicipalServices = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                if (MunicipalServices == 1) // старт кода 1 ком услуги
                {
                    Console.WriteLine("\tВыберите способ оплаты: \n1-Оплата за месяц \n 2-Предоплата");
                    Intercom = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();
                    if (Intercom == 1)
                    {
                        Console.WriteLine("\tВведите оплату за домофон в размере 100 сом");
                        SummOfIntercom = Convert.ToDecimal(Console.ReadLine());
                        if (SummOfIntercom == 100)
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Оплата прошла успешно на сумму " + SummOfIntercom + " сом");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Cумма оплаты 100 сом!");
                            Console.ResetColor();
                        }
                    }

                    if (Intercom == 2)
                    {
                        Console.WriteLine("\tВведите количество месяца");
                        NumberOfMonth = Convert.ToInt32(Console.ReadLine());
                        SummOfIntercom = 100;
                        Bonus = ((NumberOfMonth * SummOfIntercom) / 100) * 7;
                        SummOfIntercomResult = NumberOfMonth * SummOfIntercom;
                        Console.WriteLine("Оплата прошла успешно на сумму " + SummOfIntercomResult + " сом, а для получения бонуса в размере (7%): " + Bonus + " сом введите номер телефона");
                        Console.WriteLine("\tВведите номер телефона:");
                        PhoneNumber = Convert.ToString(Console.ReadLine());
                        if (PhoneNumber.Trim().Length == 10)
                        {
                            if (PhoneNumber.StartsWith("055") == true)
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;
                                Console.WriteLine("Ваш баланс Мегаком пополнен на " + Bonus + " сом");
                            }
                            if (PhoneNumber.StartsWith("077") == true)
                            {
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("Ваш баланс Билайн пополнен на " + Bonus + " сом");
                            }
                            if (PhoneNumber.StartsWith("070") == true)
                            {
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("Ваш баланс О пополнен на " + Bonus + " сом");
                            }
                        }
                    }
                } // конец кода 1 ком услуги

                if (MunicipalServices == 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\tИзвините данная услуга временна недоступна");
                    Console.ResetColor();
                }

                if (MunicipalServices == 3)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\tИзвините данная услуга временна недоступна");
                    Console.ResetColor();
                }
            }
            Console.ResetColor();
            Console.ReadKey();
        }
    }
}