using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
		static decimal PercStav(decimal x, decimal y)
		{
			if(x>=1000000)
			{
			decimal PercentSum=(((x/100)*(y-2))+x)/12;
			return PercentSum;
			}
			else
			{
				decimal PercentSum=(((x/100)*y)+x)/12;
			return PercentSum;
			}
		}
        public static void Main() 
        {	
			string[]interestRate={
				"1 - 15% - годовых вид кредита ипотечный",
				"2 - 27% - годовых вид кредита потребительский",
				"3 - 35% - годовых вид кредита авто кредит"};
			foreach(var listCred in interestRate)
            Console.WriteLine(listCred);
			decimal sumCredit=0;
			Console.WriteLine("Выберите вид кредита:");
			int numbCred=Convert.ToInt32(Console.ReadLine());
			if(numbCred==1)
			{
				Console.WriteLine("Вы выбрали "+interestRate[numbCred-1]+"\nВведите сумму кредита:");
				sumCredit = Convert.ToDecimal(Console.ReadLine());
				decimal Percent15 = 15; 
				decimal result = PercStav(sumCredit, Percent15);
				Console.WriteLine("Вы дали заявку для получения кредита на сумму - "+sumCredit+" c процентной ставкой "+Percent15+" ,ежемесячная сумма погашения составляет "+(result));
			}
			if(numbCred==2)
			{
				Console.WriteLine("Вы выбрали "+interestRate[numbCred-1]+"\nВведите сумму кредита:");
				sumCredit = Convert.ToDecimal(Console.ReadLine());
				decimal Percent27 = 27; 
				decimal result = PercStav(sumCredit, Percent27);
				Console.WriteLine("Вы дали заявку для получения кредита на сумму - "+sumCredit+" c процентной ставкой "+Percent27+" ,ежемесячная сумма погашения составляет "+(result));
			}
			if(numbCred==3)
			{
				Console.WriteLine("Вы выбрали "+interestRate[numbCred-1]+"\nВведите сумму кредита:");
				sumCredit = Convert.ToDecimal(Console.ReadLine());
				decimal Percent35 = 35; 
				decimal result = PercStav(sumCredit, Percent35);
				Console.WriteLine("Вы дали заявку для получения кредита на сумму - "+sumCredit+" c процентной ставкой "+Percent35+" ,ежемесячная сумма погашения составляет "+(result));
			}
        }
    }
}