using System;

namespace TZ
{
	public static class tz5
	{
		static void NumbersWords (byte count)
		{
			string [] Numbers = new string[10];
			Numbers[0] = "1- Один";
			Numbers[1] = "2- Два";
			Numbers[2] = "3- Три";
			Numbers[3] = "4- Четыре";
			Numbers[4] = "5- Пять";
			Numbers[5] = "6- Шесть";
			Numbers[6] = "7- Семь";
			Numbers[7] = "8- Восемь";
			Numbers[8] = "9- Девять";
			Numbers[9] = "10- Десять";
			for(int i=0;i<=count-1;i++)
				Console.WriteLine(Numbers[i]);
		}
		public static void Main()
		{
			byte Number=10;
			NumbersWords(Number);
		}
	}
}