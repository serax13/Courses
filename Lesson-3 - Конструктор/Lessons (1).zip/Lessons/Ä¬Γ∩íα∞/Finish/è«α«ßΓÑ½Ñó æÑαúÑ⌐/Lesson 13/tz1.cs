using System;

namespace tz
{
	public static class tz2810
	{
		static void NameAge(string Name, byte Age)
		{
			Console.WriteLine("Привет я "+Name+" мне "+Age+" лет через год мне исполнится "+(++Age));
		}
		public static void Main()
		{
			string Name = "Maxim";
			byte Age = 17;
			
			NameAge(Name,Age);
		}
	}
}