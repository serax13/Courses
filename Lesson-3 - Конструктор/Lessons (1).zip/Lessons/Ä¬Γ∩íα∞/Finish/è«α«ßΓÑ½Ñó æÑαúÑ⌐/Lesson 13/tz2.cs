using System;

namespace TZ
{
	public static class tz2
	{
		static void square()
		{
			int x =2;
			Console.WriteLine(x*x);
		}
		public static void Main()
		{
			square();
		}
	}
}