using System;

namespace TZ
{
	public static class tz3
	{
		static void cycle(long count)
		{
			long factor = 2;
			factor = factor*count;
			for(int i=1;i<=x;i++)
			{
				Console.WriteLine(i);
			}
		}
		public static void Main()
		{
			long Number=5;
			cycle(Number);
		}
	}
}