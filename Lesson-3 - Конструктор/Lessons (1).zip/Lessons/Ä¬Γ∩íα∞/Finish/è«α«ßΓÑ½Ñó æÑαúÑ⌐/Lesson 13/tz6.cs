using System;
using System.Threading;

namespace TZ
{
	public static class tz6
	{
		static void Stars (byte quantityStars,byte quantityLine)
		{
			
			for(int i=0;i<=quantityLine - 1;i++)
			{
				for(int ii=0;ii<=quantityStars - 1;ii++)
					Console.Write("*");
				Console.WriteLine();
				Thread.Sleep(100);
			}
		}
		public static void Main()
		{
			byte quantityStars=15;
			byte quantityLine=3;
			Stars(quantityStars,quantityLine);
		}
	}
}