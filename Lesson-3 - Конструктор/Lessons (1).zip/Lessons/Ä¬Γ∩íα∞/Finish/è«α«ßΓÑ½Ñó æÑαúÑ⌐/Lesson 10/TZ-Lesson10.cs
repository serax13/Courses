using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {
        	Console.WriteLine("Введите колличество контактов: ");
        	int quantityContacts=Convert.ToInt32(Console.ReadLine());
			string[] contact = new string[quantityContacts];
			Console.WriteLine("Сначало Имя и через запятую номер");
			for(int i=0; i <= quantityContacts -1; i++)
			{
					Console.WriteLine("Введите Контакт ("+(i+1)+") ");
					contact[i] = Console.ReadLine();
			}
			Console.WriteLine("В телефонной книге сохр. "+quantityContacts+" номер.: ");
			foreach(var contactList in contact)
				Console.WriteLine("\t"+contactList);
			Console.WriteLine("Хотите позвонить? да/нет");
			string yesNo = Console.ReadLine().Trim().ToLower();
			if(yesNo=="да")
			{
				Console.WriteLine("Введите имя:");
				string seachContact=Console.ReadLine().Trim();
				for(int seachContactNumb=0;seachContactNumb<quantityContacts;seachContactNumb++)
				{
					if(seachContact.StartsWith(contact[seachContactNumb].Split(',')[0].Trim())==true)
					{
						Console.Write("Звонок "+contact[seachContactNumb].Replace(","," "));
						for(int load=0;load<3;load++)
						{
							Thread.Sleep(500);
							Console.Write(".");
						}
					}
					else
						Console.WriteLine("Контакт не найден");
				}
			}
			
			
        }
    }
}