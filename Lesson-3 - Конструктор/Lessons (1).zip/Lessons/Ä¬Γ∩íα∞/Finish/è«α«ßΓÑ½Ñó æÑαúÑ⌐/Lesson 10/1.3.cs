using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {
           decimal sum=0;
           decimal[]mass = {5.6M, 7.2M, 3.8M, 9.5M, 8.7M, 2.4M, 6.2M, 9.3M, 4.2M, 6.6M};
           int s = mass.Length;
           for(int i=0;i<s;i++)
           {
           	sum = sum+mass[i];
           }
           Console.WriteLine(sum);
        }
    }
}