using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {	for(int i = 10; i > 0; i--)
			{
				Console.Write(i+" ");
			}
        }
    }
}