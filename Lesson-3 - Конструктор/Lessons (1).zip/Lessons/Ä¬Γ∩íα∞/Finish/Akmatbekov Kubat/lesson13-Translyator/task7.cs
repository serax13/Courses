using System;

namespace task7
{
	public class task7
	{
		static void Translator(string word)
		{
			string EnChars = " ,A,B,V,G,D,E,E,J,Z,I,I,K,L,M,N,O,P,R,S,T,U,F,H,C,CH,SH,SH,Y,E,U,YA";
			string RuChars = " ,А,Б,В,Г,Д,Е,Ё,Ж,З,И,Й,К,Л,М,Н,О,П,Р,С,Т,У,Ф,Х,Ц,Ч,Ш,Щ,Ъ,Ы,Ь,Э,Ю,Я";
			string[] EnCharsList = EnChars.Split(',');
			string[] RuCharsList = RuChars.Split(',');
			int EnCharsCount = EnCharsList.Length;
			int RuCharsCount = RuCharsList.Length;
			word = word.ToUpper();
			char[] WordList = word.ToCharArray();
			int WordCount = word.Length;
			string[] WordListArr = new string[WordCount];
			for (int i=0; i<=WordCount-1; i++)
			{
				WordListArr[i] = Convert.ToString(WordList[i]);
			}
			for (int j=0; j<=WordCount-1; j++)
			{
				for (int i=0; i<=RuCharsCount-1; i++)
				{
					if (RuCharsList[i].Contains(WordListArr[j]) == true)
					{
						TranslatedChars = TranslatedChars.Replace(RuCharsList[i],EnCharsList[i]);
						Console.Write(TranslatedChars); 
					}
				}
			}
		}
		public static void Main ( string [] args)
		{
			Console.Clear();
			Console.WriteLine("Введите слово: ");
			string word = Console.ReadLine();
			Translator(word);
			Console.ReadLine();
		}
	}
}