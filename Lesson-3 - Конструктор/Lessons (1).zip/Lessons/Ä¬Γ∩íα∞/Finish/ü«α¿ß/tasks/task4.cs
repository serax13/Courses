using System;

namespace tasks
{
	public class task4
	{
		public static void Main(string [] agrs)
		{
      Console.WriteLine("Type in Letter using 'space' or ',' as a delimiter:");

      TypeLetters = Console.ReadLine();

      string[] SplitLetters = TypeLetters.Split(new Char [] {',' , ' '});

      for (int i = 0; i <= TypeLetters.Length(); i++)
      {
        
        Console.WriteLine(SplitLetters[i]);
      }

			Console.ReadKey();
		}
	}
}
