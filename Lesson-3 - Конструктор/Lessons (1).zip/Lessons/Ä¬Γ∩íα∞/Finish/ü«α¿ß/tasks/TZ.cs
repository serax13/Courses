using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
      //----create variable for array length
			Console.WriteLine("сколько контактов хотите сохранить?");
      int PHCount = Convert.ToInt32(Console.ReadLine());

      //----create array of phone numbers using loop
      Console.WriteLine("Введите Имена и Номера контактов.");
      string[] PhoneNumber = new string[PHCount];
      for (int i = 0; i <= PHCount-1; i++)
      {
        PhoneNumber[i] = Console.ReadLine().ToUpper();
      }

      //----display all saved phone numbers
      for (int i = 0; i <= PHCount-1; i++)
      {
        Console.WriteLine(PhoneNumber[i]);
      }

      //---create variable for call or no call choice
      Console.WriteLine("Хотите позвонить? Да/Нет");
      string Answer = Console.ReadLine();

      //----answer is yes
      if (Answer.Trim().ToUpper()=="ДА")
      {
        Console.Write("Введите имя: ");
        //---variable of name for searching in list
        string InputName = Console.ReadLine();
        //---loop for checking every element in array
        for (int i = 0; i <= PHCount-1; i++)
        {
          //---if name is in book show this
          if (PhoneNumber[i].Contains(InputName.Trim().ToUpper()))
          {
            Console.WriteLine("Вызов "+PhoneNumber[i]);
          }
        }
      }

      //---answer is no
      else if (Answer.Trim().ToUpper()=="НЕТ")
      {
        Console.WriteLine("Хорошо!");
      }
      //---any other case
      else
      {
        Console.WriteLine("Ошибочка!");
      }
			Console.ReadKey();
		}
	}
}
