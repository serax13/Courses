using System;

namespace tasks
{
  public class task9
  {
    public static void Main(string[] agrs)
    {
      // Create array of numbers
      int[] number = new int [10];
      number[0] = 1;
      number[1] = 2;
      number[2] = 3;
      number[3] = 4;
      number[4] = 5;
      number[5] = 6;
      number[6] = 7;
      number[7] = 8;
      number[8] = 9;
      number[9] = 10;

      // Display an array of numbers
      for (int i = 9; i >= 0; i--)
      {
        Console.Write(number[i]+" ");
      }

      Console.ReadKey();
    }
  }
}
