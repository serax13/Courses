using System;

namespace tasks
{
  public class task9
  {
    public static void Main(string[] agrs)
    {
      // visualize multiplication table
      for (int i = 1; i <= 9; i++)
      {
        for ( int j = 2; j <= 9; j++)
        {
          Console.Write("{0} x {1} = {2}", j, i, i*j);
          if (j > 8) Console.Write("\n");// switch to next row
          else Console.Write("  ");// spaces between columns
        }

      }

      Console.ReadKey();
    }
  }
}
