using System;

namespace tasks
{
  public class task6
  {
    public static void Main(string[] agrs)
    {
      Console.WriteLine("Type in any numbers from 1 to 10 (use ',' as a delimiter):");

      string input = Console.ReadLine();
      string[] numList = input.Split(',');

      Console.WriteLine("Array`s length is "+numList.Length);

      for (int i = 0; i <= numList.Length-1; i++)
      {
        Console.WriteLine(numList[i]);
      }


      Console.ReadKey();
    }
  }
}
