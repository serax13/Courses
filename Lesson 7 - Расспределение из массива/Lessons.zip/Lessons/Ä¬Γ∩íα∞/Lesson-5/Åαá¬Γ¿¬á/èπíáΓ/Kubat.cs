﻿using System;

namespace Kubat
{
	public class Kubat
	{
		public static void Main(string [] args)
		{
			Console.WriteLine("Введите переменную А: ");
			int var_a = Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Введите оператор: ");
			char oper = Convert.ToChar(Console.ReadLine());
			Console.WriteLine("Введите переменную B: ");
			int var_b = Convert.ToInt32(Console.ReadLine());
			if (oper == '+')
			{
				int rez = var_a+var_b;
				Console.WriteLine("Результат: " + rez);
			}
			if (oper == '-')
			{
				int rez = var_a-var_b;
				Console.WriteLine("Результат: " + rez);
			}
			if (oper == '*')
			{
				int rez = var_a*var_b;
				Console.WriteLine("Результат: " + rez);
			}
			if (oper == '/')
			{
				int rez = var_a/var_b;
				Console.WriteLine("Результат: " + rez);
			}
			Console.ReadKey();
		}
	}
}