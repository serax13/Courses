using System;

namespace L
{
	public class L
	{
		public static void Main(string [] args)
		{	
			decimal som;
			// Вывести текст на консоль 
			Console.WriteLine("Введите деньги :");
			som = Convert.ToDecimal (Console.ReadLine());
			if(som<20)
			{
				Console.WriteLine("Банкомат не принимает банкноты меньше 20");
				
			}
			else if (som>=20 && som<=100)
			{
				som-=5;
				Console.WriteLine ("На баланс поступило "+som);
			}
			else if (som>=101 && som<=500)
			{
				som-=10;
				Console.WriteLine ("На баланс поступило "+som);
			}
			else if (som>=501)
			{
				som-=20;
				Console.WriteLine ("На баланс поступило "+som);
			}
			
			
			Console.ReadKey();
		}
	}
}