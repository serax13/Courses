using System;
using System.Threading;

namespace Lesson11
{
	public class Lesson11
	{		
		// Метод с параметором
		static void CW(string text)
		{
			Console.WriteLine(text);
		}
		
		// Метод возвращает сумму 2 чисел
		static decimal Plus(decimal x, decimal y)
		{
			return x + y;
		}
		
		// Метод возвращает строку
		static string NameAndAge(string name, int age = 0)
		{
			return "Привет я "+name+" и мне "+age+" лет";
		}
		
		public static void Main(string [] agrs)
		{
			// Пример использование метода CW (Console.WriteLine())
			CW("Hello World!");
			
			// Пример метода котроый возвращает сумму 2 чисел
			decimal resultPlus = Plus(5,5);
			Console.WriteLine(resultPlus);
			
			// Позиционные
			string resultOne = NameAndAge("Дима Позиционные", 20);
			Console.WriteLine(resultOne);
			
			// Именнованные
			string resultTwo = NameAndAge(age: 20, name: "Дима Именованные");
			Console.WriteLine(resultTwo);
			
			// Опциональные
			string resultThree = NameAndAge("Дима Опциональные");
			Console.WriteLine(resultThree);
			
			
			Console.ReadKey();
			
		}
	}
}