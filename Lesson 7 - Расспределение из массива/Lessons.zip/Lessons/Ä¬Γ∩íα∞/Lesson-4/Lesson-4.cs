using System;

namespace Lesson4
{
	public class Lesson4
	{
		public static void Main(string [] agrs)
		{
			//=================== Унарные операторы =======================//
			
			// Переменная x увеличивается на 1 (++)
			int x = 1;
			x++;
			
			// Переменная y уменьшается на один (--)
			int y = 1;
			y--;
			
			// Изменение знака числа на плюс (+=)
			int z = 5;
			z += 5;
			
			// Изменение знака числа на минус (-=)
			int i = 5;
			i -= 4;
			
			//=================== Бинарные операторы =======================//
			
			// Бинарный опертор (сложение) +
			decimal x1 = 5;
			decimal y1 = 5;
			decimal z1 = x1 + y1;
			
			// Бинарный опертор (вычитание) -
			decimal x2 = 5;
			decimal y2 = 5;
			decimal z2 = x2 - y2;
			
			// Бинарный опертор (деление) /
			decimal x3 = 5;
			decimal y3 = 5;
			decimal z3 = x3 / y3;
			
			// Бинарный опертор (умножение) /
			decimal x4 = 5;
			decimal y4 = 5;
			decimal z4 = x4 * y4;
			
			// Бинарный опертор (остаток от деления) %
			decimal x5 = 7;
			decimal y5 = 2;
			decimal z5 = x5 % y5;
			
			//=============== Условный оператор if ==============//
			
			Console.WriteLine("На улице идет дождь?");
			string result = Console.ReadLine();
			
			if(result == "Да")
			{
				Console.WriteLine("Возьми зонт");
			}
			else
			{
				Console.WriteLine("Можешь идти без зонта");
			}
			
			
			Console.ReadKey();
		}
	}
}