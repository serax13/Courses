﻿using System;
namespace qwerty
{
	public class qwerty
{	
	public static void Main (string [] args) {
	Console.WriteLine ("   *\n  ***\n *****\n *******");
}
}
}