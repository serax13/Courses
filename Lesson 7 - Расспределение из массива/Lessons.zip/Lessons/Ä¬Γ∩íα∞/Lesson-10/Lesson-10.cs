using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
			/*
			// Пример цикл в цикле
			for(int i = 1; i <= 50; i++)
			{
				for(int j = 1; j <= i; j++)
				{
					Console.Write("*");
				}
				Console.WriteLine("");
				Thread.Sleep(100);
			}
			
			// Пример отступа в цикле
			int n = 1;
			for(int i = 1; i<=50; i++)
			{
				Console.Write("= = = = = ");
				n++;
				if(n > 5)
				{
					n = 1;
					Console.Write("\n");
				}
				Thread.Sleep(100);
			}
			*/
			
			/*
			// Получение номера используя функцию Split в цикле
			string numbers = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15";
			string[] listNumbers = numbers.Split(',');
			int numbersCount = listNumbers.Length;
			
			for(int i = 0; i <= numbersCount - 1; i++)
			{
				string number = listNumbers[i];
				Console.WriteLine(number);
			}
			*/
			
		 
			// Пример разбиение строки в цикле
			string[] textWithNumbers = new string[5];
			textWithNumbers[1] = "A | 5 сантиметр";
			textWithNumbers[2] = "B | 7 сантиметр";
			textWithNumbers[3] = "C | 8 сантиметр";
			
			string numbers = "1,2";
			string[] listNumbers = numbers.Split(',');
			int numbersCount = listNumbers.Length;
			decimal sum = 0;
			for(int i = 0; i <= numbersCount - 1; i++)
			{
				// Получает номер из массива номеров
				string number = listNumbers[i];
				// Конвертирует в числовой тип
				int index = Convert.ToInt32(number);
				// Переменная поулчает данные из массива
				string wordsResult = textWithNumbers[index];
				// Отображает
				Console.WriteLine(wordsResult);
				// Отделяем цифру от символа
				string numberSum = wordsResult.Split('|')[1];
				// Используя Replace избавляемся от слова сантиметр
				numberSum = numberSum.Replace("сантиметр", "").Trim();
				// Суммируем
				sum = sum + Convert.ToDecimal(numberSum);
			}
			Console.WriteLine("Итого "+sum+" сантиметров");
		   
			
			/*
			// Пример заполнения массива.
			Console.WriteLine("Введите количество букв");
			string textCount = Console.ReadLine();
			int count = Convert.ToInt32(textCount.Trim());
			
			Console.WriteLine("Введите буквы");
			string[] words = new string[count];
			for(int i = 0; i <= count -1; i++)
			{
				words[i] = Console.ReadLine();
			}
			
			Console.WriteLine("Результат массива");
			for(int i = 0; i <= words.Length - 1; i++)
			{
				Console.WriteLine(words[i]);
			}
			*/
			
			Console.ReadKey();
		}
	}
}