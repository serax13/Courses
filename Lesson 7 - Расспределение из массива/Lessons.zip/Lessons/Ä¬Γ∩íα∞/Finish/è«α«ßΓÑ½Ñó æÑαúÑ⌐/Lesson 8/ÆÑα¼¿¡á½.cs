using System;
namespace Praktik
{
    public class Praktik

    {
        public static void Main(string[] args)
        {   
        	int again_pay=0;
        	do{
        	int month;
        	int home_selection;
        	int code_chek=0;
            int intercom = 0;
        	int section_selection = 0;
        	int subsection_selection = 0;
        	
            decimal amount = 0;
            decimal amount_intercom = 0;
            decimal amount_per_phone = 0;
            
            string PhoneNumb;
            
            int [] amount_per_games = {0, 50, 200, 500, 750, 835, 1500};
            string [] operator_code = {"055","077","070"};
        	string [] operators_names = {"MegaCom","BeeLine"," Оператора - O "};
        	string [] seach_dir = {"игры", "услуги"};
        	string [] name_games = {"1- Танки 50", "2-War Fase 200", "3- Королество 500", "4- Техномагия 750", "5- Strife 835", "6- Prime World 1500"};
        	string [] name_servis = {"1- Домофон", "2- Газ", "3- Отопление"};
        	
        	
            Console.WriteLine("Введите услугу: ");
            string textSearch = Console.ReadLine();
			for(int i = 0; i <= 1; i++)
			{				
				if(seach_dir[i].Contains(textSearch.ToLower().Trim()) == true)
				{
					if (i==0)
						{
							section_selection=1;
							Console.WriteLine("Выберите игру: \n");
							foreach(var catalog_game in name_games)
                			Console.WriteLine(catalog_game);
                		}
					else
						{
							section_selection=2;
							Console.WriteLine("Выберите услугу: \n");
							foreach(var catalog_servis in name_servis)
                			Console.WriteLine(catalog_servis);
						}
				}
			}
            if (section_selection == 1)
            {   
				subsection_selection = Convert.ToInt32(Console.ReadLine());
                	if (subsection_selection == 1||subsection_selection==2||subsection_selection==3||subsection_selection==4||subsection_selection==5||subsection_selection==6) 
                	{
                    	Console.WriteLine("Введите сумму оплаты "+amount_per_games[subsection_selection]);
                    	amount = Convert.ToDecimal(Console.ReadLine());
                    	if (amount > 0 && amount < 5000 )
                    		{
                    			if (amount==50&&subsection_selection==1||amount==200&&subsection_selection==2||amount==500&&subsection_selection==3||amount==750&&subsection_selection==4||amount==835&&subsection_selection==5||amount==1500&&subsection_selection==6)
                    					Console.WriteLine("Платеж прошел успешно на сумму " + amount + " сом");
                    			else if (amount<50&&subsection_selection==1||amount<200&&subsection_selection==2||amount<500&&subsection_selection==3||amount<750&&subsection_selection==4||amount<835&&subsection_selection==5||amount<1500&&subsection_selection==6)
                        			{
										Console.ForegroundColor = ConsoleColor.Red;
                            			Console.WriteLine("Невераня сумма!");
                        			}
                        		if (amount>50&&subsection_selection==1||amount>200&&subsection_selection==2||amount>500&&subsection_selection==3||amount>750&&subsection_selection==4||amount>835&&subsection_selection==5||amount>1500&&subsection_selection==6)
                        			{
                        				amount_per_phone = amount-amount_per_games[subsection_selection];
                        				Console.WriteLine("Платеж прошел успешно на сумму "+amount_per_games[subsection_selection]+" сом, для возврата остатка " + amount_per_phone + " сом ");
                        			}
                    		}
						else 
                        	{
					    		Console.ForegroundColor = ConsoleColor.Red;
                        		Console.WriteLine("Сумма не должна быть меньше нуля или больше 5000 сом!");
                        	}
                	}
			}	
			else if (section_selection == 2) //Вывод меню Ком.услуг
            {
    			home_selection = Convert.ToInt32(Console.ReadLine());
                if (home_selection == 1) //Вывод меню домофона
                {
                    Console.WriteLine("1. Оплата за месяц ");
                    Console.WriteLine("2. Предоплата");
                    intercom = Convert.ToInt32(Console.ReadLine());
                    
                    if (intercom == 1) // Оплата за месяц в домофоне
                    {
                        Console.WriteLine("Введите сумму оплаты");
                        amount = Convert.ToDecimal(Console.ReadLine());
                        if (amount == 100) //Сумма равная 100 сом на домофоне
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Оплата прошла успешно на сумму " + amount + " сом");
                        }
						else if (amount < 0 || amount > 5000 ) // Ограничение денег до 5000 сом
                        {
					        Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Неверная сумма!");
                        }
                        else // если клиент ввел сумму не равную 100 сом
                        {
                            Console.WriteLine("Ошибка, сумма оплаты 100 сом");
                        }

                    }
                    else if (intercom == 2)// Предоплата по домофону
                    {
                        Console.WriteLine("Введите количестко месяцев");
                        month = Convert.ToInt32(Console.ReadLine());
                        if (month>= 2 && month<=24) // ограничение в месяцах от 2 месяцев до 24 месяцев по домофону
                        {
           					amount_intercom = month * 100;
                            amount_per_phone = month * 7;
                            Console.WriteLine("Оплата прошла успешна на " + amount_intercom + " сом, для получения бонуса " + amount_per_phone + "сом ");
                        }
						else
						{
							Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Некорректный месяц!");
						}
                    }
				}
				else if (home_selection == 2||home_selection==3)
				{
                     Console.WriteLine("Введите сумму оплаты");
					 amount = Convert.ToDecimal(Console.ReadLine());	
					  if (amount > 0 && amount < 5000 )
                        	Console.WriteLine("Оплата прошла успешна на "+amount+" сом");
                      else
					  		{						  
					     		Console.ForegroundColor = ConsoleColor.Red;
                           		Console.WriteLine("Невераня сумма!");
					  		}
				}
				else
				{
					Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Некорректный оператор!");
				}
            }
            else // вывод ошибки если в гоавном меню написали другое значение кроме 1 и 2
			{
				Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Некорректный ввод!");
			}
   
            if (amount>50&&subsection_selection==1||amount>200&&subsection_selection==2||amount>500&&subsection_selection==3||amount>750&&subsection_selection==4||amount>835&&subsection_selection==5||amount>1500&&subsection_selection==6||intercom == 2)
			{
				int again_phonenumb=0;
			    do
			    	{
			    		Console.WriteLine("Введите номер телефона: ");
						PhoneNumb = Convert.ToString (Console.ReadLine());
							if (PhoneNumb.Length==10||PhoneNumb.Length==13)
								{
									for(code_chek=0; code_chek<3; code_chek++)
										{
				   							if(PhoneNumb.StartsWith(operator_code[code_chek])==true)
				   								{
			        								Console.WriteLine("Ваш баланс "+operators_names[code_chek]+" пополнен на "+amount_per_phone+" сом");
													again_phonenumb=0;
													break;
												}
										}
								}
			    			if(code_chek!=0&&code_chek!=1&&code_chek!=2)
			    				{
									Console.WriteLine("не правильно введен номер, повторить ввод? 1- Да, 2- Нет");
									again_phonenumb=Convert.ToInt32(Console.ReadLine());
			    				}
					}while(again_phonenumb==1);
			}
			Console.WriteLine("выполнить ещё платеж? 1- Да, 2- Нет");
			again_pay=Convert.ToInt32(Console.ReadLine());
			Console.ResetColor();
        	}while(again_pay==1);
        }
    }
}