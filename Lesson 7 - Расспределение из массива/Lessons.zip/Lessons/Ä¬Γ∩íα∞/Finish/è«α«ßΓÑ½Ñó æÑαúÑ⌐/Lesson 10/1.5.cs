using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {
            string [] groceryList = new string[15];
			groceryList[0]="1 - Чай | 120 сом";
			groceryList[1]="2 - Сахар | 50 сом";
			groceryList[2]="3 - Соль | 15 сом";
			groceryList[3]="4 - Рис | 200 сом";
			groceryList[4]="5 - Гречка | 220 сом";
			groceryList[5]="6 - Картофель | 60 сом";
			groceryList[6]="7 - Морковь | 50 сом";
			groceryList[7]="8 - Хлеб | 20 сом";
			groceryList[8]="9 - Йогурт | 110 сом";
			groceryList[9]="10 - Кефир | 60 сом";
			groceryList[10]="11 - Сметана | 80 сом";
			groceryList[11]="12 - Масло | 160 сом";
			groceryList[12]="13 - Салат | 140 сом";
			groceryList[13]="14 - Колбаса | 250 сом";
			groceryList[14]="15 - Лапша | 45 сом";
			int sumMass=groceryList.Length;
			decimal sum=0;
			
			for(int i=0; i<sumMass; i++)
			{
				sum = sum+Convert.ToDecimal(groceryList[i].Split("|")[1].Replace("сом","").Trim());
			}
			foreach(var n in groceryList)
			Console.WriteLine(n);
			Console.WriteLine(sum);
        }
    }
}