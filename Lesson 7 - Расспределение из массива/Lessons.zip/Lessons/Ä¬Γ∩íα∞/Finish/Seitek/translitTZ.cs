using System;


namespace Program
{
	public class Program
	{
		public static string Replacement()
		{
			string Word = Console.ReadLine();
			string[] eng = new string[29];
			eng[0] = "A";
			eng[1] = "B";
			eng[2] = "V";
			eng[3] = "G";
			eng[4] = "D";
			eng[5] = "E";
			eng[6] = "YO";
			eng[7] = "ZH";
			eng[8] = "Z";
			eng[9] = "I";
			eng[10] = "Y";
			eng[11] = "K";
			eng[12] = "L";
			eng[13] = "M";
			eng[14] = "N";
			eng[15] = "O";
			eng[16] = "P";
			eng[17] = "R";
			eng[18] = "S";
			eng[19] = "T";
			eng[20] = "U";
			eng[21] = "F";
			eng[22] = "H";
			eng[23] = "TS";
			eng[24] = "SH";
			eng[25] = "SCH";
			eng[26] = "E";
			eng[27] = "YU";
			eng[28] = "YA";
			string[] rus = new string[29];
			rus[0] = "�";
			rus[1] = "�";
			rus[2] = "�";
			rus[3] = "�";
			rus[4] = "�";
			rus[5] = "�";
			rus[6] = "�";
			rus[7] = "�";
			rus[8] = "�";
			rus[9] = "�";
			rus[10] = "�";
			rus[11] = "�";
			rus[12] = "�";
			rus[13] = "�";
			rus[14] = "�";
			rus[15] = "�";
			rus[16] = "�";
			rus[17] = "�";
			rus[18] = "�";
			rus[19] = "�";
			rus[20] = "�";
			rus[21] = "�";
			rus[22] = "�";
			rus[23] = "�";
			rus[24] = "�";
			rus[25] = "�";
			rus[26] = "�";
			rus[27] = "�";
			rus[28] = "�";
			for(int i = 1; i==29; i++)
			{
				Word = Word.Replace(rus[i],eng[i]);
			}
			Console.WriteLine(Word);
			return Word;
		}
		public static void Main(string[] args)
		{
			Replacement();
		}
	}
}