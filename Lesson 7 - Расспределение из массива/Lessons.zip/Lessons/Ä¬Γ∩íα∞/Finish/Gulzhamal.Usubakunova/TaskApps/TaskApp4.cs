using System;

namespace TaskApp4
{
	public class TaskApp4
	{
		
		public static void Main(string [] agrs)
		{
			string Alphabet = Console.ReadLine();;
			string[] ListAlphabet = Alphabet.Split(',');
			int AlphabetCount = ListAlphabet.Length;
			int n = 1;
			for(int i = 0; i <= AlphabetCount - 1; i++)
			{
				
				Console.Write(ListAlphabet[i]);
				n++;
				if(n > 4)
				{
					n = 1;
					Console.Write("\n\n");
				}
			}
			
			
		}
		
	}
						
}