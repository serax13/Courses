using System;

namespace TaskApp8
{
	public class TaskApp8
	{
		
		public static void Main(string [] agrs)
		{
	
			string[] ProductsName = new string[15]; // массив продуктов
			ProductsName[0]="0-Гречка    |80 сом";
			ProductsName[1]="1- Молоко   |60 сом";
			ProductsName[2]="2- Томаты   |40 сом";
			ProductsName[3]="3- Соль     |27 сом";
			ProductsName[4]="4- Сахар    |45 сом";
			ProductsName[5]="5- Перец    |30 сом";
			ProductsName[6]="6- Спагетти |70 сом";
			ProductsName[7]="7- Рис      |70 сом";
			ProductsName[8]="8- Масло    |90 сом";
			ProductsName[9]="9- Свекла   |30 сом";
			ProductsName[10]="10-Лук      |25 сом";
			ProductsName[11]="11-Картофель|20 сом";
			ProductsName[12]="12-Виноград |80 сом";
			ProductsName[13]="13-Розмарин |20 сом";
			ProductsName[14]="14-Кориандр |20 сом";
			
			for (int i=0;i<=14;i++)
			{
				Console.WriteLine(ProductsName[i]);
			}
			
			Console.WriteLine("Для покупки продуктов выберите коды продуктов через запятую");
			string ProductsCode = Console.ReadLine();
			string[] listProducts = ProductsCode.Split(',');
			
			decimal sum = 0;
			for(int i = 0; i <= listProducts.Length-1; i++)
			{
				
				string Product = listProducts[i];
				int index = Convert.ToInt32(Product);
				string ProductResult = ProductsName[index];
				Console.WriteLine(ProductResult);	
				string ProductsSum = ProductResult.Split('|')[1];
				
				ProductsSum = ProductsSum.Replace("сом", "").Trim();
				
				sum = sum + Convert.ToDecimal(ProductsSum);
			}
			Console.WriteLine("Итоговая сумма: "+sum+" сомов");
	
			
		}
	
	}
						
}