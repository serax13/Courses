using System;

namespace PayTerminal
{
	public class PayTerminal
	{
		public static void Main(string [] agrs)
		{
			decimal MoneyPay=0; // переменная  для ввода суммы
			string PhoneNumber="tel"; // переменная для ввода телефона
			string CheckChoise="0";//переменная для ввода вариантов
			byte LegenthNum=0;//переменная для хранения количества символов
			int Month=0;//переменная для ввода количество месяцев
			
			while(1!=2)//простое зацикливание
			{	
				string[] ChooseService = new string[9]; // массив услуг
				ChooseService[0]="Танки";
				ChooseService[1]="Warface";
				ChooseService[2]="Королевство";
				ChooseService[3]="Техномагия";
				ChooseService[4]="Strife";
				ChooseService[5]="Prime World";
				ChooseService[6]="домофон";
				ChooseService[7]="газ";
				ChooseService[8]="отопление";
				
			    Console.WriteLine("#####Оплата Услуг#####");
				Console.WriteLine("WorldOfTanks 50сом\nWarface 200сом\nKindoms 500сом\nTechMagic 750сом\nStrike 835сом\nPrimeWorld 1500сом \nдомофон\nгаз\nотопление");
				
				Console.WriteLine("Здравствуйте, выберите услугу:");	
				string TextSearch = Console.ReadLine(); // поиск услуги по введеному слову
				
				for(int i = 0; i <= 8; i++)
				{				
					if(ChooseService[i].ToUpper().Contains(TextSearch.ToUpper()) == true)
					{
						Console.WriteLine("Вы оплачиваете услугу : "+ChooseService[i]);
				
						switch(ChooseService[i])
						{
							case "Танки":
							CheckPayment(50);
							break;
						
							case "Warface":
							CheckPayment(200);
							break;
						
							case "Королевство":
							CheckPayment(500);
							break;
							
							case "Техномагия":
							CheckPayment(750);
							break;
							
							case "Strife":
							CheckPayment(835);
							break;
							
							case "Prime World":
							CheckPayment(1500);
							break;
							
							case "газ":
							MoneyPay=Convert.ToDecimal(Console.ReadLine());
							if(MoneyPay<=0||MoneyPay>5000)
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
								Console.WriteLine("Неверная сумма оплаты!!");
								Console.ResetColor(); 
								//Цвет
							}
							else
							{
								Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
							}
							
							break;
							
							case "отопление": 
							MoneyPay=Convert.ToDecimal(Console.ReadLine());
							if(MoneyPay<=0||MoneyPay>5000)
							{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
								Console.WriteLine("Неверная сумма оплаты!!");
								Console.ResetColor(); 
								//Цвет
							}
							else
							{
								Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
							}
							
							break;
							
							case "домофон":
							Console.WriteLine("Выберите следующий вариант оплаты>>");
							Console.WriteLine("Оплата за месяц - 1\nПредоплата - 2");
							CheckChoise=Console.ReadLine();
							if(CheckChoise=="1")
							{
								Console.WriteLine("Введите сумму оплаты равной 100 сом>>");
								MoneyPay=Convert.ToDecimal(Console.ReadLine());
								if(MoneyPay!=100)
								{
									Console.WriteLine("Сумма оплаты должна быть равной 100сом!!");
								}
								else
								{
									Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
								}
							}
							else if(CheckChoise=="2")
							{   
								Console.WriteLine("Введите количество месяцев>>");
								Month=Convert.ToInt32(Console.ReadLine());
								int CheckMoney = Month*100;
								Console.WriteLine("Введите сумму оплаты равной "+CheckMoney+" сом");
								MoneyPay=Convert.ToDecimal(Console.ReadLine());
								
								if(MoneyPay>CheckMoney||MoneyPay<CheckMoney)
								{
									Console.WriteLine("Сумма оплаты должна быть равной "+CheckMoney+" сом!!");
								}
								else
								{
									Console.WriteLine("Платеж на сумму "+CheckMoney+" сом успешно завершен");
									CheckMoney=(Month*100)/100*7;
									Console.WriteLine("Для вывода бонуса в виде единиц введите ваш телефон>>");
									PhoneNumber=Console.ReadLine();
									LegenthNum=Convert.ToByte(PhoneNumber.Length);
									if(LegenthNum==10||LegenthNum==13)
									{
										Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+CheckMoney+" сом");
									}
									else
									{//цвет
										Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
										Console.WriteLine("Данный оператор не существует!");
										Console.ResetColor(); 
									}
				
								}
								
							}
							
							break;
							
							
							default:
							break;
							
						}
					}
				}
			}
	
		}
		
		public static void CheckPayment(decimal GameSumm) //функция для совершения платежа
		{	
			decimal MoneyPay=0;
			string PhoneNumber;
			byte LegenthNum=0;
					
			Console.WriteLine("Введите сумму оплаты>>");
			MoneyPay=Convert.ToDecimal(Console.ReadLine());
			
			if(MoneyPay==GameSumm)
			{
				Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
			}
			
			else if(MoneyPay>GameSumm &&MoneyPay<5001)
			{
				Console.WriteLine("Платеж прошел успешно на сумму " + GameSumm+" сом");
				Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-GameSumm)+" сом \n на баланс введите номер телефона>>");
				PhoneNumber=Console.ReadLine();
				LegenthNum=Convert.ToByte(PhoneNumber.Length);
			    
				if(LegenthNum==10||LegenthNum==13)
				{
				    Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-GameSumm)+" сом");
			    }
			    else
			    {	//цвет
					Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				    Console.WriteLine("Данный оператор не существует!");
					Console.ResetColor(); 
			    }
						
						
			}
			
			else if(MoneyPay>5000||MoneyPay<GameSumm)
			{ 
			    Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				Console.WriteLine("Неверная сумма платежа!!");
				Console.ResetColor(); 
						
			}

		}

		
	}
}