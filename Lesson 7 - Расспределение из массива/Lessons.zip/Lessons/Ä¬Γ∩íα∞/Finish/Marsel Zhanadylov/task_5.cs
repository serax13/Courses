using System;
namespace MARSEL{
	public class task_5{
		public static void Main(){
			//Begining of the task_5!!!
			string [] ProductList = 
			{
			"0-Чай       | 120 сом",
			"1-Сахар     | 50 сом",
			"2-Хлеб      | 20 сом",
			"3-Молоко    | 20 сом",
			"4-Сгущенка  | 60 сом",
			"5-Сметана   | 48 сом",
			"6-Колбаса   | 130 сом",
			"7-Мясо      | 520 сом",
			"8-Творог    | 70 сом",
			"9-Конфеты   | 140 сом",
			"10-Курица   | 320 сом",
			"11-Рись     | 85 сом",
			"12-Гречка   | 80 сом",
			"13-Мед      | 450 сом",
			"14-Макароны | 90 сом"
			};
			decimal Sum = 0;
			for (int i =0;i <= ProductList.Length-1;i++)
			{
				Console.WriteLine(ProductList[i]);
			
				Sum = Sum + Convert.ToDecimal(ProductList[i].Split('|')[1].Replace("сом","").Trim());
			}
				Console.WriteLine("\nTotal sum is: " + Sum + " сом.\n");
		}
	}
}