using System;
namespace MARSEL{
	public class task_4{
		public static void Main(){
			Console.WriteLine("Enter words with comma.");
			string words = Console.ReadLine();
			string [] ListOfWords = words.Split(',');
			int count = 0;
			int n = 1;
			for(int r = 0;r <= ListOfWords.Length-1;r++)
			{
				Console.Write(ListOfWords[r].Trim().ToUpper());
			  count++;
			  n++;
			   if(n > 4)
			{
				n = 1;
				Console.WriteLine(" \n ");
			}
			}
				Console.WriteLine("Arrays number is: " + count);
			
		}
	}
}