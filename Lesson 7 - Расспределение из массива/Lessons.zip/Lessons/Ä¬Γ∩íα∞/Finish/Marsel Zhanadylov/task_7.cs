using System;
namespace MARSEL{
	public class task_7{
		public static void Main() {
			// Begining of the task_7;
			string [] ProductList = new string [15]; 
			
			ProductList [0] = "0-Чай       | 120 сом";
			ProductList [1] = "1-Сахар     | 50 сом";
			ProductList [2] = "2-Хлеб      | 20 сом";
			ProductList [3] = "3-Молоко    | 20 сом";
			ProductList [4] = "4-Сгущенка  | 60 сом";
			ProductList [5] = "5-Сметана   | 48 сом";
			ProductList [6] = "6-Колбаса   | 130 сом";
			ProductList [7] = "7-Мясо      | 520 сом";
			ProductList [8] = "8-Творог    | 70 сом";
			ProductList [9] = "9-Конфеты   | 140 сом";
			ProductList [10] = "10-Курица   | 320 сом";
			ProductList [11] = "11-Рись     | 85 сом";
			ProductList [12] = "12-Гречка   | 80 сом";
			ProductList [13] = "13-Мед      | 450 сом";
			ProductList [14] = "14-Макароны | 90 сом";
			
			for (int i =0;i <= ProductList.Length-1;i++)
			{
				Console.WriteLine(ProductList[i]);
			}
			Console.WriteLine("\nSelect a Products with numbers and comma, please.");
			string number = Console.ReadLine();
			string [] ListNumbers = number.Split(',');
			int NumbersCount = ListNumbers.Length;
			
			decimal Sum = 0;
			for(int i = 0;i <= NumbersCount-1;i++)
			{
				// Begining of the task_8;
				string number2 = ListNumbers[i];
				int index = Convert.ToInt32(number2);
				string ProductResult = ProductList[index];
				Console.WriteLine(ProductResult);
				string SelectedProducts = ProductResult.Split('|')[1];
				Sum = Sum + Convert.ToDecimal(SelectedProducts.Replace("сом","").Trim());
				
			}
				Console.WriteLine("\nTotal sum is: " + Sum + " сом.\n");			
			}
		}
	}
