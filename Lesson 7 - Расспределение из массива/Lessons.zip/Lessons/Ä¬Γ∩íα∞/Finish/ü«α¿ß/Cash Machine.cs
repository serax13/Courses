using System;
using System.Threading;

namespace lesson1
{
  public class CashMachine
  {
    public static void Main(string[] agrs)
    {

      Console.WriteLine("-----------Cash Machine------------\n\n");
      Console.WriteLine("Goods List:\n");
      //Massiv Goods
      string [] Good = new string [15];
      Good[0] = "1-Tea | 120 som";
      Good[1] = "2-Sugar | 50 som";
      Good[2] = "3-Bread | 20 som";
      Good[3] = "4-Milk | 45 som";
      Good[4] = "5-Sandwich | 38 som";
      Good[5] = "6-Yogurt | 40 som";
      Good[6] = "7-Sausage | 100 som";
      Good[7] = "8-Cucumber | 30 som";
      Good[8] = "9-Potato | 25 som";
      Good[9] = "10-Paper | 100 som";
      Good[10] = "11-Candy | 15 som";
      Good[11] = "12-Icecream | 25 som";
      Good[12] = "13-Water | 18 som";
      Good[13] = "14-Cake | 300 som";
      Good[14] = "15-Coffee | 200 som";
      //Display list of products
      for(int i = 0; i <= 14; i++)
      {

        Console.WriteLine(Good[i]);

      }


      //Chooosing products
      Console.WriteLine("Choose products by their indeces, please (use ',' as a delimiter):");


      string Choice = Console.ReadLine();

      decimal TotalSum=0;

      string[] ChoiceList = Choice.Split(',');
      for(int i = 0; i<= ChoiceList.Length-1; i++)
      {
        int ChoiceListInt = Convert.ToInt32(ChoiceList[i]);
        Console.WriteLine(Good[ChoiceListInt-1]);
        string TotalSumStr = Good[ChoiceListInt-1].Split('|')[1].ToString().Replace("som", " ").Trim();
        TotalSum = TotalSum+Convert.ToDecimal(TotalSumStr);
      }


      //Load process visualization
      Console.WriteLine("Wait please...");
			for(int i = 1; i <= 20; i++)
			{
				Thread.Sleep(200);
				Console.Write("=");
			}


      Console.WriteLine("\nОбщая сумма к оплате "+TotalSum);

      Console.WriteLine("Введите сумму:");

      decimal PaySum = Convert.ToDecimal(Console.ReadLine());

      if (PaySum==TotalSum)
      {
        Console.WriteLine("Спасибо за покупку!");
      }
      else if (PaySum>TotalSum)
      {
        decimal Change = PaySum-TotalSum;
        Console.WriteLine("Спасибо за покупку! Ваша сдача "+Change);
      }
      else if (PaySum>TotalSum)
      {
        Console.WriteLine("Не хватило денег!");
      }
      else
      {
        Console.WriteLine("Ошибка!");
      }

      Console.ReadKey();
    }
  }
}
