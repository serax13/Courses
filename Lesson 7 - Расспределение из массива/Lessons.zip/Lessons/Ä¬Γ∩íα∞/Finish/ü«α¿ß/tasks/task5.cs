using System;

namespace tasks
{
  public class task5
  {
    public static void Main(string[] agrs)
    {

      //---Creating an Array---//

      string[] productArray = new string[10];
      productArray[0] = "1 - Чай | 150 сом";
      productArray[1] = "2 - Сахар | 20 сом";
      productArray[2] = "3 - Мука | 50 сом";
      productArray[3] = "4 - Перец | 30 сом";
      productArray[4] = "5 - Картошка | 23 сом";
      productArray[5] = "6 - Конфеты | 130 сом";
      productArray[6] = "7 - Соль | 20 сом";
      productArray[7] = "8 - Дрожь | 10 сом";
      productArray[8] = "9 - Лук | 15 сом";
      productArray[9] = "10 - Морковь | 20 сом";

      //----Display array elements

      for (int i = 0; i <= 9; i++)
      {
        Console.WriteLine(productArray[i]);
      }

      decimal sum = 0;

      for (int i = 0; i <=9; i++)
      {
        sum=sum+Convert.ToDecimal(productArray[i].Split('|')[1].Replace("сом", "").Trim());
      }
      Console.WriteLine("Общая сумма "+sum+" сом.");

      Console.ReadKey();
    }
  }
}
