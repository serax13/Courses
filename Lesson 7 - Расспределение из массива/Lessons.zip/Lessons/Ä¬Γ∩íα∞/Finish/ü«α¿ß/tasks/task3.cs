using System;
using System.Threading;


namespace tasks
{
  public class tasks
  {
      public static void Main(string[] agrs)
      {

        decimal[] number = new decimal [11];
        number[0] = 25;
        number[1] = 26;
        number[2] = 100;
        number[3] = 65;
        number[4] = 78;
        number[5] = 10;
        number[6] = 6;
        number[7] = 4;
        number[8] = 3;
        number[9] = 5;
        number[10] = 14;

        decimal sum = 0;
        for (int i = 0; i <= 10; i++)
        {
          sum=sum+number[i];
        }

        Console.WriteLine(sum);

        Console.ReadKey();
      }
  }
}
