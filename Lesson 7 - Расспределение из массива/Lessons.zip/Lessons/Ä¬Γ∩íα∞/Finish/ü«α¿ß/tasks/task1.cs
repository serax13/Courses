using System;
using System.Threading;


namespace tasks
{
  public class tasks
  {
      public static void Main(string[] agrs)
      {

        string ABC = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
  			string[] listLetters = ABC.Split(',');
  			int LettersCount = listLetters.Length;

  			for(int i = 0; i <= LettersCount - 1; i++)
  			{
  				string letter = listLetters[i];
  				Console.WriteLine(letter);
  			}
        
        Console.ReadKey();
      }
  }
}
