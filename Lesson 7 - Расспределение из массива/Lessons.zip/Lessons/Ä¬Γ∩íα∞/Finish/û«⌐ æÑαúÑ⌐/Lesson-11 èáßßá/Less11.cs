using System;
using System.Threading;

namespace lesson9
{
    public class lesson9
    {   

        static decimal PercentSumm (decimal Sum, decimal Percent)
        {
            if (Sum > 1000000)
            {
                decimal Res1 = ((Sum/100)*Percent)/12;
                decimal Res2 = ((Sum/100)*(Percent-2))/12;
                decimal Bonus = Res1-Res2;
                Console.WriteLine("Вы дали заявку на получение кредита на сумму "+Sum+" с процентной ставкой "+Percent+"%, ваш бонус -2%, ежемесячная сумма погашения составит "+Res2+" сом, ваш бонус с 2% состовляет: "+Bonus+ "сом");
                return Res2;
            }
            else
            {
                decimal Res1 = ((Sum/100)*Percent)/12;
                Console.WriteLine("Вы дали заявку на получение кредита на сумму "+Sum+" с процентной ставкой "+Percent+"%, ежемесячная сумма погашения составит "+Res1+" сом");
                  return Res1;
              
            }
           
        }
        

        
        public static void Main(string [] args)
        {
            while(true)

            {
                Console.Clear();
                Console.WriteLine("1 - 15% годовых вид кредита ипотечный \n2 - 27% годовых вид кредита потребительский \n3 - 35% годовых вид кредита авто кредит");
                int Choose = Convert.ToInt32(Console.ReadLine());
                if (Choose == 1)
                {
                    Console.WriteLine("Вы выбрали: 15% годовых вид кредита ипотечный, введите сумму кредита: ");
                    decimal Sum = Convert.ToDecimal(Console.ReadLine());
                    PercentSumm(Sum,15);
                    
                }
                 if (Choose == 2)
                {
                    Console.WriteLine("Вы выбрали: 27% годовых вид кредита потребительский, введите сумму кредита: ");
                    decimal Sum = Convert.ToDecimal(Console.ReadLine());
                    PercentSumm(Sum,27);
                }
                 if (Choose == 3)
                {
                    Console.WriteLine("Вы выбрали: 35% годовых вид кредита авто, введите сумму кредита: ");
                    decimal Sum = Convert.ToDecimal(Console.ReadLine());
                    PercentSumm(Sum,35);
                }
                Console.ReadKey();
            }
        }
    }
}