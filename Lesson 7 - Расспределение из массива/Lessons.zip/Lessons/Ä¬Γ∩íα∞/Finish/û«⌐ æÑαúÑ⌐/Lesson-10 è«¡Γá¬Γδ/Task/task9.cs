using System;
using System.Threading;

namespace lesson9
{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			int[] Numbers = new int[10];
			Numbers[0] = 10;     
			Numbers[1] = 9;
			Numbers[2] = 8;
			Numbers[3] = 7;
			Numbers[4] = 6;
			Numbers[5] = 5;
			Numbers[6] = 4;
			Numbers[7] = 3;
			Numbers[8] = 2;
			Numbers[9] = 1;

			for (int i = 0; i <= 9 ;i++)
			{
				Console.Write(Numbers[i]);
			}
			Console.ReadLine();
		}
	}
}