using System;
using System.Threading;

namespace lesson9
{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			string[] Numbers1 = new string [9];
			Numbers1[0] = "1";
			Numbers1[1] = "2";
			Numbers1[2] = "3";
			Numbers1[3] = "4";
			Numbers1[4] = "5";
			Numbers1[5] = "6";
			Numbers1[6] = "7";
			Numbers1[7] = "8";
			Numbers1[8] = "9";

			string[] Numbers2 = new string [9];
			Numbers2[0] = "1";
			Numbers2[1] = "2";
			Numbers2[2] = "3";
			Numbers2[3] = "4";
			Numbers2[4] = "5";
			Numbers2[5] = "6";
			Numbers2[6] = "7";
			Numbers2[7] = "8";
			Numbers2[8] = "9";
			int n = 1;
		  int Umnojenie = 0;
			
      for (int i = 1; i < 9; i++)
      {
        for (int j = 0; j < 9; j++)
        {
        	Umnojenie = Convert.ToInt32(Numbers1[i])*Convert.ToInt32(Numbers2[j]);
          Console.WriteLine(Numbers1[i]+"*"+Numbers2[j]+"="+Umnojenie);
        }
        	Console.WriteLine("");
        	n++;
          if(n > 3)
					{
						n = 1;
						Console.Write("\n");
					}
					Thread.Sleep(100);
      }
        Console.ReadLine();    
		}
	}
}