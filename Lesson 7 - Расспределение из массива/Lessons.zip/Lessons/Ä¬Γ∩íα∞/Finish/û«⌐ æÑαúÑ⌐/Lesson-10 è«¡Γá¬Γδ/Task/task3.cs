using System;
using System.Threading;

namespace lesson9
{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			decimal Sum=0;
			decimal[] Massiv = new decimal[10];
			Massiv[0]=44;
			Massiv[1]=10;
			Massiv[2]=5;
			Massiv[3]=91;
			Massiv[4]=55;
			Massiv[5]=13;
			Massiv[6]=16;
			Massiv[7]=29;
			Massiv[8]=7;
			Massiv[9]=8;

			for(int i=0; i<=9; i++)
			{
				Console.WriteLine (Massiv[i]);
			}

			for(int i=0; i<=9; i++)
			{
				Sum=Sum+Massiv[i];
			}
			Console.WriteLine("Сумма "+Sum);
			
		Console.ReadKey();
	 }
 }
} 