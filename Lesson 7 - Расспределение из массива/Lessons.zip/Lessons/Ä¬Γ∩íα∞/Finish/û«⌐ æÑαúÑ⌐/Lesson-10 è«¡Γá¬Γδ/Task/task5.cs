using System;
using System.Threading;

namespace lesson9

{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			string[] Products = new string[10];
			Products[0] = "1) Чай | 120 сом";     
			Products[1] = "2) Сахар | 50 сом";
			Products[2] = "3) Кофе | 200 сом";
			Products[3] = "4) Хлеб | 20 сом";
			Products[4] = "5) Сыр | 100 сом";
			Products[5] = "6) Яйца | 60 сом";
			Products[6] = "7) Сливки | 70 сом";
			Products[7] = "8) Масло | 80 сом";
			Products[8] = "9) Печенье | 110 сом";
			Products[9] = "10) Булочка | 30 сом";

			decimal Sum = 0;
			decimal SumAll = 0;
			for (int i = 0; i<=9; i++)
			{		
				Console.WriteLine (Products[i]);	
			}
			for (int j = 0; j <= 9; j++)
			{
				Sum = Convert.ToDecimal (Products[j].Split('|')[1].Replace("сом","").Trim());
				SumAll = SumAll + Sum;
			}
			Console.WriteLine ("Итоговая сумма: "+SumAll+" сом.");
			Console.ReadKey();
		}
	}
}