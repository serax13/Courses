using System;
namespace Book
{
public class Book
{
	public static void Main(string [] book)
	{
		int ScoreContac=0;
		string NameContact;
		string flag="0";
		byte Exit=1;
		Console.WriteLine("Введите количество контактов:");
		ScoreContac=Convert.ToInt32(Console.ReadLine());
		string [] ListContacts = new string [ScoreContac];
		Console.WriteLine("Вводите имя и телефон контакта через (,)");
		for(int i=0;i<ScoreContac;i++)
		{
			Console.WriteLine("Введите данные контакта №"+(i+1));
			ListContacts[i]=Console.ReadLine();
		}
		Console.Clear();
		Console.WriteLine("Следующие контакты были добавлены:\n");
		for(int i=0;i<ScoreContac;i++)
		{
			Console.WriteLine("Контакт №"+(i+1)+": "+ListContacts[i]);
		}
		
		while(Exit!=0)
		{
			Console.WriteLine("\nХотите позвонить Да/Нет");
			if(Console.ReadLine()=="Да")
			{
				Console.WriteLine("Введите имя контакта:");
				NameContact=Console.ReadLine();
				for(int i=0;i<ScoreContac;i++)
				{
					if(ListContacts[i].Split(',')[0].Trim()==NameContact)
					{
						Console.WriteLine("Вызов "+ListContacts[i]+"...");
						flag="1";
						break;
					}
				}
				if(flag=="0")
				{
					Console.WriteLine("Контакт не найден!!");
				}
			}
			Console.WriteLine("Для продолжения нажмите 1\nДля выхода нажмите 0");
			Exit=Convert.ToByte(Console.ReadLine());
		}
	}
}
}