using System;
namespace Task_5
{
	public class Task_5
	{
		public static void Main(string [] tasks)
		{
			string [] ListOfProducts = new string[5];//список продуктов
			ListOfProducts[0]="1-'Чай' * 120 сом";
			ListOfProducts[1]="2-'Сахар' * 50 сом";
			ListOfProducts[2]="3-'Яблоки' * 95 сом";
			ListOfProducts[3]="4-'Картошка' * 25 сом";
			ListOfProducts[4]="5-'Шоколад' * 70 сом";
			decimal Summ=0;
			for(int i=0;i<5;i++)
			{
				Console.WriteLine(ListOfProducts[i].Replace("*",""));
				Summ+=Convert.ToDecimal(ListOfProducts[i].Split('*')[1].Replace("сом","").Trim());
				
			}
			Console.WriteLine("Сумма выведенных продуктов равно "+Summ+" сом");
			Console.ReadKey();
		}
	}
}