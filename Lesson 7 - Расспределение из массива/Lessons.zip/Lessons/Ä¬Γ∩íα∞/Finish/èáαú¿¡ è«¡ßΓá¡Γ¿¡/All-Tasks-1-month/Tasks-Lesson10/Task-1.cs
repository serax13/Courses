using System;
namespace Task_1
{
	public class Task_1
	{
		public static void Main(string [] tasks)
		{
			string [] Alphabet = new string[33];
		Alphabet[0]="А";
		Alphabet[1]="Б";
		Alphabet[2]="В";
		Alphabet[3]="Г";
		Alphabet[4]="Д";
		Alphabet[5]="Е";
		Alphabet[6]="Ж";
		Alphabet[7]="З";
		Alphabet[8]="Ё";
		Alphabet[9]="Й";
		Alphabet[10]="И";
		Alphabet[11]="К";
		Alphabet[12]="Л";
		Alphabet[13]="М";
		Alphabet[14]="Н";
		Alphabet[15]="О";
		Alphabet[16]="П";
		Alphabet[17]="Р";
		Alphabet[18]="С";
		Alphabet[19]="Т";
		Alphabet[20]="У";
		Alphabet[21]="Ф";
		Alphabet[22]="Х";
		Alphabet[23]="Ц";
		Alphabet[24]="Ч";
		Alphabet[25]="Ш";
		Alphabet[26]="Щ";
		Alphabet[27]="Э";
		Alphabet[28]="Ы";
		Alphabet[29]="Ю";
		Alphabet[30]="Ь";
		Alphabet[31]="Ъ";
		Alphabet[32]="Я";
	
		
			for(int i=0;i<33;i++)
			{
				Console.WriteLine(Alphabet[i]);
			}
			Console.ReadKey();
		}
	}
}