using System;
namespace Task_7
{
	public class Task_7
	{
		public static void Main(string [] tasks)
		{
			string [] ListOfProducts = new string[10];//список продуктов
			ListOfProducts[0]="1-'Чай' * 120 сом";
			ListOfProducts[1]="2-'Сахар' * 50 сом";
			ListOfProducts[2]="3-'Яблоки' * 95 сом";
			ListOfProducts[3]="4-'Картошка' * 25 сом";
			ListOfProducts[4]="5-'Шоколад' * 70 сом";
			ListOfProducts[5]="6-'Кола' * 120 сом";
			ListOfProducts[6]="7-'Масло' * 50 сом";
			ListOfProducts[7]="8-'Конфеты' * 95 сом";
			ListOfProducts[8]="9-'Лук' * 25 сом";
			ListOfProducts[9]="10-'Хлеб' * 70 сом";
			string Simbols;
			Console.WriteLine("Введите код продуктов через запятую:");
			Simbols=Console.ReadLine();
			string[] Text=Simbols.Split(',');
			int SimbolsCount=Text.Length;
			Console.WriteLine("Выбранные продукты:");
			for(int i=0;i<SimbolsCount;i++)
			{
				Console.WriteLine(ListOfProducts[Convert.ToInt32(Text[i])-1].Replace("*",""));	
			}
	
			Console.ReadKey();
		}
	}
}