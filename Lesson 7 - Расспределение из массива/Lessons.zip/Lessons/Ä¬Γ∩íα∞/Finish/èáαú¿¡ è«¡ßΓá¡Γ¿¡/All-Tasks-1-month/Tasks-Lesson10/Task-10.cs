using System;
namespace Task_10
{
	public class Task_10
	{
		public static void Main(string [] tasks)
		{
			
			for(int i=1;i<10;i++)
			{
				for(int j=2;j<10;j++)
				{
					Console.Write(j+"*"+i+"="+(j*i)+"  ");
					if(i*j<10)
					{
						Console.Write(" ");
					}
				}
				Console.Write("\n");
			}
			Console.ReadKey();
		}
	}
}