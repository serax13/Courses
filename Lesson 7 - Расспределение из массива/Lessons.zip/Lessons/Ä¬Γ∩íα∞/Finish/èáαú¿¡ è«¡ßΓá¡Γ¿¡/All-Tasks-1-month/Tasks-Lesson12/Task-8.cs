using System;
namespace Task_8
{
	public class Task_8
	{
		 static decimal PercentSumm(decimal Summ=0,decimal Percent=0)
		{
			return (Summ/100)*Percent;
		}
		static decimal Operation(decimal Operand_1=0, decimal Operand_2=0,string Operator="")
		{
			decimal Answer=0;
			switch(Operator)
			{
				case "+":
				Answer=Operand_1+Operand_2;
				break;
				case "-":
				Answer=Operand_1-Operand_2;
				break;
				case "*":
				Answer=Operand_1*Operand_2;
				break;
				case "/":
				Answer=Operand_1/Operand_2;
				break;
				default:
				break;
			}
			return Answer;
		}
		static void SalaryCalc(decimal Salary=0)
		{
			decimal PercSumm=0;
			Console.WriteLine("Зарплата за месяц состовляет "+Salary+"сом");
			Console.WriteLine("Налог 20% от суммы "+Salary+" состовляет "+(PercentSumm(Salary,20)));
			Console.WriteLine("На руки в месяц чистыми вы получаете "+(Operation(Salary,PercentSumm(Salary,20),"-")));
			Console.WriteLine("За час вы зарабатываете "+(Operation(Salary,720,"/")));
			Console.WriteLine("За день вы зарабатываете "+(Operation(Salary,30,"/")));
			Console.WriteLine("За неделю вы зарабатываете "+(Operation(Salary,4,"/")));
			Console.WriteLine("Ваш годовой доход состовляет "+(Operation(Salary,12,"*")));
			PercSumm=Operation(Salary,PercentSumm(Salary,20),"-");//вычисление чистой зарплаты
			Console.WriteLine("Ваша чистая зарплата за год состовляет "+(Operation(PercSumm,12,"*")));
		}
		public static void Main(string [] tasks)
		{
			decimal Salary=0;
			Console.WriteLine("Введите вашу зарплату за месяц");
			Salary=Convert.ToDecimal(Console.ReadLine());
			SalaryCalc(Salary);
			Console.ReadKey();
		}
	}
}