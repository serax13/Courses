using System;
namespace Task_3
{
	public class Task_3
	{
		static decimal Operation(decimal Operand_1=0, decimal Operand_2=0,string Operator="")
		{
			decimal Answer=0;
			switch(Operator)
			{
				case "+":
				Answer=Operand_1+Operand_2;
				break;
				case "-":
				Answer=Operand_1-Operand_2;
				break;
				case "*":
				Answer=Operand_1*Operand_2;
				break;
				case "/":
				Answer=Operand_1/Operand_2;
				break;
				default:
				break;
			}
			return Answer;
		}
		public static void Main(string [] tasks)
		{
			
			decimal Oper_1=0,Oper_2=0;
			string Operator;
			Console.WriteLine("Введите знак операции");
			Operator=Console.ReadLine();
			Console.WriteLine("Введите первый операнд");
			Oper_1=Convert.ToDecimal(Console.ReadLine());
			Console.WriteLine("Введите второй операнд");
			Oper_2=Convert.ToDecimal(Console.ReadLine());
			Console.WriteLine("Ответ: "+Oper_1+Operator+Oper_2+"="+Operation(Oper_1,Oper_2,Operator));
		
			
			Console.ReadKey();
		}
	}
}