using System;
namespace Task_6
{
	public class Task_6
	{
		static void SearchMethod(string SearchText)
		{
			byte flag=0;
			string[] Cars = new string[20];
			Cars[0]="Mersedes 2000$ 1998 Бишкек";
			Cars[1]="Bmw 2000$ 1998 Бишкек";
			Cars[2]="Honda 2000$ 1998 Чуй";
			Cars[3]="Mersedes 2500$ 1999 Чуй";
			Cars[4]="Mersedes 8000$ 2005 Иссык-Куль";
			Cars[5]="Honda 4000$ 2002 Иссык-Куль";
			Cars[6]="Bmw 5000$ 2002 Нарын";
			Cars[7]="Mersedes 3000$ 1999 Нарын";
			Cars[8]="Lexus 6000$ 1998 Бишкек";
			Cars[9]="Mersedes 4600$ 2002 Бишкек";
			Cars[10]="Lexus 5000$ 2005 Чуй";
			Cars[11]="Mersedes 2000$ 1998 Талас";
			Cars[12]="Honda 2500$ 1998 Ош";
			Cars[13]="Bmw 30000$ 2005 Ош";
			Cars[14]="Lexus 6000$ 2005 Чуй";
			Cars[15]="Mersedes 7000$ 1997 Талас";
			Cars[16]="Honda 2500$ 1998 Ош";
			Cars[17]="Bmw 3000$ 2004 Ош";
			for(int i=0;i<18;i++)
			{
				if(Cars[i].Contains(SearchText)	==true)
				{
				Console.WriteLine(Cars[i]);	
				flag=1;
				}
			}
			if(flag==0)
			{
				Console.WriteLine("Машины с данными параметрами не найдены!");
			}
		}
		public static void Main(string [] tasks)
		{
			string TextSearch;
			while(1!=2){
			Console.WriteLine("Введите слово для поиска:");
			TextSearch=Console.ReadLine();
			SearchMethod(TextSearch);
			Console.ReadKey();
			Console.Clear();
			}
			Console.ReadKey();
		}
	}
}