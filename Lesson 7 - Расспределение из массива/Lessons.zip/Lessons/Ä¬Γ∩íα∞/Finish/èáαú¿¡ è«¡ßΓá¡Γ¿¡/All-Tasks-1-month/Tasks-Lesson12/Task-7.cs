using System;
namespace Task_7
{
	public class Task_7
	{
		static void MassItem(string [] Mas,int Index)
		{
		Console.WriteLine("Значение массива по индексом "+(Index+1)+" равно "+Mas[Index]);
		}
		public static void Main(string [] tasks)
		{
			int N=0,Index=0;
			Console.WriteLine("Введите кол-во массивов");
			N=Convert.ToInt32(Console.ReadLine());
			string[] Mas=new string[N];
			for(int i=0;i<N;i++)
			{
				Console.WriteLine("Введите значение массива №"+(i+1));
				Mas[i]=Console.ReadLine();
			}
			Console.WriteLine("Для получения значение массива введите его индекс:");
			Index=Convert.ToInt32(Console.ReadLine());
			if(Index<N+1)
			{
				MassItem(Mas,Index-1);
			}
			else
			{
				Console.WriteLine("Под данным индексом нету значения в массиве!!!");
			}
			Console.ReadKey();
		}
	}
}