using System;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
			string[] numbers = new string[10];
			numbers[0] = "1";
			numbers[1] = "2";
			numbers[2] = "3";
			numbers[3] = "4";
			numbers[4] = "5";
			numbers[5] = "6";
			numbers[6] = "7";
			numbers[7] = "8";
			numbers[8] = "9";
			numbers[9] = "10";
			for(int i = numbers.Length - 1; i >= 0; i--)
			{
				Console.WriteLine(numbers[i]);
			}
			Console.ReadKey();
		}	
	}		
}			