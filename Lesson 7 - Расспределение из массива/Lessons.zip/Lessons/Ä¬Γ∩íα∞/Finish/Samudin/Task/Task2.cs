using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		public static void Main(string [] agrs)
		{
			Console.WriteLine("Алфавит в таблицу");
			string[] alvafit = new string [15];
			alvafit[0] = "А";
			alvafit[1] = "Б";
			alvafit[2] = "В";
			alvafit[3] = "Г";
			alvafit[4] = "Д";
			alvafit[5] = "Е";
			alvafit[6] = "Ё";
			alvafit[7] = "Ж";
			alvafit[8] = "З";
			alvafit[9] = "И";
			alvafit[10] = "Й";
			alvafit[11] = "К";
			alvafit[12] = "Л";
			alvafit[13] = "М";
			alvafit[14] = "Н";

			int count = 1;
			for(int i = 0; i <= alvafit.Length - 1; i++)
			{
				Console.Write(alvafit[i]);
				count++;
				if(count > 5)
				{
					count = 1;
					Console.Write("\n");
				}
				Thread.Sleep(250);
			}
			Console.ReadKey();
		}	
	}		
}			