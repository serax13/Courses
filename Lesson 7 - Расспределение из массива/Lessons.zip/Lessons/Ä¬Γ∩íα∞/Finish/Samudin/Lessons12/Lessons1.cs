using System;
namespace Homework
{
    public class Homework
    {
    	static void Hello()
    	{
    		Console.WriteLine("Hello World");
    	}
    	public static void Main (string [] args)
    	{
    		Hello();
    	}	
    }		
}    		