using System;
namespace Lessons3
{
    public class Lessons3
    {
    	static void gender()
    	{
    		string[] gender1 = new string [2];
    		gender1[0] = "М";
    		gender1[1] = "Ж";
    		for(int i = 0; i <= 1; i++)
			{
				Console.WriteLine(gender1[i].Trim());
			}
			Console.WriteLine("Выберите пол: ");
			string selectGender = Console.ReadLine();
			if(selectGender == "М")
			{
				Console.WriteLine("Вы мужчина!!!");
			}
			if(selectGender == "Ж")
			{
				Console.WriteLine("Вы женщина!!!");
			}
    	}
    	public static void Main (string [] args)
    	{
    		gender();
    	}	
    }		
}