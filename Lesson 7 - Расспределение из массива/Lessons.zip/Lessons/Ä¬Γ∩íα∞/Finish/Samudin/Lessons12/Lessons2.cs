using System;
namespace Homework
{
    public class Homework
    {
    	static void Read()
    	{
    		string Read = Console.ReadLine();
    		Console.WriteLine(Read);
    	}
    	public static void Main (string [] args)
    	{  
    		Read();
    	}	
    }		
}    	  	