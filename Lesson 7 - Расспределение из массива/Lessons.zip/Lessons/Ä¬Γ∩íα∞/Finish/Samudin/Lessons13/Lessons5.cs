using System;

namespace Homework
{
    public class Homework
    {
        static void Metod(byte x = 10)
        {
            string Stroka = "Один, Два, Три, Четыре, Пять, Шесть, Семь, Восемь, Девять, Десять";
            string[] array = Stroka.Split(',');
            for(int i = 1; i <= x; i++)
            {
                Console.WriteLine(i + "-" + array[i-1].Trim());
            }
        }
    	public static void Main (string [] args)
    	{
    		Metod();
    	}	
    }		
}    		
