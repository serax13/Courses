using System;
namespace Homework
{
    public class Homework
    {
    	static void Metod(long count)
    	{
    		long[] array = new long[count];
    		for(long i = 1; i <= array.Length; i++)
    		{
    			array[i - 1] = i;
    			Console.WriteLine(i);
    		}
    	}
    	public static void Main (string [] args)
    	{
    		Metod(Convert.ToInt64(Console.ReadLine()));
    	}	
    }		
}    		
