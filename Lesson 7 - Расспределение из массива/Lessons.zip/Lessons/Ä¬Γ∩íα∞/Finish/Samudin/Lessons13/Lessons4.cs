using System;

namespace Ls {
	public class Ls {
		public static void Main(string [] args) {

			Console.WriteLine("Введите число:");
			long num = Convert.ToInt64(Console.ReadLine());
			Method(num);
		}

		public static void Method(long num) {


			long[] NumArray = new long[num];
			long LengthArr = NumArray.Length;

			for (long i = 1; i <= LengthArr; i++) {
				NumArray[i] = i;
				Console.Write(NumArray[i]);
				if (i == LengthArr)
					Console.Write(";");
				else 
					Console.Write(",");
			}

			
		}
	}
}