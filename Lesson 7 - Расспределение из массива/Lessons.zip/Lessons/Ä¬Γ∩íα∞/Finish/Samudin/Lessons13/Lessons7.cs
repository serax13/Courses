using System;

namespace Homework
{
    public class Homework
    {
        static void Translater(string slovo)
        {            
            char[] en = new char[27];
            en[0] = 'A';
            en[1] = 'B';
            en[2] = 'C';
            en[3] = 'D';
            en[4] = 'E';
            en[5] = 'F';
            en[6] = 'G';
            en[7] = 'H';
            en[8] = 'I';
            en[9] = 'J';
            en[10] = 'K';
            en[11] = 'L';
            en[12] = 'M';
            en[13] = 'N';
            en[14] = 'O';
            en[15] = 'P';
            en[16] = 'Q';
            en[17] = 'R';
            en[18] = 'S';
            en[19] = 'T';
            en[20] = 'U';
            en[21] = 'V';
            en[22] = 'W';
            en[23] = 'X';
            en[24] = 'Y';
            en[25] = 'Z';
            en[26] = ' ';
            char[] ru = new char[34];
            ru[0] = 'А';
            ru[1] = 'Б';
            ru[2] = 'В';
            ru[3] = 'Г';
            ru[4] = 'Д';
            ru[5] = 'Е';
            ru[6] = 'Ё';
            ru[7] = 'Ж';
            ru[8] = 'З';
            ru[9] = 'И';
            ru[10] = 'Й';
            ru[11] = 'К';
            ru[12] = 'Л';
            ru[13] = 'М';
            ru[14] = 'Н';
            ru[15] = 'О';
            ru[16] = 'П';
            ru[17] = 'Р';
            ru[18] = 'С';
            ru[19] = 'Т';
            ru[20] = 'У';
            ru[21] = 'Ф';
            ru[22] = 'Х';
            ru[23] = 'Ц';
            ru[24] = 'Ч';
            ru[25] = 'Ш';
            ru[26] = 'Щ';
            ru[27] = 'Ъ';
            ru[28] = 'Ы';
            ru[29] = 'Ь';
            ru[30] = 'Э';
            ru[31] = 'Ю';
            ru[32] = 'Я';
            ru[33] = ' ';
            char[] charArray = slovo.ToCharArray();
            for(int i = 0; i <= slovo.Length - 1; i++)
            {
                for(int g = 0; g <= slovo.Length - 1; g++)
                {
                    if(slovo[i] == ru[g])
                    {
                        Console.Write(en[g]);
                    }
                }
            }
        }
    	public static void Main (string [] args)
    	{
    		Translater();
    	}	
    }		
}    		
