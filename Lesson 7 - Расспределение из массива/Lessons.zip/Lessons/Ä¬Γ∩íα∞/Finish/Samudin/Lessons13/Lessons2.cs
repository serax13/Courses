using System;
namespace Homework
{
    public class Homework
    {
    	static void CW(string text)
		{
			Console.WriteLine(text);
		}
		static void Metod(int x)
		{
			Console.WriteLine("Введите число: ");
			int y = x * x;
			Console.WriteLine("Квадрат числа {0} = {1}",x,y);
		}
    	public static void Main (string [] args)
    	{
    		Metod(Convert.ToInt32(Console.ReadLine()));
    	}	
    }		
}    		
