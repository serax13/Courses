using System;
namespace Homework
{
    public class Homework
    {
    	static void CW(string text)
		{
			Console.WriteLine(text);
		}
		static string Name()
		{
			Console.WriteLine("Напишите имя: ");
			string name = Console.ReadLine();
			return name;
		}
		static byte Age()
		{
			Console.WriteLine("Введите возраст: ")
			byte x = Convert.ToByte(Console.ReadLine());
			return x;
		}
    	public static void Main (string [] args)
    	{
    		string name = Name();
    		byte x = Age();
    		int y = x+1;
    		CW("Привет я " + name + " мне " + x + " через год мне исполнится " + y);
    	}	
    }		
}    		
