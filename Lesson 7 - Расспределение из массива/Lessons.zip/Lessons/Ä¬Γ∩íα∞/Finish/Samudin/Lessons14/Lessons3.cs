using System;

namespace Lessons2
{
    public class Lessons2
    {
    	static void numbers()
    	{  
            int count = 1;
            for(int i = 1; i <= 10; i++)
            {
                Console.Write(i);
                count++;
                if(count > 5)
                {
                    count = 1;
                    Console.Write("\n");
                }   
            }
    	}
    	public static void Main (string [] args)
    	{
            numbers();
    	}	
    }		
}   