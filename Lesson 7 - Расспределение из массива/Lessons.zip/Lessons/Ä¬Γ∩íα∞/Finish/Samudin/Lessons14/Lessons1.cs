using System;

namespace Lessons13
{
    public class Lessons13
    {
    	static void Hello()
    	{
    		Console.WriteLine("Hello World!!!");
    	}
    	public static void Main (string [] args)
    	{
    		Hello();
    	}	
    }		
}    		