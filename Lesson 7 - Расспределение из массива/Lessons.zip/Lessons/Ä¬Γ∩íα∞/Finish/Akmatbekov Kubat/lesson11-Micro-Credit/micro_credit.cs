using System;

namespace micro_credit
{
	public class micro_credit
	{
		public static void Main ( string [] args)
		{
			string[] ListCreditProducts = new string[3];
			ListCreditProducts[0] = " 1 - 15% годовых вид кредита ипотечный";
			ListCreditProducts[1] = " 2 - 27% годовых вид кредита потребительский";
			ListCreditProducts[2] = " 3 - 35% годовых вид кредита авто кредит";

			string CreditQueryNumber;
			string ListCreditProductPercent;
			byte CreditProductPercent = 0;
			byte CreditQueryPeriod = 0;
			decimal CreditQuerySumm;
			decimal PercentSumm;
			decimal CreditCalculateSumm;

			for ( int i = 0; i <= 2; i++)
			{
				CW(ListCreditProducts[i]);
			}
			
			Console.Clear();
			CW("\n Для выбора кредита введите номер: \n");
			CreditQueryNumber = Console.ReadLine().Trim();
			
			if (CreditQueryNumber != "")
			{
				for (int j=0; j<=2; j++)
				{
					if (ListCreditProducts[j].Split('-')[0].Trim().Contains(CreditQueryNumber.Trim()) == true)
					{
						CW("\n Вы выбрали: " + ListCreditProducts[j] + ", введите сумму кредита \n");
						ListCreditProductPercent = ListCreditProducts[j].Split('-')[1].Trim();
						CreditProductPercent = Convert.ToByte(ListCreditProductPercent.Split('%')[0].Trim());
					}					
				}
			}

			CreditQuerySumm = Convert.ToDecimal(Console.ReadLine());
			if (CreditQuerySumm > 1000000)
			{
				CreditProductPercent = Convert.ToByte(CreditProductPercent - 2);
			}
			CW("\n Введите срок кредитования:\n");
			CreditQueryPeriod = Convert.ToByte(Console.ReadLine());

			CreditCalculateSumm = MethodCreditCalculateSumm(CreditQuerySumm,CreditQueryPeriod);
			PercentSumm = MethodPercentCalculateSumm(CreditQuerySumm,CreditProductPercent);

			CW("\n Вы дали заявку для получения кредита на сумму " + CreditQuerySumm + " с процентной ставкой " + CreditProductPercent + "%,");
			CW("ежемесячная сумма погашения составляет " + (PercentSumm + CreditCalculateSumm));
		}

		static void CW(string text)
		{
			Console.WriteLine(text);
		}

		static decimal MethodPercentCalculateSumm (decimal CreditSumm = 0, decimal CreditPercent = 0)
		{
			return ((CreditSumm/100)*CreditPercent)/12;
		}

		static decimal MethodCreditCalculateSumm (decimal CreditSumm = 0, byte CreditPeriod = 0)
		{
			return CreditSumm/CreditPeriod;
		} 
	}
}