using System;
using System.Threading;

namespace cash_mashine
{
	public class cash_mashine
	{
		public static void Main(string [] args)
		{
			string[] FoodList = new string[20];
			FoodList[0] = "1 Чай | 120 сом";
			FoodList[1] = "2 Сахар | 50 сом";
			FoodList[2] = "3 Кофе | 350 сом";
			FoodList[3] = "4 Картошка | 30 сом";
			FoodList[4] = "5 Марковка | 20 сом";
			FoodList[5] = "6 Сигареты | 95 сом";
			FoodList[6] = "7 Булочки | 15 сом";
			FoodList[7] = "8 Мороженое | 40 сом";
			FoodList[8] = "9 Соль | 10 сом";
			FoodList[9] = "10 Хлеб | 20 сом";
			FoodList[10] = "11 Уксус | 50 сом";
			FoodList[11] = "12 Конфеты | 220 сом";
			FoodList[12] = "13 Шоколад | 120 сом";
			FoodList[13] = "14 Лепешка | 25 сом";
			FoodList[14] = "15 Молоко | 70 сом";
			FoodList[15] = "16 Банан | 122 сом";
			FoodList[16] = "17 Сливки | 140 сом";
			FoodList[17] = "18 Торт | 420 сом";
			FoodList[18] = "19 Колбаса | 520 сом";
			FoodList[19] = "20 Мясо | 320 сом";

			int ClientChoosedFoodByNumbers;
			int FoodListNumbers;
			//string ClientChoosedFoodByName;
			string ClientEnteredChoise;
			string[] ClientEnteredChoiseArray;
			//string ChoosedFoodList;
			int ClientEnteredChoiseArrayCount;
			decimal ChoosedFoodPrice;
			decimal ChoosedFoodPriceSumm;
			decimal ClientEnteredSumm;

			Console.Clear();
			for (int i=0; i<=19; i++)
			{
				Console.WriteLine(FoodList[i]);
			}
			Console.WriteLine("\n Введите название продукта или номер продукта:\n");
			ClientEnteredChoise =  Console.ReadLine().ToUpper().Trim();

			if (ClientEnteredChoise != "")
			{
				ChoosedFoodPriceSumm = 0;
				Console.WriteLine("\n Выбранные продукты:\n");
				ClientEnteredChoiseArray = ClientEnteredChoise.Split(',');
				ClientEnteredChoiseArrayCount = ClientEnteredChoiseArray.Length;
				for (int i=0; i <= ClientEnteredChoiseArrayCount-1; i++)
				{
					ClientChoosedFoodByNumbers = Convert.ToInt32(ClientEnteredChoiseArray[i]);
					for (int j=0; j<=19; j++)
					{
						FoodListNumbers = Convert.ToInt32(FoodList[j].Split('|')[0].Split(' ')[0].Trim());
						if (FoodListNumbers == ClientChoosedFoodByNumbers)
						{
							Console.WriteLine(FoodList[j]);
							ChoosedFoodPrice = Convert.ToDecimal(FoodList[j].Split('|')[1].Trim().Replace("сом",""));
							ChoosedFoodPriceSumm += ChoosedFoodPrice;
						}
					}
				}
				for (int i=0; i<=40; i++)
				{
					Console.Write("=");
					Thread.Sleep(100);
				}
				Console.WriteLine("\n Общая сумма к оплата: " + ChoosedFoodPriceSumm + " сом\n");
				Console.Write(" Введите сумму: ");
				ClientEnteredSumm = Convert.ToDecimal(Console.ReadLine());
				if (ClientEnteredSumm == ChoosedFoodPriceSumm)
				{
					Console.WriteLine("\n Спасибо за покупку!");
				}
				else if (ClientEnteredSumm > ChoosedFoodPriceSumm)
				{
					ChoosedFoodPriceSumm = ClientEnteredSumm - ChoosedFoodPriceSumm;
					Console.WriteLine("\n Спасибо за покупку! Ваша сдача " + ChoosedFoodPriceSumm + " сом");
				}
				else if (ClientEnteredSumm < ChoosedFoodPriceSumm)
				{
					ChoosedFoodPriceSumm = ChoosedFoodPriceSumm - ClientEnteredSumm;
					Console.WriteLine("\n Вам необходимо доплатить " + ChoosedFoodPriceSumm + " сом");
				}
				else
				{
					Console.WriteLine("\nОшибка в программе!");
				}
			}
			else
			{
				Console.WriteLine("\n Очень жаль что вам ничего не понравилось, до свидания!");
			}
		}
	}
}
	