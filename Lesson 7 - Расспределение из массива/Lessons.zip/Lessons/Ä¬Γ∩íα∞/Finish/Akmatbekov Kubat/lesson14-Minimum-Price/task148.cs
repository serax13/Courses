using System;

namespace task148
{
	public class task148
	{
		static void GetCheaperData(string[] productArr, string searchText)
		{
			decimal price = 0;
			decimal minPrice = 0;
			for(int i=0; i<=14; i++)
			{
				if (productArr[i].Trim().Split('-')[1].Contains(searchText) == true)
				{
					price = Convert.ToDecimal(productArr[i].Split('-')[0].Split('$')[0]);
				}
				if (minPrice == 0)
				{
					minPrice = price;
				}
				if (price < minPrice)
				{
					minPrice = price;
				}
			}
			for(int i=0; i<=14; i++)
			{
				if (productArr[i].Trim().Split('-')[1].Contains(searchText) == true)
				{
					price = Convert.ToDecimal(productArr[i].Split('-')[0].Split('$')[0]);
					if (minPrice == price)
					{
						Console.Write("\n Машина с минимальной ценой: " + productArr[i] + "\n");
					}
				}
			}
		}
		public static void Main(string [] args)
		{
			string[] productArr = new string[15];
			productArr[0] = "4000$ - Mercedes";
			productArr[1] = "2500$ - Mercedes";
			productArr[2] = "8000$ - Mercedes";
			productArr[3] = "1500$ - Mercedes";
			productArr[4] = "4500$ - Mercedes";
			productArr[5] = "1800$ - BMW";
			productArr[6] = "7500$ - BMW";
			productArr[7] = "1230$ - BMW";
			productArr[8] = "5200$ - BMW";
			productArr[9] = "22000$ - BMW";
			productArr[10] = "1777$ - Audi";
			productArr[11] = "3200$ - Audi";
			productArr[12] = "8654$ - Audi";
			productArr[13] = "1234$ - Audi";
			productArr[14] = "8356$ - Audi";

			for (int i=0; i<=14; i++)
			{
				Console.WriteLine(productArr[i]);
			}
			Console.WriteLine("Введите марку: ");
			string searchText = Console.ReadLine().Trim();
			GetCheaperData(productArr,searchText);
			Console.ReadKey();
		}
	}
}