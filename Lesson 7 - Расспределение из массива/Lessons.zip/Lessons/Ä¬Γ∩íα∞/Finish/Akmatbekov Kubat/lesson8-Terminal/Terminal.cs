using System;
 
namespace Terminal
{
	public class Terminal
    {
        public static void Main(string [] args)
      	{
      		string[] ChooseService = new string[2];
      		ChooseService[0] = "1 - Оплата за Игры";
      		ChooseService[1] = "2 - Оплата за коммунальные услуги";

      		string[] ChooseGame = new string[6];
      		ChooseGame[0] = "1 - Танки - 50 сом";
      		ChooseGame[1] = "2 - Warface - 200 сом";
      		ChooseGame[2] = "3 - Королевство - 500 сом";
      		ChooseGame[3] = "4 - Техномагия - 750 сом";
      		ChooseGame[4] = "5 - Strife - 835 сом";
      		ChooseGame[5] = "6 - Prime World - 1500 сом";

      		string[] ChooseUtilityBills = new string[3];
      		ChooseUtilityBills[0] = "1 - Домофон";
      		ChooseUtilityBills[1] = "2 - Газ";
      		ChooseUtilityBills[2] = "3 - Отопление";

            string[] CellOperatorO = new string[10];
			CellOperatorO[0] = "700";
			CellOperatorO[1] = "701";
			CellOperatorO[2] = "702";
			CellOperatorO[3] = "702";
			CellOperatorO[4] = "702";
			CellOperatorO[5] = "702";
			CellOperatorO[6] = "702";
			CellOperatorO[7] = "702";
			CellOperatorO[8] = "702";
			CellOperatorO[9] = "702";

			string[] CellOperatorMegacom = new string[10];
			CellOperatorMegacom[0] = "550";
			CellOperatorMegacom[1] = "551";
			CellOperatorMegacom[2] = "552";
			CellOperatorMegacom[3] = "553";
			CellOperatorMegacom[4] = "554";
			CellOperatorMegacom[5] = "555";
			CellOperatorMegacom[6] = "556";
			CellOperatorMegacom[7] = "557";
			CellOperatorMegacom[8] = "558";
			CellOperatorMegacom[9] = "559";

			string[] CellOperatorBeeline = new string[10];
			CellOperatorBeeline[0] = "770";
			CellOperatorBeeline[1] = "771";
			CellOperatorBeeline[2] = "772";
			CellOperatorBeeline[3] = "773";
			CellOperatorBeeline[4] = "774";
			CellOperatorBeeline[5] = "775";
			CellOperatorBeeline[6] = "776";
			CellOperatorBeeline[7] = "777";
			CellOperatorBeeline[8] = "778";
			CellOperatorBeeline[9] = "779";

			byte ChooseNumber = 0; //Номер действия в меню
			decimal PaymentSumm = 0; //Сумма платежа которая заранее предопределна
			decimal EnteredPaymentSumm = 0; //Сумма платежа введенная пользователем
			decimal BonusFromPayment = 0; //Для возврата денег или зачисления бонусов
			string CellPhoneNumber;
			string CellOperators;
			bool ChoosedServiceState = false;
			bool ChoosedGameState = false;
			bool ChoosedUtilitiesState = false;

		 	// Цикл консоли для повторного ввода.
      		//while (true)
        	//{
		   		// Команда для очистки консоли.
		   		Console.Clear(); 
		  		Console.WriteLine("\nВведите услугу: \n");
		  		string SearchService = Console.ReadLine();
				// Выбор услуги
				for (int i=0; i<=1; i++)
				{
					if (ChooseService[i].ToUpper().Trim().Contains(SearchService.ToUpper().Trim()) == true)
					{
						Console.WriteLine("\nЧто бы выбрать нажмите соответствующую кнопку: " + ChooseService[i] + "\n");
						ChoosedServiceState = true;
					}
				}
				for (int j=0; j<=5; j++)
				{
					if (ChooseGame[j].ToUpper().Trim().Contains(SearchService.ToUpper().Trim()) == true)
					{
						Console.WriteLine("\nЧто бы оплатить введите сумму: " + ChooseGame[j] + "\n");
						ChoosedGameState = true;
						ChooseNumber = Convert.ToByte(ChooseGame[j].Split('-')[0].Trim());
					}
				}
				for (int k=0; k<=2; k++)
				{
					if (ChooseUtilityBills[k].ToUpper().Trim().Contains(SearchService.ToUpper().Trim()) == true)
					{
						ChooseNumber = Convert.ToByte(ChooseUtilityBills[k].Split('-')[0].Trim());
						if (ChooseNumber == 1)
						{
							Console.WriteLine("\nВыберите дальнейшее действие: " + ChooseUtilityBills[k] + "\n");	
						}
						ChoosedUtilitiesState = true;
					}
				}

				if (ChoosedServiceState == true)
				{
					ChooseNumber = Convert.ToByte(Console.ReadLine());
					Console.Clear();
					if (ChooseNumber == 1)
					{
						ChoosedGameState = true;
					}
					if (ChooseNumber == 2)
					{
						ChoosedUtilitiesState =true;
					}
				}

				if (ChoosedGameState == true)
				{
					if (ChoosedServiceState == true && ChoosedGameState == true)
					{
						for (int j=0; j<=5; j++)
						{
							Console.WriteLine(ChooseGame[j]);
						}
						Console.WriteLine("\nВыберите дальнейшее действие: \n");
						ChooseNumber = Convert.ToByte(Console.ReadLine().ToUpper().Trim());
						Console.WriteLine("\nВведите сумму для оплаты:\n");	
					}
					if (ChooseNumber == 1)
						{
							PaymentSumm = 50;
						}
						else if (ChooseNumber == 2)
						{
							PaymentSumm = 200;
						}
						else if (ChooseNumber == 3)
						{
							PaymentSumm = 500;
						}
						else if (ChooseNumber == 4)
						{
							PaymentSumm = 750;
						}
						else if (ChooseNumber == 5)
						{
							PaymentSumm = 835;
						}
						else if (ChooseNumber == 6)
						{
							PaymentSumm = 1500;
						}
					
					EnteredPaymentSumm = Convert.ToDecimal(Console.ReadLine());
					if (EnteredPaymentSumm == PaymentSumm)
					{
						Console.WriteLine("\nПлатеж прошел успешно на " + PaymentSumm + " сом!");
					}
					else if (EnteredPaymentSumm > 0 && EnteredPaymentSumm <= 5000)
					{
						BonusFromPayment = EnteredPaymentSumm - PaymentSumm; 
						Console.WriteLine("\nПлатеж прошел успешно на " + PaymentSumm + " сом, для получения остатка " + BonusFromPayment + " сом, введите номер телефона.\n");
					}
					else
					{
						Console.WriteLine("Введенная сумма большая!");
					}
				}

				if (ChoosedUtilitiesState == true)
				{
					if (ChoosedServiceState == true && ChoosedUtilitiesState == true)
					{
						for (int k=0; k<=2; k++)
						{
							Console.WriteLine(ChooseUtilityBills[k]);
						}
						Console.WriteLine("\nВыберите дальнейшее действие: \n");
						ChooseNumber = Convert.ToByte(Console.ReadLine());
					}
					
					
					if (ChooseNumber == 1)
					{
						Console.WriteLine("\n 1 - Оплата за месяц - 100 сом\n 2 - Предоплата \n");
						ChooseNumber = Convert.ToByte(Console.ReadLine());
						if (ChooseNumber == 1)
						{
							PaymentSumm = 100;
							Console.WriteLine("\nПлатеж прошел успешно на " + PaymentSumm + " сом.");
						}
						else if (ChooseNumber == 2)
						{
							Console.WriteLine("\nВведите количество месяцев: \n");
							byte PaymentMonth = Convert.ToByte(Console.ReadLine());
							PaymentSumm = PaymentMonth * 100;
							BonusFromPayment = Convert.ToDecimal((PaymentSumm / 100) * 7);
							if (PaymentMonth >=2 && PaymentSumm <=5000)
							{
								Console.WriteLine("\nПлатеж прошел успешно на " + PaymentSumm + " сом, для получения бонуса " + BonusFromPayment + " сом, введите номер телефона.\n");
							}
							else
							{
								Console.WriteLine("\nВведенна большая сумма!");
							}
						}
					}
					else if (ChooseNumber == 2 || ChooseNumber == 3)
					{
						Console.WriteLine("\nВведите сумму оплаты:\n");
						EnteredPaymentSumm = Convert.ToDecimal(Console.ReadLine().Trim());
						if (EnteredPaymentSumm > 0 && EnteredPaymentSumm <= 5000)
						{
							Console.WriteLine("\nПлатеж прошел успешно на " + EnteredPaymentSumm + " сом.\n");
						}
						else
						{
							Console.WriteLine("\nВведенна большая сумма!");	
						}
					}
				}

				if (BonusFromPayment > 0)
				{
					CellPhoneNumber = Console.ReadLine().ToUpper().Trim();
					if (CellPhoneNumber.Length == 10 || CellPhoneNumber.Length == 13)
					{
						CellOperators = CellPhoneNumber.Trim().Substring(1,3);
						for (int o=0; o<=9; o++)
						{
							if (CellOperatorO[o].Contains(CellOperators) == true)
							{
								Console.WriteLine("\nВаш сотовый оператор O!\n");
								Console.WriteLine("\nДеньги зачислены на номер: " + CellPhoneNumber);
							}
						}
						for (int m=0; m<=9; m++)
						{
							if (CellOperatorMegacom[m].Contains(CellOperators) == true)
							{
								Console.WriteLine("\nВаш сотовый оператор Megacom!\n");
								Console.WriteLine("\nДеньги зачислены на номер: " + CellPhoneNumber);
							}
						}
						for (int b=0; b<=9; b++)
						{
							if (CellOperatorBeeline[b].Contains(CellOperators) == true)
							{
								Console.WriteLine("\nВаш сотовый оператор Beeline!\n");
								Console.WriteLine("\nДеньги зачислены на номер: " + CellPhoneNumber);
							}
						}					
					}
					else
					{
						Console.WriteLine("Введен не правильный формат!");
					}
				}
				
			//} закрытие цикла

			//Console.ReadKey();
		}
	}
}