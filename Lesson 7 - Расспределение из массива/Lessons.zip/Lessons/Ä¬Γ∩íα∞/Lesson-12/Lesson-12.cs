using System;

namespace Lesson12
{
	public class Lesson12
	{
		static void ShowProducts()
		{
			Console.WriteLine("1 - 15% godovuh vid credita ipotechtui");
			Console.WriteLine("2 - 27% godovuh vid credita potrebitelskii");
			Console.WriteLine("3 - 35% godovuh vid credita avto credit");
		}
		
		static decimal GetPercentSum(decimal Sum, decimal Percent)
		{
			if(Sum > 1000000)
			{
				Percent = Percent - 2;
			}
			decimal PercentSum = ((Sum / 100) * Percent);
			return PercentSum;
		}
		
		public static void Main(string [] agrs)
		{
			ShowProducts();
			
			Console.WriteLine("Vuberite vid credita:");
			string Vubor = Console.ReadLine();
			int mecias = 12;
			if(Vubor == "1")
			{
				Console.WriteLine("Vu vubrali ipotechnui credit 15% Vvedite summu credita");
				decimal summaCredita = Convert.ToDecimal(Console.ReadLine());
				decimal summaProcent = GetPercentSum(summaCredita, 15);
				Console.WriteLine("Summa credita "+summaCredita+" ejemesiachnaia oplata "+(summaCredita+summaProcent) / mecias);
			}
			if(Vubor == "2")
			{
				Console.WriteLine("Vu vubrali potrebitelskii credit 27% Vvedite summu credita");
				decimal summaCredita = Convert.ToDecimal(Console.ReadLine());
				decimal summaProcent = GetPercentSum(summaCredita, 27);
				Console.WriteLine("Summa credita "+summaCredita+" ejemesiachnaia oplata "+(summaCredita+summaProcent) / mecias);
			}
			if(Vubor == "3")
			{
				Console.WriteLine("Vu vubrali avto credit 35% Vvedite summu credita");
				decimal summaCredita = Convert.ToDecimal(Console.ReadLine());
				decimal summaProcent = GetPercentSum(summaCredita, 35);
				Console.WriteLine("Summa credita "+summaCredita+" ejemesiachnaia oplata "+(summaCredita+summaProcent) / mecias);
			}
		}
	}
}