﻿using System;

namespace Task_5
{
	public class Task_5
	
	{
		static void GetWordChislo(int Chislo)
		{	
			string[] Words=new string [10];
			Words[0]="один";
			Words[1]="два";
			Words[2]="три";
			Words[3]="четыри";
			Words[4]="пять";
			Words[5]="шесть";
			Words[6]="семь";
			Words[7]="восемь";
			Words[8]="девять";
			Words[9]="десять";
			
			for(int i=0; i<=Chislo; i++)	
			{
				Console.WriteLine((i+1)+"-"+Words[i]); 
			}
			
		}
		public static void Main(string [] args)
		{
			GetWordChislo(9);
			
			Console.ReadKey();
		}
	}
}