using System;

namespace Task_2
{
	public class Task_2
	{
		static void GetChislo(int x)
		{			
			Console.WriteLine("�����:"+x+"="+(x*x));
		}
		public static void Main(string [] args)
		{
			GetChislo(30);
			
			Console.ReadKey();
		}
	}
}