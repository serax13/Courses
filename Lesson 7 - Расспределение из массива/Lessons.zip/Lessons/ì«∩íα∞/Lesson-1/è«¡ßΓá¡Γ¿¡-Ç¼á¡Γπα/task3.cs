using System;

namespace Task_3
{
	public class Task_3
	
	{
		static void GetCount(int x)
		{			
			for(int i=0; i<=(x*2); i++)
			{
				Console.WriteLine(i); 
			}
			
		}
		public static void Main(string [] args)
		{
			GetCount(10);
			
			Console.ReadKey();
		}
	}
}