using System;

namespace Lesson1
{
	public class Lesson1
	{
		public static void Main(string [] agrs)
		{
			//======= Test Substring ============//
			string TestSubstr = "0555123456";
			Console.WriteLine("Test Substring");
			Console.WriteLine(TestSubstr.Substring(0,3));
			
			
			//======= Test Trim ================//
			string TestTrim = " ДА ";
			Console.WriteLine("Test Trim");
			if(TestTrim.Trim() == "ДА")
			{
				Console.WriteLine("Trim работает");
			}
			else
			{
				Console.WriteLine("Trim не работает");
			}
			
			//====== Test StartsWith ==========//
			string TestStartsWith = "0555123456";
			Console.WriteLine("Test StartsWith");
			if(TestStartsWith.StartsWith("055") == true)
			{
				Console.WriteLine("StartsWith работает");
			}
			else
			{
				Console.WriteLine("StartsWith работает");
			}
			
			//====== Test EndsWith ==========//
			string TestEndsWith = "0555123456";
			Console.WriteLine("Test EndsWith");
			if(TestEndsWith.EndsWith("456") == true)
			{
				Console.WriteLine("EndsWith работает");
			}
			else
			{
				Console.WriteLine("EndsWith работает");
			}
			
			// ======= Test ToUpper =========//
			string TestToUpper = "abc";
			Console.WriteLine("Test ToUpper abc");
			Console.WriteLine(TestToUpper.ToUpper());
			
			// ======= Test Length =========//
			string TestLength = "ABCD";
			Console.WriteLine("Тест длины текста ABCD");
			Console.WriteLine(TestLength.Length);
			
			
			Console.ReadKey();
		}
	}
}