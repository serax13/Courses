using System;
using System.Threading;

namespace Kassa
{
	public class Kassa
	{
		public static void Main(string[] args)
        {
            string[] Menu = new string[16];
            byte flag = 1;
            string price;
            decimal Sum = 0;

            Menu[1] = "1)Чай|120 сом";
            Menu[2] = "2)Сахар|50 сом";
            Menu[3] = "3)Бананы|85 сом";
            Menu[4] = "4)Вафли|140 сом";
            Menu[5] = "5)Хлеб Бородинский|30 сом";
            Menu[6] = "6)Колбаса|285 сом";
            Menu[7] = "7)Кофе|570 сом";
            Menu[8] = "8)Сок|95 сом";
            Menu[9] = "9)Кетчуп|65 сом";
            Menu[10] = "10)Рис|140 сом";
            Menu[11] = "11)Гречка|80 сом";
            Menu[12] = "12)Макароны|33 сом";
            Menu[13] = "13)Апельсины|112 сом";
            Menu[14] = "14)Картошка|30 сом";
            Menu[15] = "15)Лук|40 сом";
            for (int i = 1; i < 16; i++)
            {
                Console.WriteLine(Menu[i]);
            }
            Console.WriteLine("Выберите продукты");
            while (flag == 1)
            {
                Sum = 0;

                string Vvod = Console.ReadLine();
                Console.WriteLine("Пожалуйста подождите...");
                Console.WriteLine("");
                Console.WriteLine("===================================");
                Console.WriteLine("");
                Thread.Sleep(3000);
                string[] Kody = Vvod.Split(',');

                for (int i = 0; i < Kody.Length; i++)
                {
                    string[] Number = Menu[Convert.ToByte(Kody[i])].Split('|');
                    price = Number[1].Replace("сом", "");
                    Sum += Convert.ToDecimal(price);

                }
                Console.WriteLine("Общая сумма к оплате " + Sum + " сомов");
                decimal oplata = Convert.ToDecimal(Console.ReadLine());
                if (Sum == oplata)
                {
                    Console.WriteLine("Спасибо за покупку!");
                }
                else if (Sum > oplata)
                {
                    Console.WriteLine("Ошибка вводы!");
                }
                else
                {
                    decimal ostatok;
                    ostatok = oplata - Sum;
                    Console.WriteLine("Спасибо за покупку! Ваша сдача " + ostatok + " сом");
                }
            }
        }
    }
}
