using System;
using System.Threading;

namespace lesson10

{
	public class lesson10
	{
		public static void Main(string [] args)	
		{
			while(true)
			{
				Console.Clear();
				int Id = 1;
				Console.WriteLine ("Сколько контактов сохранить?");
				int Count = int.Parse(Console.ReadLine());
				Console.WriteLine ("Введите контакт: ");
				string[] Contact = new string [Count];
				for (int i = 0; i < Count; i++)
				{
					Console.WriteLine("Номер телефона "+Id+": ");
					Contact[i] = Console.ReadLine();
					Id++;
				}
				Console.WriteLine("Ваш список контактов:");
				for (int i = 0; i <= Count-1; i++)
				{
					Console.WriteLine(Contact[i]);
				}
				Console.WriteLine ("Хотите позвонить? Да/Нет");
				string Choose = Console.ReadLine().Trim();
				if(Choose == "да"||Choose =="Да")
				{
					Console.WriteLine ("Введите имя: ");
					string NameChoose = Console.ReadLine();
					for (int i = 0; i <= Count-1; i++)
					{
						if (Contact[i].Split(',')[0] == NameChoose)
						{
							Console.WriteLine ("Вызов "+Contact[i]);
							return;
						}
					}
					
					for (int i = 0; i <= Count-1; i++)
					{
						if (Contact[i].Split(',')[0] != NameChoose)
						{
							Console.WriteLine ("Неверный номер!" );
							return;
						}
					}
			  }
			Console.ReadKey();
		}
	 }
 }
} 