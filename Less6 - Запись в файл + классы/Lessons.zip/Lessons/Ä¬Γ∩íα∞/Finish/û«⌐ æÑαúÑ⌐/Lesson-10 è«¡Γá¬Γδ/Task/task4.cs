using System;
using System.Threading;

namespace lesson9

{
	public class lesson9
	{
		public static void Main(string [] args)

		{
			int n=1;

			string Letters = (Console.ReadLine());
			string[] TextList = Letters.Split(',');

			int Count = Convert.ToInt32(TextList.Length);
			for (int i=0; i<=Count-1; i++)
			{
				//string Letter = TextList[i];
				Console.Write (TextList[i]);
				n++;
				if (n>4)
				{
					n = 1;
					Console.Write("\n");
				}
				Thread.Sleep(50);
			}
		Console.ReadKey();
	 }
 }
} 