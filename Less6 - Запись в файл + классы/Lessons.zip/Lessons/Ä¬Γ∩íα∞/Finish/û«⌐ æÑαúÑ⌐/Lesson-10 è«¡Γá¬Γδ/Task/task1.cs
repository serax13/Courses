using System;
using System.Threading;

namespace lesson9
{
	public class lesson9
	{
		public static void Main(string [] args)
		{
			string Letters = "АБВГДЕЁЖЗИКЛМНОПРСТУФКЦЧШЩЪЫЬЭЮЯ";

			for(int i = 0; i < Letters.Length; i++)
			{
   			Console.WriteLine(Letters[i]);
			}
			
		Console.ReadKey();
	 }
 }
} 