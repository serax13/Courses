using System;

namespace matrix
{
	public class ky

	{
		public static void Main(string [] args)
		{

			decimal SummIgr = 0;
			decimal Bonus = 0;
			string PhoneNumb;
			int Domofon = 0;
			decimal SummDomofon;
			int KollMec;
			decimal SummDomofonVych;
			
			string[] Kod_Operatora = new string[3];
			Kod_Operatora [0] = "055";
			Kod_Operatora [1] = "077";
			Kod_Operatora [2] = "070";
			
			string[] Imya_Operatora = new string[3];
			Imya_Operatora [0] = "MegaCom";
			Imya_Operatora [1] = "BeeLine";
			Imya_Operatora [2] = " Оператора - O ";

			//Поисковик
			string[] SearchMenu = new string[9];
			SearchMenu[0] = "Танки | 50 сом";
			SearchMenu[1] = "War face | 200 сом";
			SearchMenu[2] = "Королевство | 500 сом";
			SearchMenu[3] = "Техномагия | 750 сом";
			SearchMenu[4] = "Strife | 835 сом";
			SearchMenu[5] = "Prime World | 1500 сом";
			SearchMenu[6] = "Домофон | 100 сом";
			SearchMenu[7] = "Газ | 100 сом";
			SearchMenu[8] = "Отопление |  сом";
			

			

			
			for(int i = 0; i <= 8; i++)

			{
				Console.WriteLine("Что вы хотите найти?: ");
				string TextSearch = Console.ReadLine();
				if(SearchMenu[0].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
				
				{   
					Console.WriteLine("Введите сумму оплаты:");
					SummIgr = Convert.ToDecimal (Console.ReadLine());
					if (SummIgr > 0&&SummIgr < 5000)
					{
						if (SummIgr == 50)
						Console.WriteLine("Платеж успешно осуществлен на сумму "+SummIgr+" сомов");
						if(SummIgr > 50)
						{
							Bonus = SummIgr - 50;
							Console.WriteLine("Платеж прошел успешно на сумму 50 из "+SummIgr+" сом, для возврата части суммы "+Bonus+" сом ");
						}
						if (SummIgr < 50)
						{
							Bonus = 50 - SummIgr;
							Console.WriteLine("из за нехватки денежных средств в размере"+Bonus+" сом, сумма которую вы внесли в размере "+SummIgr+" сом будет начислена на ваш номер телефона");
						}
					}
					else
					{
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
					}
				}  // конец кода 1 игры
				// старт кода 2 игры
				if(SearchMenu[1].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
				{   
					Console.WriteLine("Введите сумму оплаты:");
					SummIgr = Convert.ToDecimal (Console.ReadLine());
					if (SummIgr > 0 && SummIgr < 5000)
					{
						if (SummIgr == 200)
						Console.WriteLine("Платеж успешно осуществлен на сумму "+SummIgr+" сом");
						if(SummIgr > 200)
						{
							Bonus = SummIgr - 200;
							Console.WriteLine("Платеж прошел успешно на сумму 200 из "+SummIgr+" сом, для возврата части суммы "+Bonus+" сом ");
						}
						if (SummIgr < 200)
						{
							Bonus = 200 - SummIgr;
							Console.WriteLine("из за нехватки денежных средств в размере "+Bonus+" сом, сумма которую вы внесли в размере "+SummIgr+" сом будет начислена на ваш номер телефона");
						}
					}
					else
					{
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
					}

				}  // конец кода 2 игры
				
				if(SearchMenu[2].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
				{   // старт кода 3 игры
					Console.WriteLine("Введите сумму оплаты:");
					SummIgr = Convert.ToDecimal (Console.ReadLine());
					if (SummIgr > 0 && SummIgr < 5000)
					{
						if (SummIgr == 500)
						Console.WriteLine("Платеж успешно осуществлен на сумму "+SummIgr+" сомов");
						if(SummIgr > 500)
						{
							Bonus = SummIgr - 500;
							Console.WriteLine("Платеж прошел успешно на сумму 500 из "+SummIgr+"сом, для возврата части суммы "+Bonus+" сом");
						}
						if (SummIgr < 500)
						{
							Bonus = 500 - SummIgr;
							Console.WriteLine("из за нехватки денежных средств в размере "+Bonus+" сом, сумма которую вы внесли в размере "+SummIgr+" сом будет начислена на ваш номер телефона");
						}
					}
					else
					{
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
					}
				}  // конец кода 3 игры

				if(SearchMenu[3].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
				{   // старт кода 4 игры
					Console.WriteLine("Введите сумму оплаты:");
					SummIgr = Convert.ToDecimal (Console.ReadLine());
					if (SummIgr > 0 && SummIgr < 5000)
					{
						if (SummIgr == 750)
						Console.WriteLine("Платеж успешно осуществлен на сумму "+SummIgr+" сомов");
						if(SummIgr > 750)
						{
							Bonus = SummIgr - 750;
							Console.WriteLine("Платеж прошел успешно на сумму 750 из "+SummIgr+" сом, для возврата части суммы "+Bonus+" сом ");
						}
						if (SummIgr < 750)
						{
							Bonus = 750 - SummIgr;
							Console.WriteLine("из за нехватки денежных средств в размере "+Bonus+" сом, сумма которую вы внесли в размере "+SummIgr+" сом будет начислена на ваш номер телефона");
						}
					}
					else
						{
							Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
							Console.ForegroundColor = ConsoleColor.Red;
						}
				} // конец кода 4 игры
				
				if(SearchMenu[4].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
				{   
					Console.WriteLine("Введите сумму оплаты:");
					SummIgr = Convert.ToDecimal (Console.ReadLine());
					if (SummIgr > 0 && SummIgr < 5000)
					{
						if (SummIgr == 835)
						Console.WriteLine("Платеж успешно осуществлен на сумму "+SummIgr+" сомов");
						if(SummIgr > 835)
						{
							Bonus = SummIgr - 835;
							Console.WriteLine("Платеж прошел успешно на сумму 835 из "+SummIgr+" сом, для возврата части суммы "+Bonus+" сом ");
						}
							if (SummIgr < 835)
							{
								Bonus = 835 - SummIgr;
								Console.WriteLine("из за нехватки денежных средств в размере "+Bonus+" сом, сумма которую вы внесли в размере "+SummIgr+" сом будет начислена на ваш номер телефона");
							}
					}
					else
						{
							Console.ForegroundColor = ConsoleColor.Red;
							Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
						}
				}  // конец кода 5 игры

				if(SearchMenu[5].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
				{   // старт кода 6 игры
					Console.WriteLine("Введите сумму оплаты:");
					SummIgr = Convert.ToDecimal (Console.ReadLine());
					if (SummIgr > 0 && SummIgr < 5000)
					{
						if (SummIgr == 1500)
						Console.WriteLine("Платеж успешно осуществлен на сумму "+SummIgr+" сом");
						if(SummIgr > 1500)
						{
							Bonus = SummIgr - 1500;
							Console.WriteLine("Платеж прошел успешно на сумму 1500 из "+SummIgr+" сом, для возврата части суммы "+Bonus+" сом введите номер телефона");
						}
							if(SummIgr < 1500)
							{
								Bonus = 1500 - SummIgr;
								Console.WriteLine("из за нехватки денежных средств в размере "+Bonus+" сом, сумма которую вы внесли в размере "+SummIgr+" сом будет начислена в ваш номер телефона");
							}
					}
					else
						{
							Console.ForegroundColor = ConsoleColor.Red;
							Console.WriteLine("Сумма должна быть больше 0 и меньше 5000");
						}
				}  // конец кода 6 игры
					// конец 1ой услуги
			 
				if(SearchMenu[6].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
					
					// старт кода 1 ком услуги
					{ 
						Console.WriteLine("Выберите способ оплаты: 1-Оплата за месяц \n 2-Предоплата");
						Domofon = Convert.ToInt32 (Console.ReadLine());
						if (Domofon == 1)
						{
							Console.WriteLine("Введите оплату за домофон в размере 100 сом");
							SummDomofon = Convert.ToDecimal (Console.ReadLine());
							if (SummDomofon == 100)
							Console.WriteLine("Оплата прошла успешно на сумму "+SummDomofon+" сом");
							else
							Console.WriteLine("Cумма оплаты 100 сом!");
						}
						if (Domofon == 2)
						{
							Console.WriteLine("Введите количество месяца");
							KollMec = Convert.ToInt32 (Console.ReadLine());
							Console.WriteLine("Введите оплату в размере: "+KollMec*100);
							SummDomofon = Convert.ToDecimal(Console.ReadLine());                                         
							Bonus = KollMec*7;
							SummDomofonVych = KollMec*SummDomofon;
							Console.WriteLine("Оплата прошла успешно на сумму"+KollMec*100+" сом, а для получения бонуса в размере (7%) "+Bonus+" сом введите номер телефона: ");
					 	}
					} // конец кода 1 ком услуги
					
					if(SearchMenu[7].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
					{
						Console.ForegroundColor = ConsoleColor.Red;
					 	Console.WriteLine("Извините данная услуга временна недоступна");
					}
					if(SearchMenu[8].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true)
					{
					 	Console.ForegroundColor = ConsoleColor.Red;
					 	Console.WriteLine("Извините данная услуга временна недоступна");
					}
					if (SearchMenu[0].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && SummIgr>50 || SearchMenu[1].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && SummIgr>200 || SearchMenu[2].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && SummIgr>500 || SearchMenu[3].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && SummIgr>750 || SearchMenu[4].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && SummIgr>835 || SearchMenu[5].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && SummIgr>1500 || SearchMenu[5].ToUpper().Trim().Contains(TextSearch.ToUpper().Trim()) == true && Domofon==2 )
					
						Console.WriteLine("Введите номер телефона");
						PhoneNumb = Convert.ToString (Console.ReadLine());
						if (PhoneNumb.Length==10)
						{
							for(int op_pr = 0; op_pr <= 3; op_pr++)
							{
								if(PhoneNumb.StartsWith(Kod_Operatora[op_pr]) == true)
								{
									Console.WriteLine("Ваш баланс "+Imya_Operatora[op_pr]+" пополнен на "+Bonus+" сом ");
									break;
								}
							}	
						}
					
			}

				
			}		 					
		}
	}
