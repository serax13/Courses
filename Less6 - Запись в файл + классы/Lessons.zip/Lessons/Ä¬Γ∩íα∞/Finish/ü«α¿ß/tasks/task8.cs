using System;

namespace tasks
{
  public class task8
  {
    public static void Main(string[] agrs)
    {

      // Creating array of elements
      string[] productArray = new string[10];
      productArray[0] = "1 - Чай | 150 сом";
      productArray[1] = "2 - Сахар | 20 сом";
      productArray[2] = "3 - Мука | 50 сом";
      productArray[3] = "4 - Перец | 30 сом";
      productArray[4] = "5 - Картошка | 23 сом";
      productArray[5] = "6 - Конфеты | 130 сом";
      productArray[6] = "7 - Соль | 20 сом";
      productArray[7] = "8 - Дрожь | 10 сом";
      productArray[8] = "9 - Лук | 15 сом";
      productArray[9] = "10 - Морковь | 20 сом";


      // Display array elements

      for (int i = 0; i <= 9; i++)
      {
        Console.WriteLine(productArray[i]);
      }


      Console.WriteLine("Type in any numbers from 1 to 10 (use ',' as a delimiter):");

      // input numbers to use as indeces
      string input = Console.ReadLine();
      string[] numList = input.Split(',');

      // Display array`s length
      Console.WriteLine("Array`s length is "+numList.Length);

      // Display products using input as indeces
      for (int i = 0; i <= numList.Length-1; i++)
      {
        Console.WriteLine(productArray[Convert.ToInt32(numList[i].Trim())-1]);
      }

      // Calculating total sum of chosen products prices
      decimal sum = 0;
      for (int i = 0; i <= numList.Length-1; i++)
      {
        sum=sum+Convert.ToDecimal(productArray[Convert.ToInt32(numList[i].Trim())-1].Split('|')[1].Replace("сом", ""));
      }

      // Display chosen products` sum
      Console.WriteLine("Total sum is "+sum+" som.");

      Console.ReadKey();
    }
  }
}
