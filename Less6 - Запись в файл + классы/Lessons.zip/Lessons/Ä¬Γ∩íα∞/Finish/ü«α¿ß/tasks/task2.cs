using System;
using System.Threading;


namespace tasks
{
  public class tasks
  {
      public static void Main(string[] agrs)
      {

        int count = 0;
        string abc = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
        string[] abcArr = abc.Split(',');
  			for(int i = 0; i<=abcArr.Length-1; i++)
  			{
  				Console.Write(abcArr[i]);
  				count++;
  				if(count > 4)
  				{
  					count = 0;
  					Console.Write("\n");
  				}
  			}

        Console.ReadKey();
      }
  }
}
