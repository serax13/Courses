using System;
namespace Terminal
{
	public class Terminal
	{
		public static void Main(string [] term)
		{
			decimal MoneyPay=0; // переменная  для ввода суммы
			string PhoneNumber="tel"; // переменная для ввода телефона
			string CheckChoise="0";//переменная для ввода вариантов
			byte LengthNum=0;//переменная для хранения количества символов
			int Month=0;//переменная для ввода количество месяцев
			while(1!=2)//простое зацикливание
			{
				Console.WriteLine("Здравствуйте, выберит услугу:");
				Console.WriteLine("Для оплаты за онлайн игры нажмите - 1");
				Console.WriteLine("Для оплаты за ком.услуги нажмите - 2");
				CheckChoise=Console.ReadLine();
				if(CheckChoise=="1")//код отвечающий за выполнения услуг для оплаты игр
				{
					Console.WriteLine("Выберите игру из предложенных вариантов\n и вводите соответствующие номера игры:");
					Console.WriteLine("1-WorldOfTanks 50сом\n2-Warface 200сом\n3-Kindoms 500сом\n4-TechMagic 750сом\n5-Strike 835сом\n6-PrimeWorld 1500сом");
					CheckChoise=Console.ReadLine();
					switch(CheckChoise)
					{
						case "1":
						CheckPayment(50);
						break;

						case "2":
						CheckPayment(200);
						break;

						case "3":
						CheckPayment(500);
						break;

						case "4":
						CheckPayment(750);
						break;

						case "5":
						CheckPayment(835);
						break;

						case "6":
						CheckPayment(1500);
						break;

						default:
						break;

					}

				}
				else if(CheckChoise=="2") //код отвечающий за выполнения услуг для оплаты комуналки
				{
					Console.WriteLine("Выберите следующие услуги по платежам:");
					Console.WriteLine("1 - Домофон 100сом\n2 - Газ\n3 - Отопление");
					CheckChoise=Console.ReadLine();
					switch(CheckChoise)
					{
						case "3"://Отопление
						Console.WriteLine("Введите сумму оплаты>>");
						MoneyPay=Convert.ToDecimal(Console.ReadLine());
						if(MoneyPay<=0||MoneyPay>5000)
						{
								Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
								Console.WriteLine("Неверная сумма оплаты!!");
								Console.ResetColor();
								//Цвет
						}
						else
						{
								Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
						}
						break;
						case "2"://Газ
						Console.WriteLine("Введите сумму оплаты>>");
						MoneyPay=Convert.ToDecimal(Console.ReadLine());
						if(MoneyPay<=0||MoneyPay>5000)
						{
				        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
								Console.WriteLine("Неверная сумма оплаты!!");
								Console.ResetColor();
								//Цвет
						}
						else
						{
								Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");
						}
						break;
						case "1"://Домофон
						Console.WriteLine("Выберите следующий вариант оплаты>>");
						Console.WriteLine("Оплата за месяц - 1\nПредоплата - 2");
						CheckChoise=Console.ReadLine();
						if(CheckChoise=="1")
						{
								Console.WriteLine("Введите сумму оплаты равной 100 сом>>");
					    	MoneyPay=Convert.ToDecimal(Console.ReadLine());
								if(MoneyPay!=100)
								{
									Console.WriteLine("Сумма оплаты должна быть равной 100сом!!");
								}
								else
								{
									Console.WriteLine("Платеж на сумму "+MoneyPay+" сом успешно завершен");

								}
						}
						else if(CheckChoise=="2")
						{
				        Console.WriteLine("Введите количество месяцев>>");
				        Month=Convert.ToInt32(Console.ReadLine());
								int CheckMoney = Month*100;
								Console.WriteLine("Введите сумму оплаты равной "+CheckMoney+" сом");
					    	MoneyPay=Convert.ToDecimal(Console.ReadLine());
								if(MoneyPay>CheckMoney||MoneyPay<CheckMoney)
								{
										Console.WriteLine("Сумма оплаты должна быть равной "+CheckMoney+" сом!!");
								}
								else
								{
										Console.WriteLine("Платеж на сумму "+CheckMoney+" сом успешно завершен");
										CheckMoney=(Month*100)/100*7;
										Console.WriteLine("Для вывода бонуса в виде единиц введите ваш телефон>>");
										PhoneNumber=Console.ReadLine();
						    		LengthNum=Convert.ToByte(PhoneNumber.Length);
			           		if(LengthNum==10||LengthNum==13)
						    		{
				              	Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+CheckMoney+" сом");
			             	}
			              else
			              {//цвет
						        		Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
				                Console.WriteLine("Данный оператор не существует!");
												Console.ResetColor();
			              }

								}

						}
						break;
						default:
						break;
					}
				}
				else //код вывода ошибки
				{
		        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная команда, повторите еще раз!");
            Console.ResetColor();
				}
				Console.ReadKey();
			}
		}
		public static void CheckPayment(decimal GameSumm)//функция для совершения платежа(также это сокращает код!)
		{
				decimal MoneyPay=0;
				string PhoneNumber;
				byte LengthNum=0;
				Console.WriteLine("Введите сумму оплаты>>");
				MoneyPay=Convert.ToDecimal(Console.ReadLine());
				if(MoneyPay==GameSumm)
				{
						Console.WriteLine("Платеж прошел успешно на сумму " + MoneyPay+" сом");
				}
				else if(MoneyPay>GameSumm &&MoneyPay<5001)
				{
						Console.WriteLine("Платеж прошел успешно на сумму " + GameSumm+" сом");
						Console.WriteLine("Для возврата оставшейся суммы "+(MoneyPay-GameSumm)+" сом \n на баланс введите номер телефона>>");
						PhoneNumber=Console.ReadLine();
						LengthNum=Convert.ToByte(PhoneNumber.Length);
			      if(LengthNum==10||LengthNum==13)
						{
				          Console.WriteLine("Баланс номера - "+PhoneNumber+" успешно пополнен на "+(MoneyPay-GameSumm)+" сом");
	         	}
			      else
            {//цвет
					        Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
			            Console.WriteLine("Данный оператор не существует!");
									Console.ResetColor();
			      }

				}
				else if(MoneyPay>5000||MoneyPay<GameSumm)
				{
           	Console.ForegroundColor = ConsoleColor.Red; // устанавливаем цвет
						Console.WriteLine("Неверная сумма платежа!!");
						Console.ResetColor();
						//цвет
				}

		}
	}
}
