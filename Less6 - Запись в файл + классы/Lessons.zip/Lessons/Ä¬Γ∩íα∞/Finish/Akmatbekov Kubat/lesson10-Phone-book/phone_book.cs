using System;
using System.Threading;

namespace phone_book
{
	public class phone_book
	{
		public static void Main (string [] args)
		{
			// Task Phone Book
			int PhoneBookIndex;
			string UserAnswer;
			string UserEnteredName;
			Console.WriteLine("\n Сколько контактов хотите сохранить?\n");
			PhoneBookIndex = Convert.ToInt32(Console.ReadLine());
			string[] PhoneBookArray = new string[PhoneBookIndex];
			Console.WriteLine("\n Введите имя и номер телефона:\n");
			for (int i = 0; i <= PhoneBookIndex - 1; i++)
			{
				PhoneBookArray[i] = Console.ReadLine().ToUpper().Trim();
			}
			for (int j = 0; j <= PhoneBookIndex - 1; j++)
			{
				Console.WriteLine("\n" + PhoneBookArray[j] + "\n");
			}
			Console.WriteLine("\n Хотите позвонить? Да/Нет\n");
			UserAnswer = Console.ReadLine().ToUpper().Trim();
			//UserAnswer = UserAnswer;
			if (UserAnswer != "")
			{
				if (UserAnswer == "ДА")
				{
					Console.WriteLine("\n Введите имя: \n");
					UserEnteredName = Console.ReadLine().ToUpper().Trim();
					//UserEnteredName = UserEnteredName;
					if (UserEnteredName != "")
					{
						for (int i=0; i <= PhoneBookIndex - 1; i++)
						{
							if (PhoneBookArray[i].Split(',')[0].Contains(UserEnteredName) == true)
							{
								Console.WriteLine("\n Вызов " + PhoneBookArray[i] + " ...");
								return;
							}
						}
						for (int j=0; j <= PhoneBookIndex - 1; j++)
						{
							if (PhoneBookArray[j].Split(',')[0].Contains(UserEnteredName) == false)
							{
								Console.WriteLine("\n Такого имени или номера в справочнике нет! ");
								return;	
							}
						}
					}
					else
					{
						Console.WriteLine("Вы не ввели имя!");
					}
				}
			}
			else
			{
				return;
			}
		}
	}
}