using System;

namespace ZD
{
	public class ZD
	{
		public static void GetData(string[] Car, string searchText)
		{
			for(int i = 0; i<=Car.Length-1;i++)
			{
				if(Car[i].Contains(searchText))
				{
					Console.WriteLine(Car[i]);
				}
			}
		}
		public static void Main(string [] args)
		{
			string[] Car = new string[10]{"2000$ - Merc", "2500$ - Merc", "3100$ - BMW", "1400$ - Mazda", "4000$ - Porsche", "3500$ - Honda", "1000$ - Kopeika", "10$ - Tachka", "10000$ - Limo", "6000$ - Ferrari"};
			GetData(Car, "Merc");
		}
	}
}