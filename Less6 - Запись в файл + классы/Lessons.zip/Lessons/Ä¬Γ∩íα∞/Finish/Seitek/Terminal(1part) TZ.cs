using System;

namespace Terminal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1.Оплата за игры");
            Console.WriteLine("2.Оплата за ком.услуги");

            string Choice1 = Console.ReadLine();
            if (Choice1 == "1")
            {
                Console.WriteLine("1.Tanks 50 сом");
                Console.WriteLine("2.Warface 200 сом");
                Console.WriteLine("3.Kingdom 500 сом");
                Console.WriteLine("4.Technomagic 750 сом");
                Console.WriteLine("5.Strife 835 сом");
                Console.WriteLine("6.Prime World 1500 сом");
                string Choice2 = Console.ReadLine();
                if (Choice2 == "1")
                {
                    Console.WriteLine("Tanks");
                    Console.WriteLine("Введите сумму оплаты");
                    decimal sum = Convert.ToDecimal(Console.ReadLine());
                    if (sum == 50)
                    {
                        Console.WriteLine("Платеж успешен");
                        Console.WriteLine("На баланс зачислено " + sum + " сом");
					}
						if(sum < 50)
						{
							Console.ForegroundColor = ConsoleColor.Red;
							Console.WriteLine("Минимальная сумма платежа - 50 сом");
						}
							if(sum > 5000)
							{
								Console.WriteLine("Максимальная сумма платежа - 5000 сом");
							}
                    else
                    {
                        decimal RestMoney = (sum - 50);
                        Console.WriteLine("Сумма превышает допустимый лимит. На баланс зачислено 50 сом. Для возврата остатка, " + RestMoney + " сом, введите номер телефона");
                        string Number = Console.ReadLine();
                        string[] Num = new string[3];
                        Num[0] = "070";
                        Num[1] = "077";
                        Num[2] = "055";
                        if (Number.Length >= 10 || Number.Length < 14)
                        {
                            if (Number.Substring(0, 3) == Num[0] || Number.Substring(0, 3) == Num[1] || Number.Substring(0, 3) == Num[2])
                            {
                                Console.WriteLine("На номер " + Number + " поступило " + RestMoney + " сом");
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Сотовый оператор с данным кодом не определен");
                            }
							

                        }

                        Console.ReadKey();
                    }
                }
            }
        }
    }
}