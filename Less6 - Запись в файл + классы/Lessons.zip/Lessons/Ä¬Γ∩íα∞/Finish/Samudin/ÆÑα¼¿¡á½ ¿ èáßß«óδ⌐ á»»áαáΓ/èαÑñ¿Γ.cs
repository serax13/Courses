using System;
using System.Threading;

namespace Lesson10
{
	public class Lesson10
	{
		static decimal creditSum(decimal sum, decimal percent)
		{
			if(sum > 1000000)
			{
				percent -= 2;
			}
			decimal percentSum = (((sum/100)*percent)/12);
			return percentSum;
		} 
		public static void Main(string [] agrs)
		{	
			Console.WriteLine("Добро пожаловать в 'СБЕРБАНК'".ToUpper());
			string[] credit = new string [3];
			credit[0] = "1 - 15% годовых вид кредита: ипотечный";
			credit[1] = "2 - 27% годовых вид кредита: потребительский";
			credit[2] = "3 - 35% годовых вид кредита: авто кредит";
			for(int i = 0; i <= credit.Length - 1; i++)
			{
				Console.WriteLine(credit[i].Trim());
			}
			Console.WriteLine("Выберите вид кредита:");
			string selectCredit = Console.ReadLine();
			if(selectCredit == "1")
			{
				Console.WriteLine("Подождите пожалуйста...");
				for(int i = 1; i <= 30; i++)
				{
				Console.Write("=");
				Thread.Sleep(100);
				}
				Console.WriteLine("");
				Console.WriteLine("Вы выбрали: 15% годовых вид кредита: ипотечный!");
				Console.WriteLine("Введите сумму: ");
				decimal summa = Convert.ToDecimal(Console.ReadLine());
				decimal procent = creditSum(summa, 15);
				Console.WriteLine("Вы подали заявку для получения кредита на сумму " + summa + " с процентной ставкой 15%");
				Console.WriteLine("Ежемесячная сумма погашения составляет: " + (summa + procent) / 12);
			}
			if(selectCredit == "2")
			{
				Console.WriteLine("Подождите пожалуйста...");
				for(int i = 1; i <= 30; i++)
				{
				Console.Write("=");
				Thread.Sleep(100);
				}
				Console.WriteLine("");
				Console.WriteLine("Вы выбрали: 27% годовых вид кредита: потребительский");
				Console.WriteLine("Введите сумму: ");
				decimal summa = Convert.ToDecimal(Console.ReadLine());
				decimal procent = creditSum(summa, 27);
				Console.WriteLine("Вы подали заявку для получения кредита на сумму " + summa + " с процентной ставкой 27%");
				Console.WriteLine("Ежемесячная сумма погашения составляет: " + (summa + procent) / 12);
			}
			if(selectCredit == "3")
			{
				Console.WriteLine("Подождите пожалуйста...");
				for(int i = 1; i <= 30; i++)
				{
				Console.Write("=");
				Thread.Sleep(100);
				}
				Console.WriteLine("");
				Console.WriteLine("Вы выбрали: 35% годовых вид кредита: авто кредит");
				Console.WriteLine("Введите сумму: ");
				decimal summa = Convert.ToDecimal(Console.ReadLine());
				decimal procent = creditSum(summa, 35);
				Console.WriteLine("Вы подали заявку для получения кредита на сумму " + summa + " с процентной ставкой 35%");
				Console.WriteLine("Ежемесячная сумма погашения составляет: " + (summa + procent) / 12);
			}
			Console.ReadKey();
		}		
	}		
}			