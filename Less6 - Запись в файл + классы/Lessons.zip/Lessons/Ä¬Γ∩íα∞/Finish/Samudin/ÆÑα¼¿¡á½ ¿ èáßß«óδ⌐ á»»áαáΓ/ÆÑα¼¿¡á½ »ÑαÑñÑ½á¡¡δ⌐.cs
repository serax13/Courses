using System;
namespace Homework
{
    public class Homework
    {
        static int GetInputService(string select)
        {
            Console.WriteLine(select + "1 - Игры | 2 - Коммунальные услуги");
            int selected = Convert.ToInt32(Console.ReadLine());
            return selected;
        }
        static string[] fuckingService(int selectedService, string[] games, string[] service)
        {
            switch(selectedService)
            {
                case 1: return games; break;
                case 2: return service; break;
                default: throw new Exception("Ошибка " + selectedService); break;
            }
        }
		static string[] Games()
		{
			string[] games = new string[]{"1) Танки | 50", "2) Warface | 200", "3) Королевство | 500", "4) Техномагия | 750", "5) Strife | 835", "6) Prime World | 1500"};
    		return games;
		}
		static string[] Service()
		{
			string[] service = new string[]{"1) Домофон | 100", "2) Газ | 200", "3) Отопление | 300"};
    		return service;
		}
        static string[] innerService()
        {
            string[] innerService = new string[]{"1) Оплата за месяц", "2) Предоплата"};
            return innerService;
        }
		static void Information(string[] info)
		{
			for(int i = 0; i < info.Length; i++)
			{
				Console.WriteLine(info[i]);
			}
		}
        static string SelectInput(string[] selectList)
        {
            Console.WriteLine("Выбор услуги из списка:");
            Information(selectList);
            string input = Console.ReadLine();
            string selected = string.Empty;
            for (int i = 0; i < selectList.Length; i++)
            {
                bool isTrue = selectList[i].StartsWith(input);
                if(isTrue)
                {
                    selected = selectList[i];
                    return selected;
                }
            }
            throw new Exception("ERROR 505!!!");
        }
        static void Pay(string payInner)
        {
            int payment = Convert.ToInt32(payInner.Split('|')[1].Trim());
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("К оплате " + payment + " Cом");
            Console.ForegroundColor = ConsoleColor.White;
            int oplata = Convert.ToInt32(Console.ReadLine());
            if(oplata < payment)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Недостаточно денег для оплаты!!!".ToUpper());
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if(oplata == payment)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Спасибо за оплату!!!".ToUpper());
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if(oplata > 5000)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Максимальная сумма 5000!".ToUpper());
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                int result = oplata - payment;
                Console.WriteLine("Оплата совершена на сумму " + payment);
                Console.WriteLine("Сдача составляет " + result + " Сом" );
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(result + " Cом будет отправлен на Ваш номер");
                Console.WriteLine("Введите ваш номер: ");
                string phoneNumber = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(phoneNumber + " пополнен на " + result + " Сом");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    	public static void Main (string [] args)
    	{
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Терминал 'Банк Азии'".ToUpper());
            Console.ForegroundColor = ConsoleColor.White;
            string[] games = Games();
            string[] service = Service();
            int inputService = GetInputService("Выберите услугу: ");
            string[] selectList = fuckingService(inputService, games, service);
            string payInner = SelectInput(selectList);
            Pay(payInner);
    		Console.ReadKey();
    	}	
    }		
}    		