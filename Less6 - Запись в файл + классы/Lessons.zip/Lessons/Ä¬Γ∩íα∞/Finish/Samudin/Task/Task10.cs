using System;
namespace Task10
{
    public class Task10
    {
    	static void CW(string text)
    	{
    		Console.WriteLine(text);
    	}
    	static string[] Contacts(int x)
    	{
    		int x = Convert.ToInt32(Console.ReadLine());
    		int numbers = Convert.ToInt32();
    		string[] numbers = new string[]{1++};
    		for(int i = 0; i < numbers.Length; i++)
    		{
    			Console.WriteLine("Номер телефона " + numbers +": ");
    		}
    	}
    	public static void Main (string [] args)
    	{
    		Console.ForegroundColor = ConsoleColor.Yellow;
    		CW("Ваша телефонная книжка!!!".ToUpper());
    		Console.ForegroundColor = ConsoleColor.White;
    		CW("Сколько контактов хотите сохранить: ");
    		int input = Convert.ToInt32(Console.ReadLine());
    	}	
    }		
}