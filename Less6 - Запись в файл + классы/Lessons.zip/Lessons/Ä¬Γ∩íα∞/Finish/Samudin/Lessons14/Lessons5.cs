using System;
using System.Threading;

namespace Lessons2
{
    public class Lessons2
    {
    	static void zvezdochka()
    	{  
            for(int i = 5; i >= 1; i--)
            {
                for(int j = i; j >= 1; j--)
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
                Thread.Sleep(100);
            }
    	}
    	public static void Main (string [] args)
    	{
            zvezdochka();
    	}	
    }		
}   