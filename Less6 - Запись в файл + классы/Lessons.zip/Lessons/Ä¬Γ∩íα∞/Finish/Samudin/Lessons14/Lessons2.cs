using System;

namespace Lessons2
{
    public class Lessons2
    {
    	static void Hello()
    	{  
            int numbers = 0;
            for(int i = 1; i <= 10; i++)
            {
                numbers++;
                Console.WriteLine(numbers + " - Hello World");
            }
    	}
    	public static void Main (string [] args)
    	{
            Hello();
    	}	
    }		
}    		