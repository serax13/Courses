using System;
namespace Lessons3
{
    public class Lessons3
    {
    	static decimal Plus(decimal firstInput, decimal secondInput)
    	{
    		decimal sum = firstInput + secondInput;
    		return sum;
    	}
    	static decimal Sub(decimal firstInput, decimal secondInput)
    	{
    		decimal sum = firstInput - secondInput;
    		return sum;
    	}
    	static decimal Breeding(decimal firstInput, decimal secondInput)
    	{
    		decimal sum = firstInput * secondInput;
    		return sum;
    	}
    	static decimal Division(decimal firstInput, decimal secondInput)
    	{
    		decimal sum = firstInput / secondInput;
    		return sum;
    	}
    	public static void Main (string [] args)
    	{
    		Console.WriteLine("Введите число: ");
    	    decimal firstInput = Convert.ToDecimal(Console.ReadLine());
    		Console.WriteLine("Введите число: ");
    		decimal secondInput = Convert.ToDecimal(Console.ReadLine());
    		Console.WriteLine("Выберите операцию: '+' '-' '*' '/'");
    		string oper = Console.ReadLine();
    		if(oper == "+")
    		{
    			Plus(firstInput, secondInput);
    			Console.WriteLine("Ответ: " + Plus(firstInput, secondInput));
    		}
    		else if(oper == "-")
    		{
    			Sub(firstInput, secondInput);
    			Console.WriteLine("Ответ: " + Sub(firstInput, secondInput));
    		}
    		else if(oper == "*")
    		{
    			Breeding(firstInput, secondInput);
    			Console.WriteLine("Ответ: " + Breeding(firstInput, secondInput));
    		}
    		else if(oper == "/")
    		{
    			if (secondInput == 0)
    			{
					Console.WriteLine("ERROR");
                    return;
    			}
    			else
    			{
					Console.WriteLine(firstInput/secondInput);
    			}
    			Division(firstInput, secondInput);
    			Console.WriteLine("Ответ: " + Division(firstInput, secondInput));
			}
			Console.ReadKey();
	    }
    }	
}