using System;

namespace Lesson10
{
	public class Lesson10
	{
		static void CW(string text)
		{
			Console.WriteLine(text);
		}
		static decimal Tax(decimal sum)
    	{
    		int percent = 20;
    		decimal percentSum = ((sum*percent)/100);
    		decimal resultTax = (sum-percentSum);
			return resultTax;
    	}
    	static decimal Hour(decimal sum)
    	{
    		int hour = 8;
    		int days = 25;
    		decimal resultHour = ((sum/days)/hour);
    		return resultHour;
    	}
    	static decimal Day(decimal sum)
    	{
    		int days = 25;
    		decimal resultDay = (sum/days);
    		return resultDay;
    	}
		static decimal Week(decimal sum)
    	{
    		int daysWeek = 5;
    		decimal resultWeek = (sum/daysWeek);
    		return resultWeek;
    	}
    	static decimal IncomeYear(decimal sum)
    	{
    		int month = 12;
    		decimal resultIncomeyear = (sum*month);
    		return resultIncomeyear;
    	}
    	static decimal Salary(decimal sum)
    	{
    		int percent = 20;
    		int month = 12;
    		decimal percentSum = ((sum*percent)/100);
    		decimal resultPercent = (sum-percentSum);
    		decimal resultSalary = (resultPercent*month);
    		return resultSalary;
    	}
		public static void Main(string [] agrs)
		{
			decimal sum = 25000;
			CW("1 - Зарплата: " + sum);
			CW("2 - " + sum + " сом налог 20%");
			CW("3 - На руки вы получаете: " + Tax(sum) + " сом в месяц");
			CW("4 - За час вы зарабатываете: " + Hour(sum) + " сом");
			CW("5 - В день зарабатываете: " + Day(sum) + " сом ");
			CW("6 - В неделю вы зарабатываете: " + Week(sum) + " сом");
			CW("7 - Ваш годовой доход составляет: " + IncomeYear(sum) + " сом");
			CW("8 - Чистая зарплата в год: " + Salary(sum) + " сомов");
		}	
	}		
}			