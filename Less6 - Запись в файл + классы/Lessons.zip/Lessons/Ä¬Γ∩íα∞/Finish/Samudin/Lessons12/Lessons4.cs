using System;
namespace Lessons3
{
    public class Lessons3
    {
    	static decimal persent(decimal sum, decimal percent)
    	{
    		decimal percentSum = ((sum/100)*percent);
			return percentSum;
    	}
    	public static void Main (string [] args)
    	{
    		Console.WriteLine("Введите число: ");
    	    decimal sum = Convert.ToDecimal(Console.ReadLine());
    		Console.WriteLine("Введите процент: ");
    		decimal percent = Convert.ToDecimal(Console.ReadLine());
    		Console.WriteLine("Результат: " + persent(sum,percent));
    	}
    }
}