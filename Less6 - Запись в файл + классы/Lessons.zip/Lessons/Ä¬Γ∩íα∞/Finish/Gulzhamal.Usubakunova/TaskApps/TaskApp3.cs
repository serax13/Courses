using System;

namespace TaskApp3
{
	public class TaskApp3
	{
		
		public static void Main(string [] agrs)
		{
			decimal SumOfNumbers=0;
			decimal[] Number = new decimal[10]; 
			Number[0]=10;
			Number[1]=20;
			Number[2]=13;
			Number[3]=89;
			Number[4]=1;
			Number[5]=34;
			Number[6]=9;
			Number[7]=45;
			Number[8]=78;
			Number[9]=19;
			
			for(int i=0;i<=9;i++)
			{
				SumOfNumbers+=Number[i];
			}
			Console.WriteLine(SumOfNumbers);
			
		}
		
	}
						
}