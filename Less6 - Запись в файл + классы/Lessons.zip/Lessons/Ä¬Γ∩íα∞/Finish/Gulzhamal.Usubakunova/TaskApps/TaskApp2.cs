using System;

namespace TaskApp2
{
	public class TaskApp2
	{
		
		public static void Main(string [] agrs)
		{
			string[] Alphabet = new string[33]; // массив продуктов
			Alphabet[0]="A";
			Alphabet[1]="Б";
			Alphabet[2]="В";
			Alphabet[3]="Г";
			Alphabet[4]="Д";
			Alphabet[5]="Е";
			Alphabet[6]="Ё";
			Alphabet[7]="Ж";
			Alphabet[8]="З";
			Alphabet[9]="И";
			Alphabet[10]="Й";
			Alphabet[11]="К";
			Alphabet[12]="Л";
			Alphabet[13]="М";
			Alphabet[14]="Н";
			Alphabet[15]="О";
			Alphabet[16]="П";
			Alphabet[17]="Р";
			Alphabet[18]="С";
			Alphabet[19]="Т";
			Alphabet[20]="У";
			Alphabet[21]="Ф";
			Alphabet[22]="Х";
			Alphabet[23]="Ц";
			Alphabet[24]="Ч";
			Alphabet[25]="Ш";
			Alphabet[26]="Щ";
			Alphabet[27]="Ъ";
			Alphabet[28]="Ы";
			Alphabet[29]="Ь";
			Alphabet[30]="Э";
			Alphabet[31]="Ю";
			Alphabet[32]="Я";
			
		
			int n = 1;
			for(int i = 0; i<=32; i++)
			{
				Console.Write(" | "+Alphabet[i]);
				n++;
				if(n > 5)
				{
					n = 1;
					Console.Write("\n\n");
				}
				
			}
			
			
		}
		
	}
	
			
				
}