using System;

namespace TaskApp6
{
	public class TaskApp6
	{
		
		public static void Main(string [] agrs)
		{
			Console.WriteLine("Введите цифры от 1 до 10 через запятую");
			
			string Numbers = Console.ReadLine();
			string[] NumbersArray= Numbers.Split(',');
			int NumbersLength=NumbersArray.Length;
			
			Console.WriteLine("Длина массива = "+NumbersLength);
			
			for(int i = 0; i <= NumbersLength-1; i++)
			{
				Console.Write (NumbersArray[i]+"\t");
				
			}
			
			
		}
	
	}
						
}