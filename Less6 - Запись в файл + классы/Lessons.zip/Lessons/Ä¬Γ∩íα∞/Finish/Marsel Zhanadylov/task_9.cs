using System;
namespace MARSEL
{
public class task_9
	{
		public static void Main()
		{
			for(int i = 10; i >= 1; i--)
			{
				 Console.WriteLine(i);
			}
		}
	}	
}