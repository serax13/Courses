using System;
namespace MARSEL
{
	public class task_1
	{
		public static void Main(string[] args)
		{
			string [] Alphabet = 
			{
				"а,б,в,г,д,е,ё,ж,з,и,л,м,н,о,п,р,с,т,у,ф,х,ц,ч,ш,щ,ъ,ы,ь,э,ю,я\n"
			};
			
			for(int i = 0; i <= Alphabet.Length-1; i++)
			{
				Console.WriteLine(Alphabet[i].ToUpper());
			} 
				
		}
	}
}
