using System;
namespace MARSEL
{
	public class PhoneBook
	{
		public static void Main()
		{
			Console.WriteLine("\tСколько контактов хотите сохранить?");
			int NumberCount = Convert.ToInt32(Console.ReadLine());
			string [] PhoneList = new string [NumberCount];
			
			for(int i = 0; i <= NumberCount-1;i++)
			{
				Console.WriteLine("\tВведите имя и номер контактов:"+(i+1));
				PhoneList[i] = Console.ReadLine(); 
			}
				Console.Clear();
			for(int j = 0; j <= PhoneList.Length-1;j++)
			{
				Console.WriteLine(PhoneList[j]);
			}
			Console.WriteLine("\tХотите позвонить? da/net ");
			string call = Console.ReadLine();
			string name = "";
			string call2 = "";
			if(call.Trim().ToUpper() == "DA")
			{
				Console.WriteLine("\tВведите имя:");
				name = Console.ReadLine();
				for(int r = 0; r <= NumberCount-1;r++)
				{
				if(PhoneList[r].Contains(name)==true)
					call2 = PhoneList[r];
				}
				if(call2.Contains(name)==true)
				{
					Console.WriteLine("Вызов " + call2 + "...");
				}
				else 
					Console.WriteLine("Контакт не найден.");
			}
			if(call.Trim().ToUpper() == "NET")
			{	
				Console.WriteLine("Спасибо, ваши контакты сохранены.");
			}	
		}
	}
}
				