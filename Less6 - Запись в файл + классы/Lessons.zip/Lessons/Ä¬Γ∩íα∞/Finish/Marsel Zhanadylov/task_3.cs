using System;
namespace MARSEL {
	public class task_3
	{
	public static void Main()
	{
	decimal [] array1 = {12,23,34,5,8,2,56,4,9,7,15,18,87,29,16,1,0};
		Array.Sort(array1);
		int count = 0;
		decimal sum = 0;
		
		for(int i = 0;i <=array1.Length-1;i++)
		{
			    Console.WriteLine(array1[i]);
				count++;
				sum = sum + Convert.ToDecimal(array1[i]);
		}
		Console.BackgroundColor = ConsoleColor.DarkYellow;
		Console.WriteLine("The array numbers is: " + count);
		Console.WriteLine("The array sum is: " + sum);
		Console.ResetColor();
	}	
	}
}