using System;
using System.Threading;
namespace CashMashine
{
	public class CashMashine
	{	
		public static void Main(string[] ter)
		{
			decimal MoneyPay=0;//Сумма чека
			decimal Payment=0;
			int CodeProduct=0;//код продукта
			byte flag=1;
			string ListCheckProducts="";
			int QuantityProducts=0;
			string [] ListOfProducts = new string[15];//список продуктов
			ListOfProducts[0]="1-'Чай' * 120 сом";
			ListOfProducts[1]="2-'Сахар' * 50 сом";
			ListOfProducts[2]="3-'Яблоки' * 95 сом";
			ListOfProducts[3]="4-'Картошка' * 25 сом";
			ListOfProducts[4]="5-'Шоколад' * 70 сом";
			ListOfProducts[5]="6-'Мороженное' * 15 сом";
			ListOfProducts[6]="7-'Яйца' * 8 сом";
			ListOfProducts[7]="8-'Хлеб' * 20 сом";
			ListOfProducts[8]="9-'Молоко' * 40 сом";
			ListOfProducts[9]="10-'Кола' * 50 сом";
			ListOfProducts[10]="11-'Пепси' * 55 сом";
			ListOfProducts[11]="12-'Конфеты * 190 сом";
			ListOfProducts[12]="13-'Бананы' * 300 сом";
			ListOfProducts[13]="14-'Snikers' * 45 сом";
			ListOfProducts[14]="15-'Кофе' * 400 сом";
			
		while(flag==1)
		{
			Console.WriteLine("НАРОДНЫЙ");
			Console.WriteLine("Для выбора продукта введите код продукта:");
			for(int i=0;i<15;i++)//вывод доступных продуктов
			{
				Console.Write("{0}\t",ListOfProducts[i].Replace("*","")+" | ");
				if((i+1)%3==0)
				{
					Console.WriteLine("\n");
				}
				
			}
				CodeProduct=Convert.ToInt32(Console.ReadLine());
				if(CodeProduct>15 ||CodeProduct<1)//проверка кода продукта
				{
					Console.ForegroundColor = ConsoleColor.Red; 
					Console.WriteLine("Товар не найден!!");
					Console.ResetColor(); 
				
				}
				else
				{
					for(int i=0;i<15;i++)
					{
						if(CodeProduct-1==i)
						{ 
							ListCheckProducts+=Convert.ToString(CodeProduct)+" / ";//запись кода всех выбранных продуктов
							QuantityProducts++;//подсчет количесвта продуктов
							MoneyPay+=Convert.ToDecimal(ListOfProducts[i].Split('*')[1].Replace("сом","").Trim());//подсчет суммы
							break;
						}
					}
				}
			Console.ForegroundColor = ConsoleColor.Green; 
			Console.WriteLine("Для добовления новвого продукта введите 1\nДля выхода нажмите 0\n");
			Console.ResetColor(); 
			flag=Convert.ToByte(Console.ReadLine());
			Console.Clear();
		}
		
		Console.WriteLine("Пожалуйста подождите...");
		Console.ForegroundColor = ConsoleColor.Green; 
		for(int i=1;i<10;i++)
		{
			
				Console.Write("=");
				Thread.Sleep(200);
		}
		Console.ResetColor(); 
		Console.WriteLine("\n\nЧек:\nДата-"+DateTime.Now);
		Console.WriteLine("Продукты:");
		for(int i=0;i<QuantityProducts;i++)
		{
			Console.WriteLine(ListOfProducts[Convert.ToInt32(ListCheckProducts.Split('/')[i].Trim())-1].Replace("*",""));
		}
	
		
		while(flag==0)
		{
			Console.WriteLine("\nВаша сумма состовляет = "+MoneyPay+"\nВнесите оплату:");
			Payment=Convert.ToDecimal(Console.ReadLine());
			if(Payment==MoneyPay)
			{
				Console.WriteLine("Спасибо за покупку!!");
				flag=1;
			}
			else if(Payment>MoneyPay)
			{
				Console.WriteLine("Спасибо за покупку!! Ваша сдача = "+(Payment-MoneyPay));
				flag=1;
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red; 
				Console.WriteLine("Неверная сумма оплаты!!");
				Console.ResetColor(); 
			}
		}
		Console.ReadKey();
		}
		
	}
}