using System;
namespace Task_1
{
	public class Task_1
	{
		static void PrinText()
		{
			Console.Write("Hello World!!!");
		}
		public static void Main(string [] tasks)
		{
		
			PrinText();
			Console.ReadKey();
		}
	}
}