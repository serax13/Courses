using System;
namespace Task_2
{
	public class Task_2
	{
		static void PrinText(string Text)
		{
			Console.Write("Вы написали: "+Text);
		}
		public static void Main(string [] tasks)
		{
			string Text;
			Console.WriteLine("Введите текст>>");
			Text=Console.ReadLine();
			PrinText(Text);
			Console.ReadKey();
		}
	}
}