using System;
using System.Threading;
namespace Tasks
{
	public class Cash
	{
		public static void Main(string [] agrs)
		{
			Console.WriteLine("\nСписок продуктов: \n");
			string[] ProductArray = new string[15];
			ProductArray[0] = "1  - Чай      | 150 сом";
			ProductArray[1] = "2  - Сахар    | 120 сом";
			ProductArray[2] = "3  - Масло    | 250 сом";
			ProductArray[3] = "4  - Рис      | 164 сом";
			ProductArray[4] = "5  - Мука     | 220 сом";
			ProductArray[5] = "6  - Конфеты  | 150 сом";
			ProductArray[6] = "7  - Молоко   | 120 сом";
			ProductArray[7] = "8  - Кефир    | 250 сом";
			ProductArray[8] = "9  - Творог   | 164 сом";
			ProductArray[9] = "10 - Гречка   | 220 сом";
			ProductArray[10] = "11 - Макароны | 100 сом";
			ProductArray[11] = "12 - Сыр      | 130 сом";
			ProductArray[12] = "13 - Колбаса  | 250 сом";
			ProductArray[13] = "14 - Сметана  | 114 сом";
			ProductArray[14] = "15 - Йогурт   | 58 сом\n";
			decimal Sum=0;
			for (int i=0; i<=15-1;i++)
			{
				Console.WriteLine(ProductArray[i]);
			}
			Console.WriteLine("Выберите номера продуктов через запятую \n");
			string Text=Console.ReadLine();
			string [] Basket=Text.Split(',');
			Console.WriteLine("Подождите, пожалуйста . . . \n");
			for(int i = 1; i <= 10; i++)
			{
				Thread.Sleep(1000);
				Console.Write("=");
			}
			Console.Write("\n");
			for (int j=0; j<=Basket.Length-1;j++)
			{
				int Res1=Convert.ToInt32(Basket[j]);
				for (int i=0; i<=15-1;i++)
				{
					if(Res1==i+1)
					{
						Console.WriteLine(ProductArray[i]);
						string [] SumBasket=ProductArray[i].Split('|');
						decimal Res=Convert.ToDecimal(SumBasket[1].Trim().Replace("сом",""));
						Sum=Sum+Res;
					}
				}
			}
			Console.Write("\nОбщая сумма к оплате : "+Sum+ " сом\nВведите сумму оплаты : ");
			decimal Pay=Convert.ToDecimal(Console.ReadLine());
			if(Pay==Sum)
			{
				Console.WriteLine("\nСпасибо за покупку!");
			}
			else if(Pay>Sum)
			{
				decimal ChangeMoney=Pay-Sum;
				Console.WriteLine("\nСпасибо за покупку! Ваша сдача "+ChangeMoney+" cом");
			}
			else
			{
				decimal ChangeMoney=Sum-Pay;
				Console.WriteLine("\nУ Вас  не хватает денежных средств на сумму "+ChangeMoney+" cом");
			}
			Console.ReadKey();
		}
		
	}
}