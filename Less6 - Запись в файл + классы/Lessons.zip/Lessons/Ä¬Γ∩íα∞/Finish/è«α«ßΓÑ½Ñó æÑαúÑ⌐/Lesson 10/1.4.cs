using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {	
            string numbers = Console.ReadLine();
			string[] listNumbers = numbers.Split(' ');
			int numbersCount = listNumbers.Length;
			int a=0;
			for(int i = 0; a<numbersCount; i++)
			{
				
				for(int ii=0;ii<4;ii++)
				if(a<numbersCount)
				{
				{
					Console.Write(listNumbers[a]+" ");
					a++;
				}
				}
				Console.WriteLine();
			}
        }
    }
}