using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {
           
           
           for(int i=2;i<10;i++)
           {
           		for(int ii=1;ii<10;ii++)
           		{
           			int total=i*ii;
           			Console.WriteLine(" "+i+" * "+ii+" = "+total);
           		}
           		Console.WriteLine();
           }
        }
    }
}