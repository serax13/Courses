using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {
           string[]alfa = {"а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я"};
           int a =0;
           for(int i=0;i<7;i++)
           {
           	for(int ii=0;ii<5;ii++)
           	{
           		if(a<33)
           		{
           		Console.Write(alfa[a]+" ");
           		a++;
           		}
           	}
           	Console.WriteLine();
           }
        }
    }
}