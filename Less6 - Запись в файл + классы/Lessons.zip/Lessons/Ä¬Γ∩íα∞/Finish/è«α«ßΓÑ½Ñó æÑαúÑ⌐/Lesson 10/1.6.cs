using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace CSharp_Shell
{

    public static class Program 
    {
        public static void Main() 
        {	string number="";
            string numbers = Console.ReadLine();
			string[] listNumbers = numbers.Split(',');
			int numbersCount = listNumbers.Length;
			
			for(int i = 0; i <numbersCount; i++)
			{
				Console.WritrLine(numbers[i]);
			}
        }
    }
}