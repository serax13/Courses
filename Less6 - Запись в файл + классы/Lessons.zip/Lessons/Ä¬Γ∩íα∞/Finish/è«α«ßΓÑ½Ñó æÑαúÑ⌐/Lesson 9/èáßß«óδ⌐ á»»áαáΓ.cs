using System;
using System.Threading;
namespace Home
{
	public class Home
	{
		public static void Main (string [] args)
		{
			string [] groceryList = new string[15];
			groceryList[0]="1 - Чай | 120 сом";
			groceryList[1]="2 - Сахар | 50 сом";
			groceryList[2]="3 - Соль | 15 сом";
			groceryList[3]="4 - Рис | 200 сом";
			groceryList[4]="5 - Гречка | 220 сом";
			groceryList[5]="6 - Картофель | 60 сом";
			groceryList[6]="7 - Морковь | 50 сом";
			groceryList[7]="8 - Хлеб | 20 сом";
			groceryList[8]="9 - Йогурт | 110 сом";
			groceryList[9]="10 - Кефир | 60 сом";
			groceryList[10]="11 - Сметана | 80 сом";
			groceryList[11]="12 - Масло | 160 сом";
			groceryList[12]="13 - Салат | 140 сом";
			groceryList[13]="14 - Колбаса | 250 сом";
			groceryList[14]="15 - Лапша | 45 сом";

			decimal total=0;
			int usingProduct1=0;

			Console.WriteLine("Список Товара: \n");
			foreach(var catalogProduct in groceryList)
            Console.WriteLine(catalogProduct);
            Console.WriteLine("Выберите продукты: (Введите номер товара через запятую)");
            string usingProduct = Console.ReadLine(); 
            int numberOfPurchases = usingProduct.Length - usingProduct.Replace(",", "").Length;
            for(int i=0; i<=numberOfPurchases;i++)
            {
            	usingProduct1 = Convert.ToInt32(usingProduct.Split(",")[i].Trim());
            	total = total+Convert.ToInt32(groceryList[usingProduct1-1].Split("|")[1].Replace("сом","").Trim());
     		}
     		Console.Write("Пожалуйста подождите");
     		for(int i = 1; i <= 10; i++)
			{
				Thread.Sleep(300);
				Console.Write(".");
			}
            Console.WriteLine("\nОбщая сумма к оплате: " +total+" сом\nВведите оплату: ");
            decimal sum = Convert.ToDecimal(Console.ReadLine());
            if(sum==total)
            	Console.WriteLine("Спасибо за покупку!");
            else if(sum>total)
            	Console.WriteLine("Спасибо за покупку!\nВаша сдача: "+(sum-total)+" сом");
            else
            	Console.WriteLine("Не хватает суммы для оплаты!");
		}
	}
}


