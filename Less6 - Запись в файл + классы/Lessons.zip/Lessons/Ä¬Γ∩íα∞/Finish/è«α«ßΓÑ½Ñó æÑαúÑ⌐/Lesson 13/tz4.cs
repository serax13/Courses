using System;

namespace TZ
{
	public static class tz4
	{
		static void cycle(long count)
		{
			for(int i=1;i<=count;i++)
			{
				if (i==10)
					Console.Write(i+";");
				else
					Console.Write(i+", ");
			}
		}
		public static void Main()
		{
			long Number=10;
			cycle(Number);
		}
	}
}