using System;

namespace TZ
{
    public static class tzf
    {
        static void ruAlphabetWords(string text)
        {
            string[] ruAlphabet = new string[34];
            ruAlphabet[0] = "А";
            ruAlphabet[1] = "Б";
            ruAlphabet[2] = "В";
            ruAlphabet[3] = "Г";
            ruAlphabet[4] = "Д";
            ruAlphabet[5] = "Е";
            ruAlphabet[6] = "Ё";
            ruAlphabet[7] = "Ж";
            ruAlphabet[8] = "З";
            ruAlphabet[9] = "И";
            ruAlphabet[10] = "Й";
            ruAlphabet[11] = "К";
            ruAlphabet[12] = "Л";
            ruAlphabet[13] = "М";
            ruAlphabet[14] = "Н";
            ruAlphabet[15] = "О";
            ruAlphabet[16] = "П";
            ruAlphabet[17] = "Р";
            ruAlphabet[18] = "С";
            ruAlphabet[19] = "Т";
            ruAlphabet[20] = "У";
            ruAlphabet[21] = "Ф";
            ruAlphabet[22] = "Х";
            ruAlphabet[23] = "Ц";
            ruAlphabet[24] = "Ч";
            ruAlphabet[25] = "Ш";
            ruAlphabet[26] = "Щ";
            ruAlphabet[27] = "Ъ";
            ruAlphabet[28] = "Ы";
            ruAlphabet[29] = "Ь";
            ruAlphabet[30] = "Э";
            ruAlphabet[31] = "Ю";
            ruAlphabet[32] = "Я";
            ruAlphabet[33] = " ";

            string[] enAlphabet = new string[34];
            enAlphabet[0] = "A";
            enAlphabet[1] = "B";
            enAlphabet[2] = "V";
            enAlphabet[3] = "G";
            enAlphabet[4] = "D";
            enAlphabet[5] = "E";
            enAlphabet[6] = "E";
            enAlphabet[7] = "J";
            enAlphabet[8] = "Z";
            enAlphabet[9] = "I";
            enAlphabet[10] = "I";
            enAlphabet[11] = "K";
            enAlphabet[12] = "L";
            enAlphabet[13] = "M";
            enAlphabet[14] = "N";
            enAlphabet[15] = "O";
            enAlphabet[16] = "P";
            enAlphabet[17] = "R";
            enAlphabet[18] = "S";
            enAlphabet[19] = "T";
            enAlphabet[20] = "U";
            enAlphabet[21] = "F";
            enAlphabet[22] = "H";
            enAlphabet[23] = "C";
            enAlphabet[24] = "CH";
            enAlphabet[25] = "SH";
            enAlphabet[26] = "SH";
            enAlphabet[27] = "'";
            enAlphabet[28] = "Y";
            enAlphabet[29] = "'";
            enAlphabet[30] = "E";
            enAlphabet[31] = "IU";
            enAlphabet[32] = "YA";
            enAlphabet[33] = " ";

			string Result = "";
            int Length = text.Length;
            for (int QuantityLetter = 0; QuantityLetter < Length; QuantityLetter++)
            {
                for (int QuantityLetterInLine = 0; QuantityLetterInLine < 34; QuantityLetterInLine++)
                {
                    string textUp = text.ToUpper();
                    if (textUp.Substring(QuantityLetter, 1) == ruAlphabet[QuantityLetterInLine])
                    {
                        if (textUp.Substring(QuantityLetter, 1) == ruAlphabet[QuantityLetterInLine])
                        {
                            if (text.Substring(QuantityLetter, 1) == ruAlphabet[QuantityLetterInLine])
                                Result = Result + enAlphabet[QuantityLetterInLine];
                            else
                                Result = Result + enAlphabet[QuantityLetterInLine].ToLower();
                        }
                    }
                }
            }

            Console.WriteLine(Result);
        }
		
		public static void Main()
        {
            string NameSurename = Console.ReadLine();
            ruAlphabetWords(NameSurename);
        }
    }
}