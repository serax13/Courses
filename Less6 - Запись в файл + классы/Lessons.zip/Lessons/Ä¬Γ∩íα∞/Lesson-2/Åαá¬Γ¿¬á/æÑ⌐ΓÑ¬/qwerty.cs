using System;
namespace qwerty
{
	public class qwerty
{	
	public static void Main (string [] args) {
	Console.WriteLine ("\t\t*\n\t****\n********");
}
}
}using System;
namespace qwerty
{
	public class qwerty
{	
	public static void Main (string [] args) {
	Console.WriteLine ("\t\t*\n\t****\n********");
}
}
}