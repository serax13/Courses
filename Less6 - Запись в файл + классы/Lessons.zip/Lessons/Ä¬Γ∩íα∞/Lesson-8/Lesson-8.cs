using System;

namespace Lesson8
{
	public class Lesson8
	{
		public static void Main(string [] agrs)
		{
			for(int i = 1; i <= 10; i++)
			{
				// Console.WriteLine(i);
			}			
			
			int w = 1;
			while(w <= 0)
			{
				// Console.WriteLine(w);
				// w++;
			}
			
			int d = 1;
			do
			{
				// Console.WriteLine(d);
			    // d++;
			}while(d <= 0);
			
			
			
			string[] dictionary = new string[5];
			dictionary[0] = "Hi | Privet";
			dictionary[1] = "World | Mir";
			dictionary[2] = "Main | Glavnyi";
			dictionary[3] = "Name | Imia";
			dictionary[4] = "Car | Mashina";
			
			
			Console.WriteLine(dictionary[0].Split('|')[0].Trim());
			Console.WriteLine(dictionary[0].Split('|')[1].Trim());
			
			string textSearch = Console.ReadLine();
			
			for(int i = 0; i <= 4; i++)
			{				
				if(dictionary[i].Contains(textSearch) == true)
				{
					Console.WriteLine(dictionary[i].Split('|')[1].Trim());
				}
			}
			
			
			
			Console.ReadKey();
		}
	}
}