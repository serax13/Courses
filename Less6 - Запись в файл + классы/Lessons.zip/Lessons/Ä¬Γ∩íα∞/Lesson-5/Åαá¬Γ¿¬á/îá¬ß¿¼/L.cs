using System;

namespace L
{
	public class L
	{
		public static void Main(string [] args)
		{	
			int a;
			// Вывести текст на консоль 
			Console.WriteLine("Введите число :");
			a = Convert.ToInt32(Console.ReadLine());
			// Проверка числа от 1 до 10
			if ( a >=1 && a <=10)
			{
				Console.WriteLine("Вы попали в диапазон от 1 до 10");
			}
			else
			{
				Console.WriteLine("Садись 2!");
			
			}
			Console.ReadKey();
		}
	}
}