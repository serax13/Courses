using System;

namespace L
{
	public class L
	{
		public static void Main(string [] args)
		{	
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("Привет мир!");
			
			
			Console.ReadKey();
		}
	}
}