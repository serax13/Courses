using System;

namespace Lesson3
{	
	public class Shkaf
	{
		public Shkaf()
		{
			Console.WriteLine("Конструтор!!!");
		}
		
		public void Noski()
		{
			Console.WriteLine("Носки");
		}
		
		public void Futbolki()
		{
			Console.WriteLine("футболки");
		}
		
		public void Bruki()
		{
			Console.WriteLine("Брюки");
		}
	}



	public class Lesson3
	{
		public static void Main(string [] agrs)
		{	
			
			Shkaf sf = new Shkaf();
			sf.Noski();
		}
	}
}