using System;
using System.Threading;

namespace lesson15
{

		public class User
		{
			public User(string Name)
			{
			 Console.WriteLine(Name);
			}
		}

		

	public class lesson15
	{
		public static void Main(string [] args)
 		{
 			User TextObj = new User("Sergei");
 		}
 	}
} 