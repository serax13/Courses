using System;
using System.Threading;

namespace lesson4
{
    public class NumbersToWords
    {
       public string Convert(int number)
{
    if (number == 0)
        return "ноль";

    string Words = "";

    if (number == 100)
    return "сто";

    if (number > 0)
    {
        if (Words != "")
            Words += " ";

        var UnitsMass = new[] { "ноль", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять", "десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать", "пятнадцать", "шестьнадцать", "семьнадцать", "восемьнадцать", "девятнадцать" };
        var TensMass = new[] { "ноль", "десять", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто" };

        if (number < 20)
            Words += UnitsMass[number];
        else
        {
            Words += TensMass[number / 10];
            if ((number % 10) > 0)
                Words += " " + UnitsMass[number % 10];
        }
    }

    return Words;
}
    }
        public class lesson15
        {
            public static void Main(string [] args)
            {
                NumbersToWords Obj = new NumbersToWords();
                Console.WriteLine(Obj.Convert(55));
                Console.ReadKey();            
            }
        }
}    